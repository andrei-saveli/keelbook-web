"""Minimal Excel (.xlsx) writer and reader, standard library only.

An .xlsx file is a zip of XML files (Office Open XML, ECMA-376). We write what a
person needs to work in Excel or LibreOffice: several sheets, a bold header row
that stays visible, column widths, a filter on every column, coloured severity
cells and drop-down lists for the input columns. Text is stored inline, numbers
as numbers. The reader understands what Excel/LibreOffice save back (shared
strings, inline strings, numbers), so a filled-in sheet can be imported.
"""

from __future__ import annotations

import re
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
from xml.etree import ElementTree as ET
from xml.sax.saxutils import escape

MAX_CELL = 32767  # Excel's limit per cell
_ILLEGAL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f]")

# Cell styles (index into cellXfs in styles.xml)
NORMAL, HEADER, CRITICAL, HIGH, MEDIUM, WRAP, TITLE, CELL, INPUT, INPUT_HEADER, LABEL, NOTE, LOW, TEXT = range(14)
SEVERITY_STYLE = {"critical": CRITICAL, "high": HIGH, "medium": MEDIUM, "low": LOW}

_NS = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main",
       "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
       "rel": "http://schemas.openxmlformats.org/package/2006/relationships"}


@dataclass
class Sheet:
    name: str
    rows: list[list[Any]] = field(default_factory=list)  # first row = header (if header=True)
    widths: list[int] = field(default_factory=list)  # characters per column
    header: bool = True
    styles: dict[tuple[int, int], int] = field(default_factory=dict)  # (row, col) 0-based -> style
    dropdowns: dict[int, list[str]] = field(default_factory=dict)  # col 0-based -> allowed values
    dropdown_rows: int = 0  # how many rows below the header get the drop-downs
    wrap_cols: set[int] = field(default_factory=set)  # long text: wrapped
    input_cols: set[int] = field(default_factory=set)  # to be filled in: highlighted
    hidden_cols: set[int] = field(default_factory=set)  # technical columns (kept for the import)
    freeze_cols: int = 0  # columns that stay visible when scrolling right
    tip: dict[int, str] = field(default_factory=dict)  # col -> help shown when a cell is selected


def col_letter(index: int) -> str:
    """0 -> A, 25 -> Z, 26 -> AA."""
    name = ""
    index += 1
    while index:
        index, rem = divmod(index - 1, 26)
        name = chr(65 + rem) + name
    return name


def _text(value: Any) -> str:
    text = _ILLEGAL.sub("", str(value))
    return text[:MAX_CELL]


def _cell(ref: str, value: Any, style: int) -> str:
    s = f' s="{style}"' if style else ""
    if value is None or value == "":
        return f'<c r="{ref}"{s}/>' if style else ""
    if isinstance(value, bool):
        value = "yes" if value else "no"
    if isinstance(value, (int, float)):
        return f'<c r="{ref}"{s}><v>{value}</v></c>'
    text = _text(value)  # an inline string: Excel never evaluates it as a formula, even if it starts with "="
    space = ' xml:space="preserve"' if text != text.strip() or "\n" in text else ""
    return f'<c r="{ref}" t="inlineStr"{s}><is><t{space}>{escape(text)}</t></is></c>'


def _sheet_xml(sheet: Sheet) -> str:
    rows = sheet.rows
    ncols = max((len(r) for r in rows), default=1)
    parts = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
             f'<worksheet xmlns="{_NS["m"]}" xmlns:r="{_NS["r"]}">',
             '<sheetPr><pageSetUpPr fitToPage="1"/></sheetPr>']
    if sheet.header and len(rows) > 1:
        x = sheet.freeze_cols
        top_left = f"{col_letter(x)}2"
        pane = (f'<pane xSplit="{x}" ySplit="1" topLeftCell="{top_left}" activePane="bottomRight" state="frozen"/>'
                if x else '<pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/>')
        parts.append(f'<sheetViews><sheetView workbookViewId="0">{pane}</sheetView></sheetViews>')
    parts.append('<sheetFormatPr defaultRowHeight="15"/>')
    if sheet.widths:
        parts.append("<cols>" + "".join(
            f'<col min="{i + 1}" max="{i + 1}" width="{w}" customWidth="1"'
            + (' hidden="1"' if i in sheet.hidden_cols else "") + "/>" for i, w in enumerate(sheet.widths))
            + "</cols>")
    parts.append("<sheetData>")
    for r, row in enumerate(rows):
        cells = []
        for c in range(max(len(row), ncols if (sheet.header and rows) else 0)):
            value = row[c] if c < len(row) else None
            if sheet.header and r == 0:
                default = INPUT_HEADER if c in sheet.input_cols else HEADER
            elif sheet.header:
                default = INPUT if c in sheet.input_cols else WRAP if c in sheet.wrap_cols else CELL
            else:
                default = TEXT if c in sheet.wrap_cols else NORMAL
            cells.append(_cell(f"{col_letter(c)}{r + 1}", value, sheet.styles.get((r, c), default)))
        height = ' ht="30" customHeight="1"' if sheet.header and r == 0 else ""
        parts.append(f'<row r="{r + 1}"{height}>' + "".join(cells) + "</row>")
    parts.append("</sheetData>")
    if sheet.header and len(rows) > 1:
        parts.append(f'<autoFilter ref="A1:{col_letter(ncols - 1)}{len(rows)}"/>')
    if sheet.dropdowns:
        last = max(len(rows), 1 + sheet.dropdown_rows)
        parts.append(f'<dataValidations count="{len(sheet.dropdowns)}">')
        for c, values in sorted(sheet.dropdowns.items()):
            listing = ",".join(values)
            help_text = sheet.tip.get(c, "Choose from the list.")[:255]
            parts.append(f'<dataValidation type="list" allowBlank="1" showErrorMessage="1" showInputMessage="1" '
                         f'promptTitle="Choose" prompt="{escape(help_text, {chr(34): "&quot;"})}" '
                         f'sqref="{col_letter(c)}2:{col_letter(c)}{last}">'
                         f'<formula1>{escape(chr(34) + listing + chr(34))}</formula1></dataValidation>')
        parts.append("</dataValidations>")
    parts.append('<pageMargins left="0.4" right="0.4" top="0.5" bottom="0.5" header="0.3" footer="0.3"/>'
                 '<pageSetup orientation="landscape" fitToWidth="1" fitToHeight="0"/>')
    parts.append("</worksheet>")
    return "".join(parts)


_BORDER = 'borderId="1" applyBorder="1"'
_TOP = '<alignment vertical="top"/>'
_TOP_WRAP = '<alignment vertical="top" wrapText="1"/>'
_MID_WRAP = '<alignment vertical="center" wrapText="1"/>'
# A calm, light look: one sans-serif font, a dark header row, hairline row dividers instead of
# a grid, soft tinted fills for severities and blue for the cells a person fills in.
_FONT = '<name val="Helvetica Neue"/><family val="2"/>'  # Excel without it falls back to a similar sans-serif
_STYLES = (
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    f'<styleSheet xmlns="{_NS["m"]}">'
    '<fonts count="8">'
    f'<font><sz val="11"/><color rgb="FF1D1D1F"/>{_FONT}</font>'  # 0 body
    f'<font><b/><sz val="11"/><color rgb="FFFFFFFF"/>{_FONT}</font>'  # 1 header (white on dark)
    f'<font><b/><sz val="20"/><color rgb="FF1D1D1F"/>{_FONT}</font>'  # 2 title
    f'<font><b/><sz val="11"/><color rgb="FFD70015"/>{_FONT}</font>'  # 3 critical
    f'<font><b/><sz val="11"/><color rgb="FFA05A00"/>{_FONT}</font>'  # 4 medium
    f'<font><sz val="10"/><color rgb="FF6E6E73"/>{_FONT}</font>'  # 5 note
    f'<font><b/><sz val="11"/><color rgb="FFC93400"/>{_FONT}</font>'  # 6 high
    f'<font><b/><sz val="11"/><color rgb="FF1D1D1F"/>{_FONT}</font>'  # 7 label
    '</fonts>'
    '<fills count="9"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>'
    '<fill><patternFill patternType="solid"><fgColor rgb="FF1D1D1F"/></patternFill></fill>'  # 2 header
    '<fill><patternFill patternType="solid"><fgColor rgb="FFFFE9EB"/></patternFill></fill>'  # 3 critical
    '<fill><patternFill patternType="solid"><fgColor rgb="FFFFF0E5"/></patternFill></fill>'  # 4 high
    '<fill><patternFill patternType="solid"><fgColor rgb="FFFFF8E1"/></patternFill></fill>'  # 5 medium
    '<fill><patternFill patternType="solid"><fgColor rgb="FFE8F2FF"/></patternFill></fill>'  # 6 input
    '<fill><patternFill patternType="solid"><fgColor rgb="FF0071E3"/></patternFill></fill>'  # 7 input header
    '<fill><patternFill patternType="solid"><fgColor rgb="FFF5F5F7"/></patternFill></fill>'  # 8 low
    '</fills>'
    '<borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border>'
    '<border><left/><right/><top/><bottom style="thin"><color rgb="FFE5E5EA"/></bottom><diagonal/></border></borders>'
    '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
    '<cellXfs count="14">'
    '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1">'
    + _TOP + '</xf>'  # NORMAL
    f'<xf numFmtId="0" fontId="1" fillId="2" {_BORDER} xfId="0" applyFont="1" applyFill="1" applyAlignment="1">'
    + _MID_WRAP + '</xf>'  # HEADER
    f'<xf numFmtId="0" fontId="3" fillId="3" {_BORDER} xfId="0" applyFont="1" applyFill="1" applyAlignment="1">'
    + _TOP + '</xf>'  # CRITICAL
    f'<xf numFmtId="0" fontId="6" fillId="4" {_BORDER} xfId="0" applyFont="1" applyFill="1" applyAlignment="1">'
    + _TOP + '</xf>'  # HIGH
    f'<xf numFmtId="0" fontId="4" fillId="5" {_BORDER} xfId="0" applyFont="1" applyFill="1" applyAlignment="1">'
    + _TOP + '</xf>'  # MEDIUM
    f'<xf numFmtId="0" fontId="0" fillId="0" {_BORDER} xfId="0" applyFont="1" applyAlignment="1">'
    + _TOP_WRAP + '</xf>'  # WRAP
    '<xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1"/>'  # TITLE
    f'<xf numFmtId="0" fontId="0" fillId="0" {_BORDER} xfId="0" applyFont="1" applyAlignment="1">'
    + _TOP + '</xf>'  # CELL
    f'<xf numFmtId="0" fontId="0" fillId="6" {_BORDER} xfId="0" applyFont="1" applyFill="1" applyAlignment="1">'
    + _TOP_WRAP + '</xf>'  # INPUT
    f'<xf numFmtId="0" fontId="1" fillId="7" {_BORDER} xfId="0" applyFont="1" applyFill="1" applyAlignment="1">'
    + _MID_WRAP + '</xf>'  # INPUT_HEADER
    '<xf numFmtId="0" fontId="7" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1">'
    + _TOP + '</xf>'  # LABEL
    '<xf numFmtId="0" fontId="5" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1">'
    + _TOP_WRAP + '</xf>'  # NOTE
    f'<xf numFmtId="0" fontId="0" fillId="8" {_BORDER} xfId="0" applyFont="1" applyFill="1" applyAlignment="1">'
    + _TOP + '</xf>'  # LOW
    '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1">'
    + _TOP_WRAP + '</xf>'  # TEXT
    '</cellXfs>'
    '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
    '</styleSheet>'
)


def _safe_sheet_name(name: str, used: set[str]) -> str:
    clean = re.sub(r"[\[\]:*?/\\]", " ", name).strip()[:31] or "Sheet"
    candidate, n = clean, 2
    while candidate.lower() in used:
        candidate = f"{clean[:28]} {n}"
        n += 1
    used.add(candidate.lower())
    return candidate


def write_xlsx(path: Path, sheets: list[Sheet]) -> None:
    used: set[str] = set()
    names = [_safe_sheet_name(s.name, used) for s in sheets]
    content_types = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        '<Default Extension="xml" ContentType="application/xml"/>'
        '<Override PartName="/xl/workbook.xml" '
        'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
        '<Override PartName="/xl/styles.xml" '
        'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
        + "".join(f'<Override PartName="/xl/worksheets/sheet{i + 1}.xml" '
                  'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
                  for i in range(len(sheets)))
        + "</Types>")
    root_rels = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        f'<Relationships xmlns="{_NS["rel"]}">'
        '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/'
        'officeDocument" Target="xl/workbook.xml"/></Relationships>')
    workbook = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        f'<workbook xmlns="{_NS["m"]}" xmlns:r="{_NS["r"]}"><sheets>'
        + "".join(f'<sheet name="{escape(n, {chr(34): "&quot;"})}" sheetId="{i + 1}" r:id="rId{i + 1}"/>'
                  for i, n in enumerate(names))
        + "</sheets>"
        + "</workbook>")
    wb_rels = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        f'<Relationships xmlns="{_NS["rel"]}">'
        + "".join(f'<Relationship Id="rId{i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/'
                  f'relationships/worksheet" Target="worksheets/sheet{i + 1}.xml"/>' for i in range(len(sheets)))
        + f'<Relationship Id="rId{len(sheets) + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/'
          'relationships/styles" Target="styles.xml"/></Relationships>')
    tmp = path.with_suffix(path.suffix + ".tmp")
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", content_types)
        z.writestr("_rels/.rels", root_rels)
        z.writestr("xl/workbook.xml", workbook)
        z.writestr("xl/_rels/workbook.xml.rels", wb_rels)
        z.writestr("xl/styles.xml", _STYLES)
        for i, sheet in enumerate(sheets):
            z.writestr(f"xl/worksheets/sheet{i + 1}.xml", _sheet_xml(sheet))
    tmp.replace(path)


# --- reading -----------------------------------------------------------------------


class XlsxError(ValueError):
    pass


def _col_index(ref: str) -> int:
    letters = re.match(r"[A-Z]+", ref.upper())
    n = 0
    for ch in letters.group(0) if letters else "A":
        n = n * 26 + (ord(ch) - 64)
    return n - 1


def read_xlsx(path: Path) -> dict[str, list[list[str]]]:
    """All sheets as {name: rows of text}. Empty cells are ''. Numbers come back as text."""
    try:
        z = zipfile.ZipFile(path)
    except (zipfile.BadZipFile, OSError) as exc:
        raise XlsxError(f"{path.name} is not an Excel .xlsx file ({exc}).") from exc
    with z:
        try:
            wb = ET.fromstring(z.read("xl/workbook.xml"))
            rels = ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))
        except KeyError as exc:
            raise XlsxError(f"{path.name} is not an Excel .xlsx workbook.") from exc
        targets = {r.get("Id"): r.get("Target") for r in rels.findall("rel:Relationship", _NS)}
        shared: list[str] = []
        if "xl/sharedStrings.xml" in z.namelist():
            sst = ET.fromstring(z.read("xl/sharedStrings.xml"))
            for si in sst.findall("m:si", _NS):
                shared.append("".join(t.text or "" for t in si.iter(f"{{{_NS['m']}}}t")))
        out: dict[str, list[list[str]]] = {}
        for sheet in wb.findall("m:sheets/m:sheet", _NS):
            target = targets.get(sheet.get(f"{{{_NS['r']}}}id"), "")
            part = target.lstrip("/") if target.startswith("/") else "xl/" + target
            try:
                root = ET.fromstring(z.read(part))
            except KeyError:
                continue
            rows: list[list[str]] = []
            for row in root.iter(f"{{{_NS['m']}}}row"):
                values: dict[int, str] = {}
                position = 0
                for c in row.findall("m:c", _NS):
                    kind = c.get("t")
                    if kind == "inlineStr":
                        text = "".join(t.text or "" for t in c.iter(f"{{{_NS['m']}}}t"))
                    else:
                        v = c.find("m:v", _NS)
                        text = v.text if v is not None and v.text is not None else ""
                        if kind == "s" and text:
                            text = shared[int(text)]
                        elif kind == "b":
                            text = "TRUE" if text == "1" else "FALSE"
                        elif kind not in ("str", "e") and text.endswith(".0"):
                            text = text[:-2]  # 2.0 saved as a number -> "2"
                    ref = c.get("r")
                    position = _col_index(ref) if ref else position  # 'r' is optional
                    values[position] = text
                    position += 1
                r_attr = row.get("r")
                index = int(r_attr) - 1 if r_attr and r_attr.isdigit() else len(rows)
                while len(rows) < index:
                    rows.append([])
                width = max(values) + 1 if values else 0
                rows.append([values.get(i, "") for i in range(width)])
            out[sheet.get("name") or f"Sheet{len(out) + 1}"] = rows
        return out
