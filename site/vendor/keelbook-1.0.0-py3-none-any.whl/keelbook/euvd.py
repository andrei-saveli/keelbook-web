"""ENISA's European Vulnerability Database (EUVD): its list of exploited vulnerabilities.

Used as a second source of "actively exploited" CANDIDATES, next to CISA KEV.
The tool downloads ENISA's whole exploited list (it sends nothing about your
product) and matches CVE IDs locally.

Checked live on 2026-11-01:
* ``/api/exploitedvulnerabilities`` returns only the latest few entries,
  whatever the paging, so it is NOT used.
* ``/api/search?exploited=true`` pages through the full list (1782 entries,
  every one with a CVE alias). 1765 of those CVEs were also in CISA KEV
  (catalogue 2026.10.30); 17 were only in EUVD, 1 only in KEV.
* ENISA's terms of use for the API were NOT found (the FAQ page did not load).
  Check them before relying on this in a paid product.

A listing here is a candidate, never a decision: CRA Art. 3(42) requires
reliable evidence that the vulnerability was exploited, and a person decides.
"""

from __future__ import annotations

import json
import re
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable

from keelbook import __version__
from keelbook.errors import VulnLookupError
from keelbook.nvd import cache_root
from keelbook.vulns import Finding

SEARCH_URL = "https://euvdservices.enisa.europa.eu/api/search"
PAGE_SIZE = 100  # the API's maximum
MAX_PAGES = 200  # safety stop (20 000 entries)
CACHE_TTL = timedelta(hours=24)
CACHE_SCHEMA = 1
MAX_RETRIES = 3
TIMEOUT_SECONDS = 60
_CVE_RE = re.compile(r"CVE-\d{4}-\d{4,}", re.IGNORECASE)

EuvdHttpFn = Callable[[str], "dict[str, Any]"]


def default_cache_file() -> Path:
    return cache_root() / "euvd-exploited.json"


def _default_http(url: str) -> dict[str, Any]:
    request = urllib.request.Request(url, headers={"User-Agent": f"keelbook/{__version__}"})
    with urllib.request.urlopen(request, timeout=TIMEOUT_SECONDS) as response:
        return json.loads(response.read())


@dataclass(frozen=True)
class EuvdEntry:
    euvd_id: str
    cve_ids: tuple[str, ...]
    exploited_since: str | None  # ISO date when it could be read, else ENISA's text


@dataclass
class EuvdCatalogue:
    entries: dict[str, list[EuvdEntry]] = field(default_factory=dict)  # CVE -> entries
    fetched_at: datetime | None = None
    total: int = 0
    from_cache: bool = False


def _date(text: Any) -> str | None:
    if not isinstance(text, str) or not text.strip():
        return None
    for pattern in ("%b %d, %Y, %I:%M:%S %p", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d"):
        try:
            return datetime.strptime(text.strip(), pattern).date().isoformat()
        except ValueError:
            continue
    return text.strip()


def _entries(items: list[Any]) -> list[EuvdEntry]:
    out = []
    for item in items:
        if not isinstance(item, dict) or not isinstance(item.get("id"), str):
            continue
        cves = tuple(sorted({c.upper() for c in _CVE_RE.findall(str(item.get("aliases") or ""))}))
        out.append(EuvdEntry(item["id"], cves, _date(item.get("exploitedSince"))))
    return out


def _catalogue(entries: list[EuvdEntry], fetched: datetime, from_cache: bool) -> EuvdCatalogue:
    catalogue = EuvdCatalogue(fetched_at=fetched, total=len(entries), from_cache=from_cache)
    for entry in entries:
        for cve in entry.cve_ids:
            catalogue.entries.setdefault(cve, []).append(entry)
    return catalogue


def load_saved(cache_file: Path | None) -> EuvdCatalogue | None:
    """The saved EUVD list, whatever its age (offline mode); None if there is none."""
    return _read_cache(cache_file, datetime.now(timezone.utc), timedelta(days=365 * 100))


def fetch_exploited(
    http: EuvdHttpFn = _default_http,
    cache_file: Path | None = None,
    now: Callable[[], datetime] = lambda: datetime.now(timezone.utc),
    sleep: Callable[[float], None] = time.sleep,
    ttl: timedelta = CACHE_TTL,
) -> EuvdCatalogue:
    """The full EUVD exploited list, from the cache if it is fresh enough."""
    cached = _read_cache(cache_file, now(), ttl)
    if cached is not None:
        return cached

    items: list[Any] = []
    total: int | None = None
    for page in range(MAX_PAGES):
        query = urllib.parse.urlencode({"exploited": "true", "size": PAGE_SIZE, "page": page})
        answer = _get(http, f"{SEARCH_URL}?{query}", sleep)
        page_items = answer.get("items")
        if not isinstance(page_items, list) or not isinstance(answer.get("total"), int):
            raise VulnLookupError("EUVD returned an unexpected response")
        total = answer["total"]
        items.extend(page_items)
        if not page_items or len(items) >= total:
            break
    if total is None or len(items) < total:
        # A partial list would make some CVEs look "not exploited". Refuse it.
        raise VulnLookupError(
            f"EUVD download was incomplete ({len(items)} of {total} entries). Try again later."
        )
    entries = _entries(items)
    fetched = now()
    _write_cache(cache_file, entries, fetched)
    return _catalogue(entries, fetched, from_cache=False)


def _get(http: EuvdHttpFn, url: str, sleep: Callable[[float], None]) -> dict[str, Any]:
    problem = "unknown error"
    for attempt in range(MAX_RETRIES):
        try:
            answer = http(url)
            if isinstance(answer, dict):
                return answer
            problem = "answer is not a JSON object"
        except urllib.error.HTTPError as exc:
            problem = f"HTTP {exc.code}"
            if exc.code < 500 and exc.code != 429:
                break
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            problem = str(getattr(exc, "reason", exc))
        except json.JSONDecodeError:
            problem = "answer is not valid JSON"
        if attempt < MAX_RETRIES - 1:
            sleep(2 ** attempt)
    raise VulnLookupError(f"Could not download the EUVD exploited list ({problem}).")


def _read_cache(path: Path | None, now: datetime, ttl: timedelta) -> EuvdCatalogue | None:
    if path is None or not path.is_file():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        fetched = datetime.fromisoformat(data["fetched_at"])
        if data.get("schema") != CACHE_SCHEMA or now - fetched > ttl:
            return None
        entries = [EuvdEntry(e["id"], tuple(e["cves"]), e.get("since")) for e in data["entries"]]
    except (OSError, ValueError, KeyError, TypeError):
        return None
    return _catalogue(entries, fetched, from_cache=True)


def _write_cache(path: Path | None, entries: list[EuvdEntry], fetched: datetime) -> None:
    if path is None:
        return
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        payload = {"schema": CACHE_SCHEMA, "fetched_at": fetched.isoformat(),
                   "entries": [{"id": e.euvd_id, "cves": list(e.cve_ids), "since": e.exploited_since}
                               for e in entries]}
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(payload), encoding="utf-8")
        tmp.replace(path)
    except OSError:
        pass


def euvd_matches(finding: Finding, catalogue: EuvdCatalogue) -> list[EuvdEntry]:
    seen: dict[str, EuvdEntry] = {}
    for cve in finding.cve_ids:
        for entry in catalogue.entries.get(cve, []):
            seen.setdefault(entry.euvd_id, entry)
    return list(seen.values())
