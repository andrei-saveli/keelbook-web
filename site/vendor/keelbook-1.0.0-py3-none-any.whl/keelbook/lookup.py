"""Decide, per component, which vulnerability source can check it, and run the lookups.

* purl that OSV understands (npm, PyPI, Maven, Alpine, ...)  -> OSV
* otherwise a usable CPE (Yocto, Buildroot, Zephyr, ...)      -> NVD, and the CVE List if asked
* neither                                                     -> NOT checked, with the reason

NVD and the CVE List both check CPE components: the CVE List adds CVEs that NVD
has not analysed yet. The same CVE found by both is shown once ("NVD + CVE List").
"""

from __future__ import annotations

from dataclasses import replace
from typing import Callable

from keelbook.cpe import ANY, unescape
from keelbook.cvelist import UNKNOWN, CveListIndex
from keelbook.errors import VulnLookupError
from keelbook.models import Component
from keelbook.nvd import CpeGroup, NvdClient, assess, matched_vendors, obviously_same, plan_cpe_lookups
from keelbook.severity import Severity, from_cached, label_for
from keelbook.vulns import Finding, clean_summary, HttpFn, LookupResult, build_queries, check_vulnerabilities, default_http

ProgressFn = Callable[[str], None]


def split_by_source(
    components: list[Component], use_nvd: bool, use_cvelist: bool = False
) -> tuple[list[Component], list[CpeGroup], dict[str, int]]:
    """(components for OSV, CPE groups for NVD / CVE List, skip reasons -> count)."""
    use_cpe = use_nvd or use_cvelist
    osv: list[Component] = []
    cpe_components: list[Component] = []
    skipped: dict[str, int] = {}

    def skip(reason: str) -> None:
        skipped[reason] = skipped.get(reason, 0) + 1

    for component in components:
        _, reason = build_queries(component)
        if reason is None:
            osv.append(component)
        elif component.cpe and use_cpe:
            cpe_components.append(component)
        elif component.cpe:
            skip("has a CPE, but NVD lookup is turned off")
        elif reason.startswith("ecosystem"):
            skip(f"{reason} and no CPE")
        else:
            skip(reason)
    groups, cpe_skips = plan_cpe_lookups(cpe_components)
    for reason, count in cpe_skips.items():
        skipped[reason] = skipped.get(reason, 0) + count
    return osv, groups, skipped


def run_lookup(
    components: list[Component],
    nvd: NvdClient | None,
    osv_http: HttpFn = default_http,
    progress: ProgressFn | None = None,
    cvelist: CveListIndex | None = None,
    offline: bool = False,
) -> LookupResult:
    """Look up every component in the source(s) that can check it.

    offline: no network. OSV has no saved copy, so its components are NOT checked;
    NVD uses saved answers only (see NvdClient.offline)."""
    osv_components, groups, skipped = split_by_source(
        components, use_nvd=nvd is not None, use_cvelist=cvelist is not None)
    result = LookupResult(skipped=dict(skipped), offline=offline)

    if osv_components and offline:
        reason = "offline: OSV is only available online"
        result.skipped[reason] = result.skipped.get(reason, 0) + len(osv_components)
    elif osv_components:
        if progress:
            progress(f"Querying OSV for {len(osv_components)} component(s)...")
        osv = check_vulnerabilities(osv_components, http=osv_http)
        result.findings.extend(osv.findings)
        result.checked += osv.checked
        result.details_failed += osv.details_failed
        result.checked_by["OSV"] = osv.checked
        for reason, count in osv.skipped.items():
            result.skipped[reason] = result.skipped.get(reason, 0) + count

    if groups:
        nvd_checked = cvelist_checked = cpe_checked = 0
        for number, group in enumerate(groups, 1):
            ok = False
            nvd_failed = False
            if nvd is not None:
                if progress:
                    progress(f"Querying NVD by CPE {number}/{len(groups)}: {group.cpe.label()}")
                try:
                    records = nvd.cves_for(group.match_string)
                except VulnLookupError:
                    nvd_failed = True
                else:
                    ok = True
                    nvd_checked += len(group.components)
                    result.findings.extend(_findings_for_group(group, records, result))
            if cvelist is not None:
                result.findings.extend(_cvelist_findings(group, cvelist, result))
                cvelist_checked += len(group.components)
                ok = True
            reason = "offline: no saved NVD answer" if offline else "NVD lookup failed"
            if ok:
                cpe_checked += len(group.components)
                if nvd_failed:
                    result.nvd_missed[reason] = result.nvd_missed.get(reason, 0) + len(group.components)
            else:
                result.skipped[reason] = result.skipped.get(reason, 0) + len(group.components)
        result.checked += cpe_checked
        if nvd is not None:
            result.checked_by["NVD"] = nvd_checked
            result.nvd_requests = nvd.requests
            result.nvd_cache_hits = nvd.cache_hits
            if nvd.oldest_data is not None:
                result.nvd_oldest_data = nvd.oldest_data.replace(microsecond=0).isoformat()
        if cvelist is not None:
            result.checked_by["CVE List"] = cvelist_checked
            result.cvelist_label = cvelist.label()

    result.findings, result.merged_duplicates = merge_duplicates(result.findings)
    result.findings.sort(key=lambda f: (f.component.name.lower(), f.vuln_id))
    return result


def merge_duplicates(findings: list[Finding]) -> tuple[list[Finding], int]:
    """One finding per (component name, version, vulnerability).

    Yocto SBOMs sometimes list one package several times under different CPE
    vendors (curl as haxx:curl, daniel_stenberg:curl and curl:curl). Each is
    looked up, so the same CVE would otherwise appear several times. The merged
    finding keeps every CPE it matched, the best fixed-in data and the worst
    severity.
    """
    merged: dict[tuple, Finding] = {}
    duplicates = 0
    for finding in findings:
        key = (finding.component.name.lower(), finding.component.version, finding.vuln_id)
        kept = merged.get(key)
        if kept is None:
            merged[key] = finding
            continue
        duplicates += 1
        matched = "; ".join(dict.fromkeys(m for m in (kept.matched_as, finding.matched_as) if m)) or None
        also = tuple(sorted({*kept.also_in, *finding.also_in} - {kept.component.name}))
        severities = [s for s in (kept.severity, finding.severity) if s is not None]
        # The CVE record's own fix version wins: for the kernel it names the fix in
        # the same stable line (6.12.50), where NVD's ranges often point elsewhere.
        if finding.source == "CVE List" and finding.fixed_in:
            fixed = finding.fixed_in
        else:
            fixed = kept.fixed_in or finding.fixed_in
        sources = " + ".join(dict.fromkeys(s for f in (kept, finding) for s in f.source.split(" + ")))
        if finding.source not in kept.source.split(" + "):
            duplicates -= 1  # found by a second source: one finding, not a duplicate CPE
        summary = kept.summary or finding.summary
        merged[key] = replace(
            kept, matched_as=matched, also_in=also, fixed_in=fixed, source=sources, summary=summary,
            program_files=kept.program_files or finding.program_files,
            # Confirmed if any of the matching CPEs named the vendor itself.
            vendor_unconfirmed=kept.vendor_unconfirmed if finding.vendor_unconfirmed else (),
            fix_note=None if fixed else (kept.fix_note or finding.fix_note),
            severity=max(severities, key=lambda s: s.sort_key()) if severities else None,
        )
    return list(merged.values()), duplicates


def _findings_for_group(group: CpeGroup, records: list[dict], result: LookupResult) -> list[Finding]:
    first, *others = sorted(group.components, key=lambda c: (len(c.name), c.name))
    label = f"{unescape(group.cpe.vendor)}:{unescape(group.cpe.product)} {group.version}"
    findings = []
    for record in records:
        keep, fixed, note = assess(record, group.cpe, group.version)
        if not keep:
            result.nvd_platform_only += 1
            continue
        summary = record.get("summary")
        if isinstance(summary, str):
            summary = clean_summary(" ".join(summary.split()))  # NVD texts contain line breaks
            if len(summary) > 160:
                summary = summary[:157] + "..."
        vendors = matched_vendors(record, group.cpe) if group.cpe.vendor == ANY else ()
        to_check = tuple(v for v in vendors if not obviously_same(v, group.cpe.product))
        findings.append(Finding(
            component=first,
            vuln_id=record["id"],
            summary=summary,
            fixed_in=(fixed,) if fixed else (),
            source="NVD",
            also_in=tuple(c.name for c in others),
            matched_as=label + (f" (NVD vendor: {', '.join(vendors)})" if vendors else ""),
            severity=from_cached(record.get("cvss")),
            fix_note=note,
            vendor_unconfirmed=to_check,
        ))
    return findings


def _cvelist_findings(group: CpeGroup, cvelist: CveListIndex, result: LookupResult) -> list[Finding]:
    first, *others = sorted(group.components, key=lambda c: (len(c.name), c.name))
    label = f"{unescape(group.cpe.vendor)}:{unescape(group.cpe.product)} {group.version}"
    findings = []
    unknown = []
    for match in cvelist.matches(group.cpe, group.version):
        if match.status == UNKNOWN:
            unknown.append(match.cve)
            continue
        vendors = match.vendors if group.cpe.vendor == ANY else ()
        to_check = tuple(v for v in vendors if not obviously_same(v, group.cpe.product))
        severity = (Severity(match.score, label_for(match.score), match.cvss_version, "CVE List")
                    if match.score is not None else None)
        findings.append(Finding(
            component=first,
            vuln_id=match.cve,
            summary=match.summary,
            fixed_in=(match.fixed_in,) if match.fixed_in else (),
            source="CVE List",
            also_in=tuple(c.name for c in others),
            matched_as=label + (f" (CVE record vendor: {', '.join(vendors)})" if vendors else ""),
            severity=severity,
            fix_note=match.fix_note,
            vendor_unconfirmed=to_check,
            program_files=match.files,
        ))
    if unknown:
        result.cvelist_unknown[f"{first.name} {group.version}"] = unknown
    return findings
