"""The official CVE List (CVE JSON 5, "CNA data") as a second source next to NVD.

Why: NVD adds product data (CPE configurations) to a CVE only after its own
analysis, and has a large backlog (status "Deferred", "Awaiting Analysis").
A lookup by CPE at NVD cannot find those CVEs. The CVE record itself, written by
the CNA (e.g. OpenSSL, the Linux kernel team), usually names the affected product
and versions from day one.

How: the whole list (about 400,000 records) is downloaded once from the CVE
Project's GitHub releases, or read from a folder, and condensed into a local
SQLite index in the user's cache folder. A scan then reads only the entries for
its own product names. Nothing about the SBOM is sent anywhere.

Version rules follow the CVE JSON 5 schema: a "versions" entry is one version or
a range (version .. lessThan / lessThanOrEqual, "6.6.*" = the whole 6.6 line);
if no entry matches, "defaultStatus" applies. When a record lists the affected
versions without a defaultStatus and ours is not among them, the record is read
as "not affected". Entries we cannot compare (git commit ranges only, or text we
cannot parse) give "unknown": counted and shown, never treated as clean.
"""

from __future__ import annotations

import functools
import io
import json
import os
import re
import shutil
import sqlite3
import tempfile
import urllib.request
import zipfile
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable, Iterable, Iterator

from keelbook import __version__
from keelbook.cpe import ANY, Cpe, parse_cpe, unescape
from keelbook.errors import VulnLookupError
from keelbook.vulns import NO_FIX_RECORDED, parse_version

INDEX_SCHEMA = "1"
REFRESH_AFTER = timedelta(days=7)
RELEASES_URL = "https://api.github.com/repos/CVEProject/cvelistV5/releases/latest"
ASSET_SUFFIX = "_all_CVEs_at_midnight.zip.zip"
TIMEOUT_SECONDS = 120

AFFECTED, UNAFFECTED, UNKNOWN = "affected", "unaffected", "unknown"

# CNA product names that differ from the CPE product names in SBOMs.
# Key: normalised CNA product (or "vendor/product"); value: normalised CPE product.
PRODUCT_ALIASES = {
    "linux/linux": "linuxkernel",
    "linux/kernel": "linuxkernel",
    "linux/linuxkernel": "linuxkernel",
    "gnuclibrary": "glibc",
    "gnucompilercollection": "gcc",
    "gnubinutils": "binutils",
    "gnubash": "bash",
}


def norm(text: Any) -> str:
    """'OpenSSL' -> 'openssl', 'util-linux' -> 'utillinux', 'linux_kernel' -> 'linuxkernel'."""
    if isinstance(text, (dict, list)):  # malformed record: no name
        return ""
    return re.sub(r"[^a-z0-9]", "", str(text or "").lower())


def default_index_file() -> Path:
    from keelbook.nvd import cache_root
    return cache_root() / "cvelist-index.sqlite"


# --- reading the CVE List ------------------------------------------------------


def iter_dir(folder: Path) -> Iterator[dict[str, Any]]:
    """CVE records from a folder, e.g. a git clone of github.com/CVEProject/cvelistV5."""
    for dirpath, _, files in os.walk(folder):
        for name in files:
            if name.startswith("CVE-") and name.endswith(".json"):
                try:
                    with open(os.path.join(dirpath, name), encoding="utf-8") as fh:
                        yield json.load(fh)
                except (OSError, ValueError):
                    continue


def iter_zip(path: Path) -> Iterator[dict[str, Any]]:
    """CVE records from the release archive. The official file is a zip that
    contains another zip (cves.zip); a plain zip of CVE files works too."""
    with zipfile.ZipFile(path) as outer:
        inner_names = [n for n in outer.namelist() if n.endswith(".zip")]
        if inner_names:
            with tempfile.TemporaryDirectory() as tmp:
                inner_path = Path(tmp) / "inner.zip"
                with outer.open(inner_names[0]) as src, open(inner_path, "wb") as dst:
                    shutil.copyfileobj(src, dst, 1 << 20)
                yield from iter_zip(inner_path)
            return
        for name in outer.namelist():
            base = name.rsplit("/", 1)[-1]
            if base.startswith("CVE-") and base.endswith(".json"):
                try:
                    yield json.loads(outer.read(name).decode("utf-8"))
                except ValueError:
                    continue


# --- condensing one record ----------------------------------------------------


def _obj(value: Any) -> dict[str, Any]:
    """The value if it is a JSON object, else an empty one (records can be malformed)."""
    return value if isinstance(value, dict) else {}


def _objs(value: Any) -> list[dict[str, Any]]:
    """The JSON objects in a list; anything else is ignored."""
    return [v for v in value if isinstance(v, dict)] if isinstance(value, list) else []


def _strs(value: Any) -> list[str]:
    return [v for v in value if isinstance(v, str)] if isinstance(value, list) else []


def _product_keys(entry: dict[str, Any]) -> set[str]:
    vendor, product = norm(entry.get("vendor")), norm(entry.get("product"))
    keys = set()
    package = norm(entry.get("packageName"))
    distro = any(v.get("versionType") in ("rpm", "deb") for v in _objs(entry.get("versions")))
    if package and not distro:
        keys.add(package)
    if product and product not in ("na", "unknown", "unspecified"):
        keys.add(PRODUCT_ALIASES.get(f"{vendor}/{product}", PRODUCT_ALIASES.get(product, product)))
    for text in _strs(entry.get("cpes")):
        cpe = parse_cpe(text)
        if cpe is not None and cpe.product not in (ANY, "-"):
            keys.add(norm(unescape(cpe.product)))
    return keys


def _vendor_names(entry: dict[str, Any]) -> list[str]:
    """Vendor names, once each ('Red Hat' and the CPE's 'redhat' are the same)."""
    names = []
    vendor = entry.get("vendor") if isinstance(entry.get("vendor"), str) else ""
    vendor = vendor.strip()
    if vendor and norm(vendor) not in ("na", "unknown"):
        names.append(vendor)
    for text in _strs(entry.get("cpes")):
        cpe = parse_cpe(text)
        if cpe is not None and cpe.vendor not in (ANY, "-"):
            names.append(unescape(cpe.vendor))
    seen, out = set(), []
    for name in names:
        if norm(name) not in seen:
            seen.add(norm(name))
            out.append(name)
    return out


def _condense_entry(entry: dict[str, Any]) -> dict[str, Any] | None:
    versions = []
    git_only = False
    raw = _objs(entry.get("versions"))
    for v in raw:
        if v.get("versionType") == "git":
            continue
        versions.append([v.get("version"), v.get("lessThan"), v.get("lessThanOrEqual"),
                         v.get("status"), v.get("versionType")])
    if raw and not versions:
        git_only = True  # only commit ranges: we cannot compare a version number with them
    default = entry.get("defaultStatus")
    if not versions and default not in (AFFECTED, UNAFFECTED) and not git_only:
        default = UNKNOWN
    return {
        "vendors": _vendor_names(entry),
        "default": UNKNOWN if git_only else default,
        "versions": versions,
        "files": _strs(entry.get("programFiles"))[:50],
        "git_only": git_only,
    }


def _summary(cna: dict[str, Any]) -> str | None:
    for d in _objs(cna.get("descriptions")):
        if str(d.get("lang", "")).lower().startswith("en") and d.get("value"):
            text = " ".join(str(d["value"]).split())
            return text[:197] + "..." if len(text) > 200 else text
    title = cna.get("title")
    return str(title)[:200] if isinstance(title, str) and title else None


def _severity(containers: dict[str, Any]) -> tuple[float, str] | None:
    """(base score, CVSS version) from the CNA, else from an ADP such as CISA."""
    sources = [_obj(containers.get("cna"))] + _objs(containers.get("adp"))
    for source in sources:
        for metric in _objs(source.get("metrics")):
            for key, version in (("cvssV4_0", "4.0"), ("cvssV3_1", "3.1"), ("cvssV3_0", "3.0")):
                data = metric.get(key)
                if isinstance(data, dict) and isinstance(data.get("baseScore"), (int, float)):
                    return float(data["baseScore"]), version
    return None


def condense(record: dict[str, Any]) -> tuple[dict[str, Any], list[tuple[str, dict[str, Any]]]] | None:
    """(CVE row, [(product key, entry)]) for a published record, else None."""
    """Malformed parts are ignored: one bad record must never stop an index build."""
    meta = _obj(_obj(record).get("cveMetadata"))
    cve_id = meta.get("cveId")
    if meta.get("state") != "PUBLISHED" or not isinstance(cve_id, str) or not cve_id:
        return None
    containers = _obj(record.get("containers"))
    cna = _obj(containers.get("cna"))
    by_product: dict[str, list[dict[str, Any]]] = {}
    for entry in _objs(cna.get("affected")):
        condensed = _condense_entry(entry)
        for key in _product_keys(entry):
            by_product.setdefault(key, []).append(condensed)
    if not by_product:
        return None
    rows = []
    for key, entries in by_product.items():
        # The kernel team writes each range twice: as git commits and as versions.
        # Keep the commit-only entries only if nothing comparable exists.
        comparable = [e for e in entries if not e["git_only"]]
        for entry in comparable or entries:
            rows.append((key, entry))
    sev = _severity(containers)
    cve = {
        "id": cve_id,
        "published": str(meta.get("datePublished") or "")[:10],
        "summary": _summary(cna),
        "score": sev[0] if sev else None,
        "cvss_version": sev[1] if sev else None,
    }
    return cve, rows


# --- the local index ------------------------------------------------------------


def build_index(records: Iterable[dict[str, Any]], dest: Path, source: str,
                progress: Callable[[int], None] | None = None) -> int:
    """Write a new index to `dest` (atomically). Returns the number of CVEs kept."""
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix(".building")
    if tmp.exists():
        tmp.unlink()
    db = sqlite3.connect(tmp)
    try:
        db.executescript(
            "CREATE TABLE meta (key TEXT PRIMARY KEY, value TEXT);"
            "CREATE TABLE cves (id TEXT PRIMARY KEY, published TEXT, summary TEXT, score REAL, cvss_version TEXT);"
            "CREATE TABLE entries (product TEXT, cve TEXT, entry TEXT);"
        )
        kept = seen = unreadable = 0
        for record in records:
            seen += 1
            if progress and seen % 20000 == 0:
                progress(seen)
            try:
                condensed = condense(record)
            except Exception:  # a record shape nobody expected: count it, keep building
                unreadable += 1
                continue
            if condensed is None:
                continue
            cve, rows = condensed
            db.execute("INSERT OR REPLACE INTO cves VALUES (?, ?, ?, ?, ?)",
                       (cve["id"], cve["published"], cve["summary"], cve["score"], cve["cvss_version"]))
            db.executemany("INSERT INTO entries VALUES (?, ?, ?)",
                           [(key, cve["id"], json.dumps(entry, separators=(",", ":"))) for key, entry in rows])
            kept += 1
        if seen == 0:
            raise VulnLookupError("The CVE List source contained no CVE records.")
        db.execute("CREATE INDEX entries_product ON entries (product)")
        built = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
        db.executemany("INSERT INTO meta VALUES (?, ?)", [
            ("schema", INDEX_SCHEMA), ("built", built), ("source", source),
            ("records", str(seen)), ("kept", str(kept)), ("unreadable", str(unreadable)),
            ("tool", f"keelbook {__version__}"),
        ])
        db.commit()
    finally:
        db.close()
    os.replace(tmp, dest)
    return kept


# --- downloading ------------------------------------------------------------------

JsonFn = Callable[[str], dict[str, Any]]
DownloadFn = Callable[[str, Path], None]


def _get_json(url: str) -> dict[str, Any]:
    request = urllib.request.Request(url, headers={
        "User-Agent": f"keelbook/{__version__}", "Accept": "application/vnd.github+json"})
    try:
        with urllib.request.urlopen(request, timeout=TIMEOUT_SECONDS) as response:
            return json.load(response)
    except Exception as exc:  # network, HTTP or JSON problem
        raise VulnLookupError(f"Could not reach the CVE List releases on GitHub ({exc}).") from exc


def _download(url: str, dest: Path) -> None:
    request = urllib.request.Request(url, headers={"User-Agent": f"keelbook/{__version__}"})
    try:
        with urllib.request.urlopen(request, timeout=TIMEOUT_SECONDS) as response, open(dest, "wb") as out:
            shutil.copyfileobj(response, out, 1 << 20)
    except Exception as exc:
        raise VulnLookupError(f"Could not download the CVE List ({exc}).") from exc


def latest_release(get_json: JsonFn = _get_json) -> tuple[str, str, int]:
    """(release name, download URL, size in bytes) of the newest full CVE List archive."""
    release = get_json(RELEASES_URL)
    for asset in release.get("assets") or []:
        if str(asset.get("name", "")).endswith(ASSET_SUFFIX):
            return str(release.get("name") or asset["name"]), asset["browser_download_url"], int(asset.get("size") or 0)
    raise VulnLookupError("The latest CVE List release on GitHub has no full archive (*" + ASSET_SUFFIX + ").")


def download_and_build(dest: Path, get_json: JsonFn = _get_json, download: DownloadFn = _download,
                       progress: Callable[[str], None] | None = None) -> int:
    name, url, size = latest_release(get_json)
    if progress:
        progress(f"Downloading the CVE List ({name}, {size / 1e6:.0f} MB)...")
    with tempfile.TemporaryDirectory() as tmp:
        archive = Path(tmp) / "cvelist.zip"
        download(url, archive)
        if progress:
            progress("Building the local CVE List index (a few minutes)...")
        return build_index(iter_zip(archive), dest, source=f"CVE List release {name}",
                           progress=(lambda n: progress(f"Indexed {n:,} CVE records...")) if progress else None)


# --- matching -----------------------------------------------------------------------


@dataclass
class Match:
    cve: str
    status: str  # affected or unknown
    fixed_in: str | None
    fix_note: str | None
    summary: str | None
    score: float | None
    cvss_version: str | None
    vendors: tuple[str, ...]
    files: tuple[str, ...]


@dataclass
class CveListIndex:
    path: Path
    meta: dict[str, str] = field(default_factory=dict)

    @classmethod
    def open(cls, path: Path) -> "CveListIndex":
        if not path.exists():
            raise VulnLookupError(f"No CVE List index at {path}. Run 'keelbook update-db'.")
        db = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
        try:
            meta = dict(db.execute("SELECT key, value FROM meta").fetchall())
        except sqlite3.Error as exc:
            raise VulnLookupError(f"The CVE List index at {path} is unreadable ({exc}). "
                                  "Run 'keelbook update-db'.") from exc
        finally:
            db.close()
        if meta.get("schema") != INDEX_SCHEMA:
            raise VulnLookupError("The CVE List index was made by another Keelbook version. Run 'keelbook update-db'.")
        return cls(path, meta)

    @property
    def built(self) -> datetime | None:
        try:
            return datetime.fromisoformat(self.meta["built"])
        except (KeyError, ValueError):
            return None

    def is_stale(self, now: datetime | None = None) -> bool:
        built = self.built
        return built is None or (now or datetime.now(timezone.utc)) - built > REFRESH_AFTER

    def label(self) -> str:
        when = self.meta.get("built", "")[:10] or "unknown date"
        return f"CVE List {when}"

    def matches(self, cpe: Cpe, version: str) -> list[Match]:
        """Affected or undeterminable CVEs for one CPE product + version."""
        product = norm(unescape(cpe.product))
        product = PRODUCT_ALIASES.get(product, product)
        db = sqlite3.connect(f"file:{self.path}?mode=ro", uri=True)
        try:
            rows = db.execute(
                "SELECT e.cve, e.entry, c.summary, c.score, c.cvss_version FROM entries e "
                "JOIN cves c ON c.id = e.cve WHERE e.product = ?", (product,)).fetchall()
        finally:
            db.close()
        per_cve: dict[str, list] = {}
        for cve, entry, summary, score, cvss_version in rows:
            per_cve.setdefault(cve, []).append((json.loads(entry), summary, score, cvss_version))
        wanted_vendor = norm(unescape(cpe.vendor)) if cpe.vendor != ANY else ""
        out = []
        for cve, items in per_cve.items():
            if wanted_vendor:
                items = [i for i in items if _vendor_fits(wanted_vendor, i[0]["vendors"])] or []
                if not items:
                    continue
            results = [(status_for(i[0], version), i) for i in items]
            affected = [(r, i) for r, i in results if r[0] == AFFECTED]
            unknown = [(r, i) for r, i in results if r[0] == UNKNOWN]
            chosen = affected or unknown
            if not chosen:
                continue
            (status, fixed), (entry, summary, score, cvss_version) = chosen[0]
            fixes = [r[1] for r, _ in affected if r[1]]
            fixed = min(fixes, key=parse_version) if fixes else None
            out.append(Match(
                cve=cve, status=status, fixed_in=fixed,
                fix_note=None if fixed else NO_FIX_RECORDED,
                summary=summary, score=score, cvss_version=cvss_version,
                vendors=tuple(dict.fromkeys(v for _, i in chosen for v in i[0]["vendors"])),
                files=tuple(dict.fromkeys(f for _, i in chosen for f in i[0]["files"])),
            ))
        out.sort(key=lambda m: m.cve)
        return out


def _vendor_fits(wanted: str, vendors: list[str]) -> bool:
    keys = [norm(v) for v in vendors]
    if not keys:
        return True  # the record names no vendor: product name decides
    return any(k == wanted or k.startswith(wanted) or wanted.startswith(k) or wanted in k for k in keys if k)


# --- version rules (CVE JSON 5) ----------------------------------------------------

_CONSTRAINT = re.compile(r"^\s*(>=|<=|>|<|=|before|prior to|up to|from)\s*(v?\d[\w.+~-]*)\s*$", re.IGNORECASE)
_ALL_VERSIONS = {"*", "all", "all versions"}


def _parse(text: Any) -> tuple | None:
    if text is None:
        return None
    return _parse_text(str(text).strip())


@functools.lru_cache(maxsize=65536)
def _parse_text(text: str) -> tuple | None:
    if re.match(r"^\d{4}-\d{2}-\d{2}", text):
        return None  # a date, not a version: cannot be compared
    return parse_version(re.sub(r"\+git.*$", "", text))


def _line(text: str) -> tuple[int, ...] | None:
    """'6.6.*' -> (6, 6); None if it is not plain numbers."""
    parts = text.strip()[:-2].lstrip("v").split(".")
    return tuple(int(p) for p in parts) if parts and all(p.isdigit() for p in parts) else None


def _in_line(installed: tuple, prefix: tuple[int, ...]) -> bool:
    """Is the installed version in that release line? (6.6.20 is in (6, 6); 6.0.5 in (6, 0))."""
    numbers = tuple(installed[0]) + (0,) * len(prefix)
    return numbers[: len(prefix)] == prefix


def _in_range(start: Any, lt: Any, lte: Any, installed: tuple) -> bool | None:
    """True/False, or None if the bounds cannot be compared."""
    if start is None or str(start).strip().lower() in _ALL_VERSIONS | {"0"}:
        low = None
    else:
        low = _parse(start)
        if low is None:
            return None
    if low is not None and installed < low:
        return False
    if lt is not None:
        if str(lt).strip() == "*":
            return True
        high = _parse(lt)
        return None if high is None else installed < high
    if lte is not None:
        text = str(lte).strip()
        if text == "*":
            return True
        if text.endswith(".*"):  # "6.6.*": anything in the 6.6 line
            prefix = _line(text)
            if prefix is None:
                return None
            return _in_line(installed, prefix) or installed < _parse(".".join(map(str, prefix)))
        high = _parse(text)
        return None if high is None else installed <= high
    return None  # caller handles single versions


def _constraints(text: str) -> list[tuple[str, str]] | None:
    """'>= 2.39, < 2.41.5' -> [('>=', '2.39'), ('<', '2.41.5')]; None if it is not that form."""
    parts = [p for p in re.split(r",|\band\b", text) if p.strip()]
    out = []
    for part in parts:
        m = _CONSTRAINT.match(part)
        if not m:
            return None
        op = {"before": "<", "prior to": "<", "up to": "<=", "from": ">="}.get(m.group(1).lower(), m.group(1))
        out.append((op, m.group(2)))
    return out or None


def _check_constraints(constraints: list[tuple[str, str]], installed: tuple) -> tuple[bool | None, str | None]:
    """(all constraints hold? None if a bound cannot be compared, the '<' bound = fixed-in)."""
    fixed = None
    for op, value in constraints:
        bound = _parse(value)
        if bound is None:
            return None, None
        ok = {">=": installed >= bound, ">": installed > bound, "<": installed < bound,
              "<=": installed <= bound, "=": installed == bound}[op]
        if not ok:
            return False, None
        if op == "<":
            fixed = value
    return True, fixed


def status_for(entry: dict[str, Any], version: str) -> tuple[str, str | None]:
    """(affected / unaffected / unknown, fixed-in version or None) for one entry."""
    installed = _parse(version)
    if entry.get("git_only") or installed is None:
        return UNKNOWN, None
    matched: list[tuple[tuple, str, Any]] = []  # (start, status, lessThan)
    unclear = False
    for start, lt, lte, status, vtype in entry.get("versions") or []:
        if status not in (AFFECTED, UNAFFECTED):
            continue
        if vtype in ("date", "git", "patch"):
            unclear = True  # not version numbers
            continue
        text = str(start or "").strip()
        if lt is None and lte is None:
            constraints = _constraints(text)
            if constraints is not None:  # "< 2.4.1", ">= 2.39, < 2.41.5", "before 2.4.1": a range as text
                hit, bound = _check_constraints(constraints, installed)
                if hit is None:
                    unclear = True
                elif hit:
                    matched.append(((), status, bound))
                continue
            if text.lower() in _ALL_VERSIONS:
                matched.append(((), status, None))
                continue
            single = _parse(text)
            if single is None:
                unclear = True
            elif single == installed:
                matched.append((single, status, None))
            continue
        hit = _in_range(start, lt, lte, installed)
        if hit is None:
            unclear = True
        elif hit:
            matched.append((_parse(start) or (), status, lt))
    if matched:
        start, status, lt = max(matched, key=lambda m: (m[0], m[1] == AFFECTED))
        if status == UNAFFECTED:
            return UNAFFECTED, None
        fixed = str(lt) if lt not in (None, "*") and _parse(lt) else None
        return AFFECTED, fixed or _next_fix(entry, installed)
    if unclear:
        return UNKNOWN, None
    default = entry.get("default")
    if default == AFFECTED:
        return AFFECTED, _next_fix(entry, installed)
    if default == UNKNOWN and not entry.get("versions"):
        return UNKNOWN, None
    return UNAFFECTED, None  # listed versions do not include ours


def _next_fix(entry: dict[str, Any], installed: tuple) -> str | None:
    """The first unaffected version after ours: in our own line if the record has one
    (kernel stable branches: '6.12.50' for 6.12.49), else the next line that is fixed."""
    same_line, later = [], []
    for start, lt, lte, status, _vtype in entry.get("versions") or []:
        if status != UNAFFECTED or lt is not None:
            continue
        begin = _parse(start)
        if begin is None or begin <= installed:
            continue
        text = str(lte or "").strip()
        if text.endswith(".*"):
            prefix = _line(text)
            if prefix and _in_line(installed, prefix):
                same_line.append(str(start))
                continue
        later.append(str(start))
    for candidates in (same_line, later):
        if candidates:
            return min(candidates, key=_parse)
    return None
