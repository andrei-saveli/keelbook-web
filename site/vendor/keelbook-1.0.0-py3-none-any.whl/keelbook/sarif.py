"""SARIF 2.1.0 output for CI systems (GitHub code scanning, GitLab, Azure DevOps, ...).

One result per finding, located in the SBOM file (the only file Keelbook reads).
Rules are vulnerabilities; "security-severity" carries the CVSS score so GitHub
can rank alerts. Unknown severity is reported as a warning, never as a note.
Findings the producer marked fixed / not affected are kept, with a SARIF
"suppression" that names the statement: visible, not hidden.
The run's properties state what was NOT checked, so an empty result list never
reads as "clean" by itself.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from keelbook import __version__
from keelbook.euvd import EuvdCatalogue
from keelbook.kev import KevCatalogue
from keelbook.report import candidate_sources, ordered
from keelbook.vex import is_resolved
from keelbook.vulns import Finding, LookupResult

SCHEMA = "https://json.schemastore.org/sarif-2.1.0.json"
INFO_URI = "https://github.com/andrei-saveli/keelbook"


def _level(finding: Finding, exploited: bool) -> str:
    if exploited:
        return "error"
    sev = finding.severity
    if sev is None:
        return "warning"  # unknown is not "low"
    if sev.label in ("critical", "high"):
        return "error"
    if sev.label == "medium":
        return "warning"
    return "note"


def _help_uri(vuln_id: str) -> str:
    if vuln_id.upper().startswith("CVE-"):
        return f"https://nvd.nist.gov/vuln/detail/{vuln_id.upper()}"
    return f"https://osv.dev/vulnerability/{vuln_id}"


def sarif_document(lookup: LookupResult, sbom_uri: str, total_components: int,
                   kev: KevCatalogue | None = None, euvd: EuvdCatalogue | None = None,
                   sources: list[str] | None = None) -> dict[str, Any]:
    rules: dict[str, dict[str, Any]] = {}
    results = []
    for f in ordered(lookup.findings, kev, euvd):
        lists = candidate_sources(f, kev, euvd)
        if f.vuln_id not in rules:
            rule: dict[str, Any] = {
                "id": f.vuln_id,
                "shortDescription": {"text": f"{f.vuln_id}: {f.summary}" if f.summary else f.vuln_id},
                "helpUri": _help_uri(f.vuln_id),
                "properties": {"tags": ["security", "vulnerability"]},
            }
            if f.severity is not None and f.severity.score is not None:
                rule["properties"]["security-severity"] = f"{f.severity.score:.1f}"
            rules[f.vuln_id] = rule
        component = f"{f.component.name} {f.component.version or '-'}"
        text = f"{component} is affected by {f.vuln_id}"
        if f.cve_ids and f.cve_ids != (f.vuln_id,):
            text += f" ({', '.join(f.cve_ids)})"
        text += f". Severity: {f.severity.text() if f.severity else 'unknown'}. Fixed in: {f.fixed_text}."
        if lists:
            text += f" Listed as exploited in {', '.join(lists)} (a candidate for CRA Art. 14; a person decides)."
        text += f" Source: {f.source}."
        result: dict[str, Any] = {
            "ruleId": f.vuln_id,
            "level": _level(f, bool(lists)),
            "message": {"text": text},
            "locations": [{"physicalLocation": {"artifactLocation": {"uri": sbom_uri},
                                                "region": {"startLine": 1}}}],
            "partialFingerprints": {
                "keelbook/v1": f"{f.component.name.lower()}|{f.component.version or ''}|{f.vuln_id}"},
            "properties": {
                "component": f.component.name, "version": f.component.version, "purl": f.component.purl,
                "cpe": f.component.cpe, "source": f.source, "fixedIn": list(f.fixed_in),
                "exploitedLists": lists,
            },
        }
        if is_resolved(f):
            result["suppressions"] = [{"kind": "external", "status": "accepted",
                                       "justification": f"{f.vex_source or 'producer'}: {f.vex_status}"
                                                        + (f" ({f.vex_detail})" if f.vex_detail else "")}]
        results.append(result)
    not_checked = sum(lookup.skipped.values())
    return {
        "$schema": SCHEMA,
        "version": "2.1.0",
        "runs": [{
            "tool": {"driver": {"name": "Keelbook", "version": __version__, "informationUri": INFO_URI,
                                "rules": list(rules.values())}},
            "results": results,
            "properties": {
                "componentsTotal": total_components,
                "componentsChecked": lookup.checked,
                "componentsNotChecked": not_checked,
                "notCheckedReasons": dict(sorted(lookup.skipped.items())),
                "sources": sources or [],
                "note": "Components that were not checked are not clean. Working aid, not legal advice.",
            },
        }],
    }


def write_sarif(path: Path, document: dict[str, Any]) -> None:
    path.write_text(json.dumps(document, indent=1, ensure_ascii=False) + "\n", encoding="utf-8")
