"""Statements by the SBOM producer about vulnerabilities (VEX), and Yocto cve-check.

Yocto often fixes a CVE by applying a patch WITHOUT changing the version number
(a "backport"). A version-based lookup then still lists the CVE. Yocto records
what it knows in two places, both read here:

* its cve-check JSON output (``cve-summary.json``, ``<image>.json``,
  ``*.sbom-cve-check.yocto.json``): per recipe, each CVE is Patched, Unpatched
  or Ignored, with a reason;
* VEX relationships inside its SPDX 3.0 SBOM (parsed in parsers.py).

The tool only SHOWS these statements next to the findings. It never drops a
finding because of them, and it never makes such a statement itself: a person
remains responsible for the assessment.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Any

from keelbook import models
from keelbook.cpe import parse_cpe, unescape
from keelbook.errors import SbomReadError
from keelbook.models import Component, VexStatement
from keelbook.vulns import Finding

YOCTO = "Yocto cve-check"
_YOCTO_STATUS = {"patched": models.FIXED, "ignored": models.NOT_AFFECTED, "unpatched": models.AFFECTED}
# CycloneDX analysis.state -> normalised status (CycloneDX 1.4+ vocabulary).
_CDX_STATUS = {
    "resolved": models.FIXED,
    "resolved_with_pedigree": models.FIXED,
    "not_affected": models.NOT_AFFECTED,
    "false_positive": models.NOT_AFFECTED,
    "exploitable": models.AFFECTED,
    "in_triage": models.UNDER_INVESTIGATION,
}
# When statements disagree, the most cautious one wins.
_PRIORITY = [models.AFFECTED, models.UNDER_INVESTIGATION, models.FIXED, models.NOT_AFFECTED]
_CVE_RE = re.compile(r"CVE-\d{4}-\d{4,}", re.IGNORECASE)


class CveCheckError(SbomReadError):
    """The Yocto cve-check file could not be read or has an unknown layout."""


@dataclass
class YoctoCveCheck:
    statements: list[VexStatement] = field(default_factory=list)
    # Unpatched CVEs as found by Yocto itself: (component, cve, summary)
    unpatched: list[tuple[Component, str, str | None]] = field(default_factory=list)
    packages: int = 0
    counts: dict[str, int] = field(default_factory=dict)  # Yocto status -> count


def _list(value):
    """The value if it is a list, else an empty list (malformed files are skipped, not crashed on)."""
    return value if isinstance(value, list) else []


def load_yocto_cve_check(path: Path) -> YoctoCveCheck:
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
    except FileNotFoundError as exc:
        raise CveCheckError(f"File not found: {path}") from exc
    except (OSError, UnicodeDecodeError) as exc:
        raise CveCheckError(f"Cannot read {path}: {exc}") from exc
    except json.JSONDecodeError as exc:
        raise CveCheckError(f"{path} is not valid JSON: {exc.msg} (line {exc.lineno})") from exc
    packages = data.get("package") if isinstance(data, dict) else None
    if not isinstance(packages, list):
        raise CveCheckError(
            f"{path} does not look like Yocto cve-check output (expected a 'package' list)."
        )

    result = YoctoCveCheck(packages=len(packages))
    for package in packages:
        if not isinstance(package, dict) or not isinstance(package.get("name"), str):
            continue
        name = package["name"].strip()
        version = package.get("version") if isinstance(package.get("version"), str) else None
        targets = {name.lower()}
        for product in _list(package.get("products")):
            if isinstance(product, dict) and isinstance(product.get("product"), str):
                targets.add(product["product"].strip().lower())
        for cpe_text in _list(package.get("cpes")):
            cpe = parse_cpe(cpe_text) if isinstance(cpe_text, str) else None
            if cpe is not None:
                targets.add(unescape(cpe.product).lower())
        for issue in _list(package.get("issue")):
            if not isinstance(issue, dict):
                continue
            cve = issue.get("id")
            raw_status = issue.get("status")
            if not isinstance(cve, str) or not _CVE_RE.fullmatch(cve.strip()) or not isinstance(raw_status, str):
                continue
            cve = cve.strip().upper()
            result.counts[raw_status] = result.counts.get(raw_status, 0) + 1
            status = _YOCTO_STATUS.get(raw_status.strip().lower())
            if status is None:
                continue
            detail = " - ".join(
                str(issue[k]).strip() for k in ("detail", "description")
                if isinstance(issue.get(k), str) and issue[k].strip()
            ) or None
            result.statements.append(VexStatement(cve, status, frozenset(targets), YOCTO, detail))
            if status == models.AFFECTED:
                summary = issue.get("summary") if isinstance(issue.get("summary"), str) else None
                result.unpatched.append((Component(name=name, version=version), cve, summary))
    return result


def cyclonedx_statements(vulnerabilities: list[Any], sbom: models.Sbom, source: str) -> tuple[list[VexStatement], list[str]]:
    """VEX statements from a CycloneDX 'vulnerabilities' list, resolved against `sbom`.

    Each statement names its components by bom-ref, either plain ("abc") or as a
    BOM-Link ("urn:cdx:<serial>/<version>#abc"). Statements whose components
    are not in the SBOM, or whose BOM-Link names a different SBOM, cannot be
    applied: they are counted and reported, never guessed.
    """
    by_ref: dict[str, list[Component]] = {}
    for component in sbom.components:
        if component.ref:
            by_ref.setdefault(component.ref, []).append(component)
    own_serial = (sbom.serial or "").removeprefix("urn:uuid:").lower()

    statements: list[VexStatement] = []
    unknown_refs: set[str] = set()
    other_bom = 0
    unusable = 0
    for vuln in vulnerabilities:
        if not isinstance(vuln, dict):
            unusable += 1
            continue
        analysis = vuln.get("analysis") if isinstance(vuln.get("analysis"), dict) else {}
        status = _CDX_STATUS.get(str(analysis.get("state", "")).strip().lower())
        cve = vuln.get("id")
        if status is None or not isinstance(cve, str) or not _CVE_RE.fullmatch(cve.strip()):
            unusable += 1
            continue
        names: set[str] = set()
        for affected in vuln.get("affects") or []:
            ref = affected.get("ref") if isinstance(affected, dict) else None
            if not isinstance(ref, str):
                continue
            if ref.startswith("urn:cdx:"):
                serial = ref[len("urn:cdx:"):].split("/", 1)[0].lower()
                if own_serial and serial != own_serial:
                    other_bom += 1
                    continue
                ref = ref.split("#", 1)[1] if "#" in ref else ""
            components = by_ref.get(ref)
            if not components:
                unknown_refs.add(ref)
                continue
            for component in components:
                names.add(component.name.lower())
        if not names:
            continue
        parts = [analysis.get("detail"), analysis.get("justification"),
                 ", ".join(r for r in analysis.get("response") or [] if isinstance(r, str))]
        detail = "; ".join(" ".join(p.split()) for p in parts if isinstance(p, str) and p.strip()) or None
        statements.append(VexStatement(cve.strip().upper(), status, frozenset(names), source, detail))

    problems = []
    if unknown_refs:
        problems.append(f"{len(unknown_refs)} VEX component reference(s) are not in the SBOM, so the "
                        "statements about them could not be applied.")
    if other_bom:
        problems.append(f"{other_bom} VEX reference(s) point to a different SBOM (serial number does not "
                        "match) and were not applied. Is this the VEX file for this SBOM?")
    if unusable:
        problems.append(f"{unusable} VEX entr{'y' if unusable == 1 else 'ies'} without a CVE ID or a "
                        "known analysis state were skipped.")
    return statements, problems


def load_cyclonedx_vex(path: Path, sbom: models.Sbom) -> tuple[list[VexStatement], list[str]]:
    """A separate CycloneDX VEX file (as Yocto's cve-check can write), matched to `sbom`."""
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
    except FileNotFoundError as exc:
        raise CveCheckError(f"File not found: {path}") from exc
    except (OSError, UnicodeDecodeError) as exc:
        raise CveCheckError(f"Cannot read {path}: {exc}") from exc
    except json.JSONDecodeError as exc:
        raise CveCheckError(f"{path} is not valid JSON: {exc.msg} (line {exc.lineno})") from exc
    if not isinstance(data, dict) or data.get("bomFormat") != "CycloneDX" or not isinstance(
            data.get("vulnerabilities"), list):
        raise CveCheckError(f"{path} is not a CycloneDX VEX file (expected bomFormat CycloneDX and a "
                            "'vulnerabilities' list).")
    if sbom.format != "CycloneDX":
        raise CveCheckError("A CycloneDX VEX file needs a CycloneDX SBOM: it names components by their "
                            "CycloneDX bom-ref.")
    return cyclonedx_statements(data["vulnerabilities"], sbom, f"CycloneDX VEX ({path.name})")


def _names(finding: Finding) -> set[str]:
    component = finding.component
    names = {component.name.lower(), *(n.lower() for n in finding.also_in)}
    if component.source_package:
        names.add(component.source_package.lower())
    cpe = parse_cpe(component.cpe)
    if cpe is not None:
        names.add(unescape(cpe.product).lower())
    return names


def apply_statements(findings: list[Finding], statements: list[VexStatement]) -> list[Finding]:
    """Attach the most cautious matching statement to each finding (same CVE, same package)."""
    by_cve: dict[str, list[VexStatement]] = {}
    for statement in statements:
        by_cve.setdefault(statement.cve_id, []).append(statement)
    out = []
    for finding in findings:
        names = _names(finding)
        matching = [
            s for cve in finding.cve_ids for s in by_cve.get(cve, []) if s.targets & names
        ]
        if not matching:
            out.append(finding)
            continue
        best = min(matching, key=lambda s: _PRIORITY.index(s.status))
        out.append(replace(finding, vex_status=best.status, vex_detail=best.detail, vex_source=best.source))
    return out


def add_unpatched(findings: list[Finding], report: YoctoCveCheck) -> tuple[list[Finding], int]:
    """Add CVEs Yocto itself lists as Unpatched that the lookup did not find.

    Returns (findings, number added). Nothing Yocto reports is lost this way.
    """
    seen = {(cve, name) for f in findings for cve in f.cve_ids for name in _names(f)}
    added = []
    for component, cve, summary in report.unpatched:
        if (cve, component.name.lower()) in seen:
            continue
        seen.add((cve, component.name.lower()))
        added.append(Finding(
            component=component, vuln_id=cve, summary=summary, source=YOCTO,
            vex_status=models.AFFECTED, vex_source=YOCTO, vex_detail="Unpatched",
        ))
    merged = sorted([*findings, *added], key=lambda f: (f.component.name.lower(), f.vuln_id))
    return merged, len(added)


def is_resolved(finding: Finding) -> bool:
    return finding.vex_status in models.RESOLVED_STATUSES
