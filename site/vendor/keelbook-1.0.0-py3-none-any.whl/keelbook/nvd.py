"""Vulnerability lookup by CPE against the US National Vulnerability Database (NVD).

Used for components that have a CPE but no purl OSV understands: typical for
SBOMs from embedded build systems (Yocto, Buildroot, Zephyr).

What is sent: only the CPE prefix "cpe:2.3:part:vendor:product:version" of
each component (package identity), never source code or the SBOM itself.

How a CVE is kept (checked live against NVD on 2026-11-01):
* NVD's ``virtualMatchString`` search applies version ranges itself
  (openssl 3.0.8 does not return CVE-2023-0286, which was fixed in 3.0.8).
* It also returns CVEs where the product only appears as a platform the
  vulnerable software runs on (``"vulnerable": false``), e.g. CVE-2019-0190 is
  an Apache httpd bug listed with openssl 1.1.1. We therefore keep a CVE only
  if NVD marks THIS product as vulnerable in at least one match entry.
* We do not second-guess NVD's version-range decision. When we can compare
  versions ourselves we use it only to report the fixed-in version.

Rate limits (NVD's published policy): about 5 requests per 30 s without an
API key, 50 per 30 s with one. Results are cached on disk (default 24 hours)
so repeated scans are fast and polite.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable

from keelbook import __version__
from keelbook.cpe import ANY, Cpe, parse_cpe, unescape
from keelbook.errors import VulnLookupError
from keelbook.models import Component
from keelbook.severity import from_nvd_metrics
from keelbook.vulns import CANNOT_COMPARE, NO_FIX_RECORDED, parse_version

NVD_URL = "https://services.nvd.nist.gov/rest/json/cves/2.0"
RESULTS_PER_PAGE = 2000  # NVD maximum
DELAY_WITHOUT_KEY = 6.5  # seconds between requests (5 per 30 s, with margin)
DELAY_WITH_KEY = 0.7  # 50 per 30 s, with margin
CACHE_TTL = timedelta(hours=24)
CACHE_SCHEMA = 2  # bump when the stored record format changes; older files are refetched
MAX_RETRIES = 4
TIMEOUT_SECONDS = 60
# 403 is what NVD sends when the rate limit is exceeded without a key.
RETRY_STATUS = {403, 429, 500, 502, 503, 504}

# (url, headers) -> parsed JSON
NvdHttpFn = Callable[[str, "dict[str, str]"], "dict[str, Any]"]


def cache_root() -> Path:
    """Where Keelbook keeps cached NVD/EUVD answers, per operating system.

    KEELBOOK_CACHE (or the old CRA_TOOL_CACHE) overrides it. Otherwise:
    Windows %LOCALAPPDATA%\\keelbook\\Cache, macOS ~/Library/Caches/keelbook,
    Linux $XDG_CACHE_HOME/keelbook or ~/.cache/keelbook.
    """
    for name in ("KEELBOOK_CACHE", "CRA_TOOL_CACHE"):
        if os.environ.get(name):
            return Path(os.environ[name])
    if sys.platform == "win32":
        base = os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
        return Path(base) / "keelbook" / "Cache"
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Caches" / "keelbook"
    base = os.environ.get("XDG_CACHE_HOME") or str(Path.home() / ".cache")
    return Path(base) / "keelbook"


def default_cache_dir() -> Path:
    return cache_root() / "nvd"


def _default_http(url: str, headers: dict[str, str]) -> dict[str, Any]:
    request = urllib.request.Request(url, headers={"User-Agent": f"keelbook/{__version__}", **headers})
    with urllib.request.urlopen(request, timeout=TIMEOUT_SECONDS) as response:
        return json.loads(response.read())


@dataclass
class NvdClient:
    """Fetches CVE records for a CPE match string, with pacing, retries and a cache."""

    api_key: str | None = None
    cache_dir: Path | None = None  # None = no cache
    ttl: timedelta = CACHE_TTL
    http: NvdHttpFn = _default_http
    sleep: Callable[[float], None] = time.sleep
    monotonic: Callable[[], float] = time.monotonic
    now: Callable[[], datetime] = lambda: datetime.now(timezone.utc)
    requests: int = 0
    cache_hits: int = 0
    oldest_data: datetime | None = None  # when the oldest NVD answer used was fetched
    offline: bool = False  # only saved answers, of any age; never a network request
    _last_request: float | None = field(default=None, repr=False)

    @property
    def delay(self) -> float:
        return DELAY_WITH_KEY if self.api_key else DELAY_WITHOUT_KEY

    def cves_for(self, match_string: str) -> list[dict[str, Any]]:
        """Trimmed CVE records NVD returns for `match_string` (see module docstring)."""
        cached = self._cache_read(match_string)
        if cached is not None:
            self.cache_hits += 1
            return cached
        if self.offline:
            raise VulnLookupError("offline: no saved NVD answer")
        records: list[dict[str, Any]] = []
        start = 0
        while True:
            query = urllib.parse.urlencode(
                {"virtualMatchString": match_string, "resultsPerPage": RESULTS_PER_PAGE, "startIndex": start}
            )
            page = self._get(f"{NVD_URL}?{query}&noRejected")
            items = page.get("vulnerabilities")
            total = page.get("totalResults")
            if not isinstance(items, list) or not isinstance(total, int):
                raise VulnLookupError("NVD returned an unexpected response")
            records.extend(_trim(item.get("cve")) for item in items if isinstance(item, dict))
            start += len(items)
            if not items or start >= total:
                break
        records = [r for r in records if r is not None]
        fetched = self.now()
        self._note_age(fetched)
        self._cache_write(match_string, records, fetched)
        return records

    def is_cached(self, match_string: str) -> bool:
        """True if a fresh cached answer exists (no network request would be needed)."""
        oldest = self.oldest_data
        found = self._cache_read(match_string) is not None
        self.oldest_data = oldest  # only a check: do not count this as data used
        return found

    # --- network -----------------------------------------------------------

    def _get(self, url: str) -> dict[str, Any]:
        headers = {"apiKey": self.api_key} if self.api_key else {}
        problem = "unknown error"
        for attempt in range(MAX_RETRIES):
            self._pace()
            self.requests += 1
            try:
                answer = self.http(url, headers)
                if not isinstance(answer, dict):
                    raise VulnLookupError("NVD returned a response that is not a JSON object")
                return answer
            except urllib.error.HTTPError as exc:
                problem = f"HTTP {exc.code}"
                if exc.code not in RETRY_STATUS:
                    raise VulnLookupError(f"NVD answered with HTTP {exc.code}") from exc
            except (urllib.error.URLError, TimeoutError, OSError) as exc:
                problem = str(getattr(exc, "reason", exc))
            except json.JSONDecodeError as exc:
                raise VulnLookupError("NVD returned a response that is not valid JSON") from exc
            if attempt < MAX_RETRIES - 1:
                self.sleep(self.delay * (2 ** attempt))
        raise VulnLookupError(f"Could not get an answer from NVD ({problem}).")

    def _pace(self) -> None:
        if self._last_request is not None:
            wait = self.delay - (self.monotonic() - self._last_request)
            if wait > 0:
                self.sleep(wait)
        self._last_request = self.monotonic()

    # --- cache -------------------------------------------------------------

    def _cache_path(self, match_string: str) -> Path | None:
        if self.cache_dir is None:
            return None
        return self.cache_dir / (hashlib.sha256(match_string.encode()).hexdigest() + ".json")

    def _cache_read(self, match_string: str) -> list[dict[str, Any]] | None:
        path = self._cache_path(match_string)
        if path is None or not path.is_file():
            return None
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            fetched = datetime.fromisoformat(data["fetched_at"])
            if (data.get("schema") != CACHE_SCHEMA or data.get("match_string") != match_string
                    or (not self.offline and self.now() - fetched > self.ttl)):
                return None
            records = data["records"]
            if not isinstance(records, list):
                return None
        except (OSError, ValueError, KeyError, TypeError):
            return None  # a broken cache file is simply refetched
        self._note_age(fetched)
        return records

    def _cache_write(self, match_string: str, records: list[dict[str, Any]], fetched: datetime) -> None:
        path = self._cache_path(match_string)
        if path is None:
            return
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            payload = {"schema": CACHE_SCHEMA, "match_string": match_string,
                       "fetched_at": fetched.isoformat(), "records": records}
            tmp = path.with_suffix(".tmp")
            tmp.write_text(json.dumps(payload), encoding="utf-8")
            tmp.replace(path)
        except OSError:
            pass  # caching is an optimisation; never fail a scan because of it

    def _note_age(self, fetched: datetime) -> None:
        if self.oldest_data is None or fetched < self.oldest_data:
            self.oldest_data = fetched


def _trim(cve: Any) -> dict[str, Any] | None:
    """Keep only what the tool uses, so the cache stays small."""
    if not isinstance(cve, dict) or not isinstance(cve.get("id"), str):
        return None
    summary = None
    for description in cve.get("descriptions") or []:
        if isinstance(description, dict) and description.get("lang") == "en":
            summary = description.get("value")
            break
    matches = []
    for config in cve.get("configurations") or []:
        for node in (config or {}).get("nodes") or []:
            for match in (node or {}).get("cpeMatch") or []:
                if isinstance(match, dict) and match.get("vulnerable") is True:
                    matches.append({k: match[k] for k in (
                        "criteria", "versionStartIncluding", "versionStartExcluding",
                        "versionEndIncluding", "versionEndExcluding") if isinstance(match.get(k), str)})
    return {"id": cve["id"], "summary": summary, "vulnerable": matches, "cvss": from_nvd_metrics(cve.get("metrics"))}


# --- deciding which CVEs apply ------------------------------------------------


def lookup_version(component: Component, cpe: Cpe) -> str | None:
    """The version to search for: the CPE's own, else the component's, cleaned.

    Yocto versions like '6.6.151+git' carry a source-control suffix that NVD
    does not know; it is dropped (Yocto's own CPEs already do the same).
    """
    if cpe.has_version:
        return unescape(cpe.version)
    if not component.version:
        return None
    return re.sub(r"\+git.*$", "", component.version.strip()) or None


def assess(record: dict[str, Any], cpe: Cpe, version: str) -> tuple[bool, str | None, str | None]:
    """(keep?, fixed-in version or None, why there is none) for one trimmed NVD record."""
    own = []
    for match in record.get("vulnerable") or []:
        theirs = parse_cpe(match.get("criteria"))
        if theirs is None or theirs.product != cpe.product:
            continue
        if cpe.vendor != ANY and theirs.vendor not in (cpe.vendor, ANY):
            continue
        own.append((theirs, match))
    if not own:
        return False, None, None  # only listed as a platform the vulnerable software runs on

    installed = parse_version(version)
    fixed: set[str] = set()
    for theirs, match in own:
        end = match.get("versionEndExcluding")
        if installed is None or not end:
            continue
        bounds = {
            "start_inc": match.get("versionStartIncluding"),
            "start_exc": match.get("versionStartExcluding"),
            "end_exc": end,
        }
        parsed = {k: parse_version(v) for k, v in bounds.items() if v}
        if any(v is None for v in parsed.values()):
            continue
        if "start_inc" in parsed and installed < parsed["start_inc"]:
            continue
        if "start_exc" in parsed and installed <= parsed["start_exc"]:
            continue
        if installed < parsed["end_exc"]:
            fixed.add(end)
    if fixed:
        return True, max(fixed, key=parse_version), None
    if any(match.get("versionEndExcluding") for _, match in own):
        return True, None, CANNOT_COMPARE
    return True, None, NO_FIX_RECORDED


def matched_vendors(record: dict[str, Any], cpe: Cpe) -> tuple[str, ...]:
    """The vendors NVD names as vulnerable for this product, e.g. ('openstack',).

    Shown to the user when the SBOM's CPE has no vendor ('*'): a match on the
    product name alone can be a different product with the same name.
    """
    vendors = set()
    for match in record.get("vulnerable") or []:
        theirs = parse_cpe(match.get("criteria"))
        if theirs is not None and theirs.product == cpe.product and theirs.vendor != ANY:
            vendors.add(unescape(theirs.vendor))
    return tuple(sorted(vendors))


def obviously_same(vendor: str, product: str) -> bool:
    """Vendor names that plainly belong to the product: busybox:busybox,
    elfutils_project:elfutils, pcre:pcre2, linux:linux_kernel. Anything else
    (openstack:neutron, samba:rsync) is shown to a person to check."""
    vendor, product = vendor.lower(), unescape(product).lower()
    return vendor in (product, f"{product}_project") or product.startswith(vendor)


@dataclass
class CpeGroup:
    """Components that share one CPE lookup (Yocto: busybox, busybox-syslog, ...)."""

    cpe: Cpe
    version: str
    components: list[Component]

    @property
    def match_string(self) -> str:
        cpe = self.cpe if self.cpe.has_version else self.cpe.with_version(self.version)
        return cpe.match_string()


def plan_cpe_lookups(components: list[Component]) -> tuple[list[CpeGroup], dict[str, int]]:
    """Group components by CPE lookup; return (groups, skip reasons -> count)."""
    groups: dict[str, CpeGroup] = {}
    skipped: dict[str, int] = {}
    for component in components:
        cpe = parse_cpe(component.cpe)
        if cpe is None:
            skipped["CPE not usable"] = skipped.get("CPE not usable", 0) + 1
            continue
        version = lookup_version(component, cpe)
        if version is None:
            skipped["no version"] = skipped.get("no version", 0) + 1
            continue
        group = CpeGroup(cpe, version, [component])
        key = group.match_string
        if key in groups:
            groups[key].components.append(component)
        else:
            groups[key] = group
    return list(groups.values()), skipped
