"""Vulnerability register: products, releases, and a person's decision per finding.

Why: the CRA asks manufacturers to "systematically document ... vulnerabilities
of which they become aware" (Art. 13(7)) and to handle them "without delay"
for the whole support period (Annex I, Part II; Art. 13(8)). A scan is a
snapshot; this register is the lasting record:

* a PRODUCT has RELEASES; each release keeps the findings of its SBOM scan
  (with the SBOM's SHA-256, coverage and sources);
* for each finding a person records a DECISION: not_affected (with a
  justification or impact statement), affected (with the action taken), fixed
  (in which release/version) or under_investigation, always with a reason;
* decisions carry over to later releases. If the component's version changed
  since the decision, the finding is flagged "re-confirm" instead of being
  silently treated as decided;
* everything is stored in the same append-only, hash-chained log as the
  Art. 14 cases (subject "PRODUCT:<id>"). Nothing is updated or deleted; a new
  decision supersedes the previous one and the history stays visible.

The status and justification vocabulary is OpenVEX's (CISA "Minimum
Requirements for VEX"), so decisions can be exported as VEX unchanged.

The register never decides anything itself. Producer statements (Yocto
cve-check, VEX in the SBOM) are shown as suggestions; adopting them is an
explicit, logged act by a named person (see accept_producer).
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import date, datetime, timezone
from typing import Any

from keelbook import models
from keelbook.cases import Event, Store
from keelbook.errors import CaseError
from keelbook.vulns import Finding

PRODUCT_ADDED = "product_added"
PRODUCT_DETAILS = "product_details"
# Product details for the evidence record (CRA Art. 13(8) support period, Art. 13(17) single point
# of contact, Annex I Part II (5) policy on coordinated vulnerability disclosure).
DETAIL_FIELDS = ("manufacturer", "contact", "cvd_policy", "support_until")
RELEASE_SCANNED = "release_scanned"
DECISION = "decision"
SUBJECT = "PRODUCT:"

NOT_AFFECTED, AFFECTED, FIXED, UNDER_INVESTIGATION = "not_affected", "affected", "fixed", "under_investigation"
STATUSES = (NOT_AFFECTED, AFFECTED, FIXED, UNDER_INVESTIGATION)
JUSTIFICATIONS = (
    "component_not_present",
    "vulnerable_code_not_present",
    "vulnerable_code_not_in_execute_path",
    "vulnerable_code_cannot_be_controlled_by_adversary",
    "inline_mitigations_already_exist",
)

# Review states of a finding in a release
NEEDS_DECISION = "needs decision"
RECONFIRM = "re-confirm"
DECIDED = "decided"


class RegisterError(CaseError):
    """A problem with the register input that the user can fix."""


def product_id(text: str) -> str:
    value = (text or "").strip().lower()
    if not re.fullmatch(r"[a-z0-9][a-z0-9._-]{0,63}", value):
        raise RegisterError(
            f"Invalid product ID '{text}'. Use 1-64 characters: letters, digits, '.', '_' or '-', "
            "starting with a letter or digit (e.g. 'gateway-x200')."
        )
    return value


def release_label(text: str) -> str:
    value = (text or "").strip()
    if not value or len(value) > 64 or any(ch.isspace() for ch in value):
        raise RegisterError(f"Invalid release '{text}'. Use a version label without spaces, e.g. '2.1.0'.")
    return value


def finding_key(component_name: str, cve_ids: list[str] | tuple[str, ...], vuln_id: str) -> str:
    """Identity of a finding across releases: component name + vulnerability.

    The version is deliberately NOT part of the key: a decision stays attached
    when the component is upgraded, and the version check then asks a person to
    re-confirm it.
    """
    vuln = "+".join(sorted({c.upper() for c in cve_ids})) or vuln_id.strip().upper()
    return f"{component_name.strip().lower()}|{vuln}"


# --- records -----------------------------------------------------------------


def finding_record(finding: Finding, kev: bool | None, euvd: bool | None) -> dict[str, Any]:
    """What the register keeps about one finding (JSON-safe, stable field names)."""
    c = finding.component
    sev = finding.severity
    return {
        "key": finding_key(c.name, finding.cve_ids, finding.vuln_id),
        "component": c.name,
        "version": c.version,
        "purl": c.purl,
        "cpe": c.cpe,
        "also_in": list(finding.also_in),
        "vuln_id": finding.vuln_id,
        "cve_ids": list(finding.cve_ids),
        "aliases": list(finding.aliases),
        "summary": finding.summary,
        "source": finding.source,
        "matched_as": finding.matched_as,
        "vendor_unconfirmed": list(finding.vendor_unconfirmed),
        "severity": None if sev is None else {"score": sev.score, "label": sev.label, "version": sev.version},
        "fixed_in": list(finding.fixed_in),
        "fix_note": finding.fix_note,
        "kev": kev,  # True / False / None (not checked or no CVE ID)
        "euvd": euvd,
        "producer_status": finding.vex_status,
        "producer_detail": finding.vex_detail,
        "producer_source": finding.vex_source,
    }


@dataclass(frozen=True)
class Decision:
    key: str
    status: str
    reason: str
    justification: str | None
    impact: str | None
    action: str | None
    fixed_in: str | None
    component: str
    version: str | None  # component version the decision was made for
    release: str  # release it was made in
    by: str
    at: str  # UTC ISO time recorded
    seq: int


@dataclass
class Release:
    label: str
    sbom_file: str
    sbom_sha256: str
    scanned_at: str
    scanned_by: str
    tool_version: str
    total: int
    checked: int
    skipped: dict[str, int]
    sources: list[str]
    findings: list[dict[str, Any]]
    seq: int
    rescans: int = 0  # earlier scans of the same release label (the latest one counts)


@dataclass
class ProductState:
    id: str
    name: str
    created_at: str
    created_by: str
    releases: dict[str, Release] = field(default_factory=dict)  # label -> latest scan
    release_order: list[str] = field(default_factory=list)  # first-scan order
    decisions: dict[str, list[Decision]] = field(default_factory=dict)  # key -> history, oldest first
    details: dict[str, str] = field(default_factory=dict)  # DETAIL_FIELDS that were recorded

    def latest_release(self) -> Release | None:
        return self.releases[self.release_order[-1]] if self.release_order else None

    def current_decision(self, key: str, version: str | None = None, any_version: bool = False) -> Decision | None:
        """Latest decision for this finding and component version.

        With any_version=True: latest decision for the finding whatever the version.
        """
        history = self.decisions.get(key) or []
        if any_version:
            return history[-1] if history else None
        for decision in reversed(history):
            if decision.version == version:
                return decision
        return None


@dataclass(frozen=True)
class ReviewRow:
    finding: dict[str, Any]
    state: str  # NEEDS_DECISION, RECONFIRM, DECIDED
    decision: Decision | None
    note: str | None = None  # e.g. "version changed: 3.0.8 -> 3.0.9"


@dataclass(frozen=True)
class DecisionInput:
    key: str
    status: str
    reason: str
    justification: str | None = None
    impact: str | None = None
    action: str | None = None
    fixed_in: str | None = None


def _clean(value: Any) -> str | None:
    if value is None:
        return None
    text = " ".join(str(value).split())
    return text or None


def validate_decision(item: DecisionInput) -> list[str]:
    """Problems with one decision (empty list = valid). Rules follow OpenVEX."""
    problems = []
    if item.status not in STATUSES:
        problems.append(f"status must be one of: {', '.join(STATUSES)} (got '{item.status}')")
    if not _clean(item.reason):
        problems.append("a reason is required (why this decision; it is recorded verbatim)")
    if item.justification and item.justification not in JUSTIFICATIONS:
        problems.append(f"justification must be one of: {', '.join(JUSTIFICATIONS)} (got '{item.justification}')")
    if item.status == NOT_AFFECTED and not item.justification and not _clean(item.impact):
        problems.append("not_affected needs a justification or an impact statement")
    if item.status != NOT_AFFECTED and item.justification:
        problems.append("a justification is only used with not_affected")
    if item.status == AFFECTED and not _clean(item.action):
        problems.append("affected needs an action statement (what is done about it, e.g. 'fix planned in 2.1')")
    if item.status == FIXED and not _clean(item.fixed_in):
        problems.append("fixed needs the release or version that contains the fix")
    return problems


# --- the register ------------------------------------------------------------


class Register:
    def __init__(self, store: Store):
        self.store = store

    def _subject(self, pid: str) -> str:
        return SUBJECT + pid

    # reading

    def product(self, text: str) -> ProductState:
        pid = product_id(text)
        events = self.store.events_for(self._subject(pid))
        if not events or events[0].type != PRODUCT_ADDED:
            raise RegisterError(f"No such product: {pid}. Add it first with 'keelbook product add {pid}'.")
        return _build(pid, events)

    def products(self) -> list[ProductState]:
        ids = {e.case_id[len(SUBJECT):] for e in self.store._events() if e.case_id.startswith(SUBJECT)}
        return [self.product(pid) for pid in sorted(ids)]

    def release(self, state: ProductState, label: str | None) -> Release:
        if label is None:
            latest = state.latest_release()
            if latest is None:
                raise RegisterError(f"{state.id} has no scanned release yet. Use 'keelbook product scan'.")
            return latest
        label = release_label(label)
        if label not in state.releases:
            known = ", ".join(state.release_order) or "none"
            raise RegisterError(f"{state.id} has no release '{label}'. Scanned releases: {known}.")
        return state.releases[label]

    def review(self, state: ProductState, release: Release) -> list[ReviewRow]:
        rows = []
        for finding in release.findings:
            decision = state.current_decision(finding["key"], finding["version"])
            if decision is not None:
                rows.append(ReviewRow(finding, DECIDED, decision))
                continue
            other = state.current_decision(finding["key"], any_version=True)
            if other is None:
                rows.append(ReviewRow(finding, NEEDS_DECISION, None))
            else:
                rows.append(ReviewRow(finding, RECONFIRM, other,
                                      f"decided for version {other.version or '-'}, "
                                      f"this release has {finding['version'] or '-'}"))
        return rows

    # writing

    def add_product(self, text: str, name: str | None, actor: str, now: datetime | None = None,
                    details: dict[str, str | None] | None = None) -> Event:
        pid = product_id(text)
        if self.store.events_for(self._subject(pid)):
            raise RegisterError(f"Product {pid} already exists.")
        data = {"product": pid, "name": _clean(name) or pid, **_valid_details(details or {})}
        return self.store.append_subject_events([(self._subject(pid), PRODUCT_ADDED, actor, data)], now)[0]

    def set_details(self, text: str, details: dict[str, str | None], actor: str,
                    now: datetime | None = None) -> Event:
        """Record new product details (only the given ones change; history is kept)."""
        state = self.product(text)
        clean = _valid_details(details)
        if not clean:
            raise RegisterError("Give at least one detail to change (--manufacturer, --contact, --cvd-policy, "
                                "--support-until).")
        return self.store.append_subject_events(
            [(self._subject(state.id), PRODUCT_DETAILS, actor, {"product": state.id, **clean})], now)[0]

    def record_scan(self, text: str, label: str, *, sbom_file: str, sbom_sha256: str, findings: list[dict],
                    total: int, checked: int, skipped: dict[str, int], sources: list[str], tool_version: str,
                    actor: str, now: datetime | None = None) -> Event:
        state = self.product(text)
        data = {
            "release": release_label(label), "sbom_file": sbom_file, "sbom_sha256": sbom_sha256,
            "total": total, "checked": checked, "skipped": dict(skipped), "sources": list(sources),
            "tool_version": tool_version, "findings": findings,
        }
        return self.store.append_subject_events([(self._subject(state.id), RELEASE_SCANNED, actor, data)], now)[0]

    def decide(self, text: str, label: str | None, items: list[DecisionInput], actor: str,
               now: datetime | None = None) -> list[Event]:
        """Record decisions for findings of one release: all of them, or none if any is invalid."""
        state = self.product(text)
        release = self.release(state, label)
        by_key: dict[str, list[dict]] = {}
        for f in release.findings:
            by_key.setdefault(f["key"], []).append(f)
        problems = []
        for number, item in enumerate(items, 1):
            label_ = f"#{number} ({item.key})"
            if item.key not in by_key:
                problems.append(f"{label_}: not a finding of release {release.label}")
                continue
            problems += [f"{label_}: {p}" for p in validate_decision(item)]
        if not items:
            problems.append("no decisions given")
        if problems:
            raise RegisterError("Nothing was recorded. Fix these problems:\n  " + "\n  ".join(problems))
        events = []
        for item in items:
            # One decision per component version present in this release (usually one).
            versions = {f["version"]: f for f in by_key[item.key]}
            for version, finding in sorted(versions.items(), key=lambda kv: kv[0] or ""):
                data = {
                    "key": item.key, "status": item.status, "reason": _clean(item.reason),
                    "justification": item.justification or None, "impact": _clean(item.impact),
                    "action": _clean(item.action), "fixed_in": _clean(item.fixed_in),
                    "component": finding["component"], "version": version, "release": release.label,
                }
                events.append((self._subject(state.id), DECISION, actor, data))
        return self.store.append_subject_events(events, now)

    def producer_suggestions(self, state: ProductState, release: Release) -> list[DecisionInput]:
        """Decisions a person may adopt from the SBOM producer's own statements.

        Only findings that still need a decision (or re-confirmation) and that the
        producer marks fixed / not affected. The reason is filled in by the caller.
        """
        out = []
        seen: set[str] = set()
        for row in self.review(state, release):
            f = row.finding
            if row.state == DECIDED or f.get("producer_status") not in models.RESOLVED_STATUSES or f["key"] in seen:
                continue
            seen.add(f["key"])
            source = f.get("producer_source") or "SBOM producer"
            detail = f.get("producer_detail")
            statement = f"{source}: {detail}" if detail else source
            if f["producer_status"] == models.FIXED:
                out.append(DecisionInput(f["key"], FIXED, reason="", fixed_in=f"{release.label} (per {statement})"))
            else:
                out.append(DecisionInput(f["key"], NOT_AFFECTED, reason="", impact=f"Producer statement - {statement}"))
        return out


def _build(pid: str, events: list[Event]) -> ProductState:
    first = events[0]
    state = ProductState(id=pid, name=first.data.get("name") or pid, created_at=first.ts, created_by=first.actor)
    state.details.update({k: first.data[k] for k in DETAIL_FIELDS if first.data.get(k)})
    for event in events[1:]:
        d = event.data
        if event.type == PRODUCT_DETAILS:
            state.details.update({k: d[k] for k in DETAIL_FIELDS if d.get(k)})
        elif event.type == RELEASE_SCANNED:
            label = d["release"]
            previous = state.releases.get(label)
            state.releases[label] = Release(
                label=label, sbom_file=d.get("sbom_file", ""), sbom_sha256=d.get("sbom_sha256", ""),
                scanned_at=event.ts, scanned_by=event.actor, tool_version=d.get("tool_version", ""),
                total=d.get("total", 0), checked=d.get("checked", 0), skipped=dict(d.get("skipped") or {}),
                sources=list(d.get("sources") or []), findings=list(d.get("findings") or []), seq=event.seq,
                rescans=(previous.rescans + 1) if previous else 0,
            )
            if label not in state.release_order:
                state.release_order.append(label)
        elif event.type == DECISION:
            state.decisions.setdefault(d["key"], []).append(Decision(
                key=d["key"], status=d["status"], reason=d.get("reason") or "", justification=d.get("justification"),
                impact=d.get("impact"), action=d.get("action"), fixed_in=d.get("fixed_in"),
                component=d.get("component", ""), version=d.get("version"), release=d.get("release", ""),
                by=event.actor, at=event.ts, seq=event.seq,
            ))
    return state


def _valid_details(details: dict[str, str | None]) -> dict[str, str]:
    out = {}
    for key, value in details.items():
        if key not in DETAIL_FIELDS:
            raise RegisterError(f"Unknown product detail: {key}")
        text = _clean(value)
        if not text:
            continue
        if key == "support_until":
            try:
                text = date.fromisoformat(text).isoformat()
            except ValueError as exc:
                raise RegisterError(f"--support-until must be a date like 2031-12-31, not {text!r}.") from exc
        out[key] = text
    return out


def utc_now() -> datetime:
    return datetime.now(timezone.utc)
