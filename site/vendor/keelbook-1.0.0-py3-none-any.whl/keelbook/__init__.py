"""Keelbook: vulnerability register for firmware makers (EU Cyber Resilience Act)."""

__version__ = "1.0.0"
