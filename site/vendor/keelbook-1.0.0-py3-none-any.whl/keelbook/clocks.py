"""Deadline logic for CRA Art. 14 reporting. Pure functions, no I/O.

Two tracks, both with an early warning (24 h) and a notification (72 h), both
counted from the moment the manufacturer became AWARE:

* vulnerability (actively exploited vulnerability): final report within 14 days
  after a corrective or mitigating measure is available.
* incident (severe incident): final report within one month after the
  incident notification was submitted.

The article numbers below were checked against the regulation text
(Regulation (EU) 2024/2847, Art. 14(2) and 14(4)); every other module reads
them from this file.
"""

from __future__ import annotations

import calendar
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

VULNERABILITY = "vulnerability"
INCIDENT = "incident"
TRACKS = (VULNERABILITY, INCIDENT)

EARLY = "early-warning"
NOTIFICATION = "notification"
FINAL = "final-report"
STAGES = (EARLY, NOTIFICATION, FINAL)

ARTICLE = {VULNERABILITY: "Art. 14(2)", INCIDENT: "Art. 14(4)"}
STAGE_LABEL = {EARLY: "Early warning", NOTIFICATION: "Notification", FINAL: "Final report"}

EARLY_HOURS = 24
NOTIFICATION_HOURS = 72
FINAL_DAYS_AFTER_FIX = 14
FINAL_MONTHS_AFTER_NOTIFICATION = 1


@dataclass(frozen=True)
class Deadline:
    stage: str
    due: datetime | None  # None = clock has not started yet
    rule: str  # plain-language rule, shown to the user
    waiting_for: str | None = None  # what must be recorded to start the clock

    @property
    def label(self) -> str:
        return STAGE_LABEL[self.stage]


def add_months(moment: datetime, months: int) -> datetime:
    """Calendar-month arithmetic; the day is clamped (31 Jan + 1 month = 28/29 Feb)."""
    index = moment.month - 1 + months
    year = moment.year + index // 12
    month = index % 12 + 1
    day = min(moment.day, calendar.monthrange(year, month)[1])
    return moment.replace(year=year, month=month, day=day)


def compute_deadlines(
    track: str,
    aware_at: datetime,
    fix_at: datetime | None = None,
    notification_submitted_at: datetime | None = None,
) -> list[Deadline]:
    """All three deadlines for a case. Times must be timezone-aware (UTC)."""
    if track not in TRACKS:
        raise ValueError(f"unknown track: {track}")
    for moment in (aware_at, fix_at, notification_submitted_at):
        if moment is not None and moment.tzinfo is None:
            raise ValueError("times must be timezone-aware")

    early = Deadline(EARLY, aware_at + timedelta(hours=EARLY_HOURS), "24 hours after becoming aware")
    notification = Deadline(
        NOTIFICATION, aware_at + timedelta(hours=NOTIFICATION_HOURS), "72 hours after becoming aware"
    )
    if track == VULNERABILITY:
        if fix_at is not None:
            final = Deadline(FINAL, fix_at + timedelta(days=FINAL_DAYS_AFTER_FIX),
                             "14 days after a corrective or mitigating measure is available")
        else:
            final = Deadline(FINAL, None, "14 days after a corrective or mitigating measure is available",
                             waiting_for="record the fix or mitigation with 'case fix'")
    else:
        if notification_submitted_at is not None:
            final = Deadline(FINAL, add_months(notification_submitted_at, FINAL_MONTHS_AFTER_NOTIFICATION),
                             "one month after the incident notification was submitted")
        else:
            final = Deadline(FINAL, None, "one month after the incident notification was submitted",
                             waiting_for="record the submitted notification with 'case submit'")
    return [early, notification, final]


def classify(deadline: Deadline, submitted_at: datetime | None, now: datetime) -> str:
    """One of: waiting, open, overdue, on time, LATE."""
    if submitted_at is not None:
        if deadline.due is None:
            return "submitted"
        return "on time" if submitted_at <= deadline.due else "LATE"
    if deadline.due is None:
        return "waiting"
    return "overdue" if now > deadline.due else "open"


def time_left_text(due: datetime, now: datetime) -> str:
    seconds = int((due - now).total_seconds())
    late = seconds < 0
    seconds = abs(seconds)
    days, rest = divmod(seconds, 86400)
    hours, rest = divmod(rest, 3600)
    minutes = rest // 60
    parts = (f"{days}d " if days else "") + f"{hours}h {minutes:02d}m"
    return f"OVERDUE by {parts}" if late else f"in {parts}"


def parse_when(text: str, now: datetime | None = None) -> datetime:
    """Parse 'now' or an ISO 8601 time into UTC.

    A time without a UTC offset is read as the computer's LOCAL time, and the
    CLI shows the resulting UTC time so the user can see what was understood.
    """
    text = text.strip()
    if text.lower() == "now":
        return now or datetime.now(timezone.utc)
    try:
        moment = datetime.fromisoformat(text)
    except ValueError as exc:
        raise ValueError(
            f"Cannot read the time '{text}'. Use 'now' or ISO format, "
            "e.g. 2026-10-31T09:30 or 2026-10-31T09:30+01:00."
        ) from exc
    return moment.astimezone(timezone.utc)  # naive -> treated as local time
