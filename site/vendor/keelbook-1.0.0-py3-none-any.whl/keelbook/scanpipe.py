"""The vulnerability-lookup pipeline shared by 'scan' and 'product scan' (CLI layer).

Both commands must behave identically: same sources, same producer statements,
same exit codes. Keeping the steps in one place guarantees that.

Steps: read extra inputs (KEV, Yocto cve-check, CycloneDX VEX) -> download EUVD
if asked -> look up OSV / NVD -> attach producer statements -> add Yocto
Unpatched CVEs. Warnings go to stderr; failures exit with the documented codes
(1 bad input file, 3 lookup failed).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import click
from rich.console import Console
from rich.markup import escape

from keelbook.cvelist import CveListIndex, default_index_file, download_and_build
from keelbook.errors import KevFileError, SbomError, VulnLookupError
from keelbook.euvd import EuvdCatalogue, default_cache_file, fetch_exploited, load_saved
from keelbook.kev import KevCatalogue, fetch_kev, load_kev
from keelbook.kev import default_cache_file as default_kev_cache
from keelbook.kernelfilter import load_kernel_sources, suggestions
from keelbook.lookup import run_lookup, split_by_source
from keelbook.models import Sbom
from keelbook.nvd import DELAY_WITHOUT_KEY, NvdClient, default_cache_dir
from keelbook.vex import add_unpatched, apply_statements, load_cyclonedx_vex, load_yocto_cve_check
from keelbook.vulns import LookupResult


@dataclass
class LookupOptions:
    kev_path: Path | None = None
    use_euvd: bool = False
    vex_paths: tuple[Path, ...] = ()
    yocto_paths: tuple[Path, ...] = ()
    excluded: tuple[str, ...] = ()
    no_nvd: bool = False
    nvd_api_key: str | None = None
    no_cache: bool = False
    use_cvelist: bool = False
    kev_download: bool = False
    kernel_sources: Path | None = None
    offline: bool = False


@dataclass
class PipelineResult:
    lookup: LookupResult
    kev: KevCatalogue | None
    euvd: EuvdCatalogue | None
    yocto_reports: list = field(default_factory=list)
    vex_files: list = field(default_factory=list)  # (file name, statements)
    statements: list = field(default_factory=list)
    yocto_added: int = 0
    offline: bool = False
    kernel_suggested: int = 0  # kernel findings suggested "not affected: not built"
    kernel_list: str | None = None

    def sources(self) -> list[str]:
        """Plain-language list of what this result is based on (for records)."""
        out = [s for s in ("OSV", "NVD") if s in self.lookup.checked_by]
        if self.lookup.cvelist_label:
            unknown = sum(len(v) for v in self.lookup.cvelist_unknown.values())
            out.append(self.lookup.cvelist_label + (f" ({unknown} record(s) whose versions could not be "
                                                    "compared: not counted, not clean)" if unknown else ""))
        if self.kev is not None:
            out.append(f"CISA KEV {(self.kev.released or 'unknown date')[:10]}")
        if self.euvd is not None:
            when = self.euvd.fetched_at.strftime("%Y-%m-%d") if self.euvd.fetched_at else "unknown date"
            out.append(f"ENISA EUVD exploited list {when}")
        out += [f"VEX file {name}" for name, _ in self.vex_files]
        out += ["Yocto cve-check"] * min(1, len(self.yocto_reports))
        if self.kernel_list:
            out.append(f"kernel build file list {self.kernel_list}")
        if self.offline:
            out.append("offline mode (saved data only)")
        for reason, n in sorted(self.lookup.nvd_missed.items()):
            out.append(f"NOT checked by NVD: {n} component(s) ({reason}), CVE List only")
        return out


def lookup_options(func):
    """The click options that control the lookup (shared by 'scan' and 'product scan')."""
    options = [
        click.option("--exclude", "excluded", multiple=True, metavar="NAME",
                     help="Do not look up this component name (repeatable). Use it for your own "
                     "product, which is not a public package. Shown as NOT checked."),
        click.option("--kev", "kev_path", type=click.Path(path_type=Path),
                     help="CISA KEV catalogue (JSON file you downloaded). Marks findings that are "
                     "CANDIDATES for 'actively exploited'."),
        click.option("--kev-download", "kev_download", is_flag=True,
                     help="Download CISA's KEV catalogue from cisa.gov instead of giving a file with --kev "
                     "(about 2 MB, kept 24 h in your user cache folder; nothing about your product is sent)."),
        click.option("--euvd", "use_euvd", is_flag=True,
                     help="Also mark findings listed in ENISA's EUVD exploited-vulnerability list (downloaded "
                     "from euvdservices.enisa.europa.eu, cached 24 h; nothing about your product is sent)."),
        click.option("--vex", "vex_paths", multiple=True, type=click.Path(path_type=Path, dir_okay=False),
                     help="CycloneDX VEX file for this SBOM (repeatable), e.g. Yocto's vex.json. Its "
                     "statements (resolved / not affected / ...) are shown next to the findings."),
        click.option("--yocto-cve", "yocto_paths", multiple=True, type=click.Path(path_type=Path, dir_okay=False),
                     help="Yocto cve-check JSON output (repeatable). Its Patched/Ignored/Unpatched "
                     "statements are shown next to the findings; Unpatched CVEs are added."),
        click.option("--cve-list", "use_cvelist", is_flag=True,
                     help="Also check CPE components against the official CVE List (the records written by "
                     "the CNAs, e.g. OpenSSL or the Linux kernel team). Finds CVEs that NVD has not analysed "
                     "yet, and exact fix versions per kernel branch. The first use downloads the list "
                     "(several hundred MB) and builds a local index; it is refreshed when older than 7 days. "
                     "Nothing about your product is sent."),
        click.option("--kernel-sources", "kernel_sources", type=click.Path(path_type=Path, dir_okay=False),
                     help="List of the kernel source files your build compiled (in the kernel build folder: "
                     "find . -name '*.o' > kernel-sources.txt). Kernel CVEs whose files are all not built are "
                     "SUGGESTED as 'not affected' (a person adopts them). Needs --cve-list."),
        click.option("--no-nvd", is_flag=True,
                     help="Do not query NVD; components identified only by CPE are then NOT checked."),
        click.option("--nvd-api-key", envvar="NVD_API_KEY",
                     help="NVD API key (free, makes CPE lookups about 10x faster). Default: $NVD_API_KEY."),
        click.option("--offline", is_flag=True,
                     help="No network at all: use only data saved by earlier scans (NVD answers of any age, "
                     "the CVE List index, the last KEV/EUVD copies). Components without saved data are "
                     "reported as NOT checked; the age of the data used is shown."),
        click.option("--no-cache", is_flag=True,
                     help="Do not use or store cached NVD/EUVD answers (default cache: 24 hours, "
                     "in your user cache folder, or $KEELBOOK_CACHE)."),
    ]
    for option in reversed(options):
        func = option(func)
    return func


def has_lookup_extras(opts: LookupOptions) -> bool:
    return bool(opts.kev_path or opts.kev_download or opts.use_euvd or opts.vex_paths or opts.yocto_paths
                or opts.kernel_sources)


def run_pipeline(console: Console, err_console: Console, sbom: Sbom, opts: LookupOptions) -> PipelineResult:
    if opts.kev_path is not None and opts.kev_download:
        raise click.UsageError("Use either --kev FILE or --kev-download, not both.")
    if opts.offline and opts.no_cache:
        raise click.UsageError("--offline uses saved data; it cannot be combined with --no-cache.")
    if opts.kernel_sources is not None and not opts.use_cvelist:
        raise click.UsageError("--kernel-sources needs --cve-list (the CVE records name the kernel source files).")
    catalogue: KevCatalogue | None = None
    yocto_reports = []
    vex_files: list[tuple[str, list]] = []
    try:  # read every extra input before any network call: fail fast
        if opts.kev_path is not None:
            catalogue = load_kev(opts.kev_path)
        built = load_kernel_sources(opts.kernel_sources) if opts.kernel_sources is not None else None
        yocto_reports = [load_yocto_cve_check(path) for path in opts.yocto_paths]
        for path in opts.vex_paths:
            statements, problems = load_cyclonedx_vex(path, sbom)
            for problem in problems:
                err_console.print(f"[yellow]Warning:[/yellow] {escape(path.name)}: {escape(problem)}")
            if not statements:
                err_console.print(f"[yellow]Warning:[/yellow] {escape(path.name)}: no statement could be "
                                  "applied to this SBOM.")
            vex_files.append((path.name, statements))
    except (KevFileError, SbomError) as exc:
        err_console.print(f"[bold red]Error:[/bold red] {escape(str(exc))}")
        raise click.exceptions.Exit(1) from exc

    if opts.kev_download:
        try:
            with console.status("Downloading CISA's KEV catalogue..."):
                catalogue, warning = fetch_kev(None if opts.no_cache else default_kev_cache(),
                                               **({"http": _no_network} if opts.offline else {}))
        except VulnLookupError as exc:
            err_console.print(f"[bold red]Error:[/bold red] {escape(str(exc))} "
                              "Run without --kev-download, or give a downloaded file with --kev.")
            raise click.exceptions.Exit(3) from exc
        if warning:
            err_console.print(f"[yellow]Warning:[/yellow] {escape(warning)}")

    euvd: EuvdCatalogue | None = None
    if opts.use_euvd and opts.offline:
        euvd = load_saved(default_cache_file())
        if euvd is None:
            err_console.print("[bold red]Error:[/bold red] --offline: no saved EUVD list. Run once with --euvd "
                              "while online, or leave out --euvd.")
            raise click.exceptions.Exit(3)
        when = euvd.fetched_at.date().isoformat() if euvd.fetched_at else "unknown date"
        err_console.print(f"[yellow]Offline: using the EUVD list saved {when}.[/yellow]")
    elif opts.use_euvd:
        try:
            with console.status("Downloading ENISA's EUVD exploited list..."):
                euvd = fetch_exploited(cache_file=None if opts.no_cache else default_cache_file())
        except VulnLookupError as exc:
            err_console.print(f"[bold red]Error:[/bold red] {escape(str(exc))} "
                              "Run without --euvd, or try again later.")
            raise click.exceptions.Exit(3) from exc

    cvelist = open_cvelist(console, err_console, opts) if opts.use_cvelist else None

    skip_names = {name.lower() for name in opts.excluded}
    to_check = [c for c in sbom.components if c.name.lower() not in skip_names]
    nvd = None
    if not opts.no_nvd:
        nvd = NvdClient(api_key=opts.nvd_api_key or None, cache_dir=None if opts.no_cache else default_cache_dir(),
                        offline=opts.offline)
        _, groups, _ = split_by_source(to_check, use_nvd=True)
        uncached = [g for g in groups if not nvd.is_cached(g.match_string)]
        if not opts.nvd_api_key and len(uncached) > 10 and not opts.offline:
            minutes = len(uncached) * DELAY_WITHOUT_KEY / 60
            console.print(
                f"[yellow]{len(uncached)} of {len(groups)} CPE lookups are not cached yet: up to about "
                f"{minutes:.0f} minute(s) at NVD without an API key. A free key from "
                "https://nvd.nist.gov/developers/request-an-api-key makes this about 10x faster "
                "(--nvd-api-key or NVD_API_KEY).[/yellow]"
            )
    try:
        with console.status("Looking up known vulnerabilities (package identifiers only)...") as status:
            lookup = run_lookup(to_check, nvd, progress=lambda text: status.update(escape(text)), cvelist=cvelist,
                                offline=opts.offline)
            left_out = len(sbom.components) - len(to_check)
            if left_out:
                lookup.skipped["excluded by you"] = left_out
    except VulnLookupError as exc:
        err_console.print(f"[bold red]Error:[/bold red] {escape(str(exc))}")
        raise click.exceptions.Exit(3) from exc  # 3 = lookup failed, SBOM was fine

    statements = (list(sbom.vex) + [s for _, file_statements in vex_files for s in file_statements]
                  + [s for report in yocto_reports for s in report.statements])
    kernel_statements = []
    if built is not None:
        kernel_statements = suggestions(lookup.findings, built, opts.kernel_sources.name)
        statements += kernel_statements
    lookup.findings = apply_statements(lookup.findings, statements)
    yocto_added = 0
    for report in yocto_reports:
        lookup.findings, added = add_unpatched(lookup.findings, report)
        yocto_added += added
    result = PipelineResult(lookup, catalogue, euvd, yocto_reports, vex_files, statements, yocto_added)
    result.offline = opts.offline
    if built is not None:
        result.kernel_list = opts.kernel_sources.name
        result.kernel_suggested = sum(1 for f in lookup.findings
                                      if f.vex_source and f.vex_source.startswith("kernel build file list"))
        console.print(f"[dim]Kernel build list {escape(opts.kernel_sources.name)} ({len(built)} files): "
                      f"{result.kernel_suggested} kernel finding(s) are only in source files the build does not "
                      "compile. They are SUGGESTED as 'not affected' (shown with the producer statements); a "
                      "person adopts or rejects them.[/dim]")
    return result


def open_cvelist(console: Console, err_console: Console, opts: LookupOptions) -> CveListIndex:
    """The local CVE List index, downloaded or refreshed first if needed (exit 3 if impossible)."""
    path = default_index_file()
    index = None
    try:
        index = CveListIndex.open(path)
    except VulnLookupError:
        pass
    if index is not None and (opts.offline or not index.is_stale()):
        if opts.offline and index.is_stale():
            err_console.print(f"[yellow]Offline: using the CVE List index from "
                              f"{index.meta.get('built', '?')[:10]} (older than 7 days).[/yellow]")
        return index
    if opts.offline:
        err_console.print("[bold red]Error:[/bold red] --offline: no CVE List index yet. Run 'keelbook update-db' "
                          "while online (or with --from-dir), or leave out --cve-list.")
        raise click.exceptions.Exit(3)
    try:
        with console.status("Getting the CVE List...") as status:
            download_and_build(path, progress=lambda text: status.update(escape(text)))
        return CveListIndex.open(path)
    except VulnLookupError as exc:
        if index is not None:
            err_console.print(f"[yellow]Warning:[/yellow] {escape(str(exc))} Using the existing CVE List index "
                              f"from {index.meta.get('built', '?')[:10]}.")
            return index
        err_console.print(f"[bold red]Error:[/bold red] {escape(str(exc))} Run without --cve-list, or build the "
                          "index from a copy of the list with 'keelbook update-db --from-dir PATH'.")
        raise click.exceptions.Exit(3) from exc


def _no_network(url: str) -> bytes:
    raise VulnLookupError("offline mode")
