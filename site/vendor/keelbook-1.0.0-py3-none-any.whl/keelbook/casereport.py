"""Markdown output for cases: report DRAFTS and the case evidence record.

Drafts are templates for a person to complete and check against ENISA's real
form on the single reporting platform. The tool never sends anything.
"""

from __future__ import annotations

from datetime import datetime

from keelbook import clocks
from keelbook.cases import CaseState, VerifyResult

TODO = "[TO COMPLETE]"

DRAFT_BANNER = (
    "> **DRAFT. Not submitted.** A person must complete and check this against the CRA text and "
    "the fields of ENISA's single reporting platform, and submit it there. "
    "Working aid, not legal advice."
)

# What each stage should contain, in the words of a checklist. Checked against the
# regulation text: CRA Art. 14(2)(a)-(c) (vulnerability) and Art. 14(4)(a)-(c) (incident).
FIELDS = {
    (clocks.VULNERABILITY, clocks.EARLY): [
        ("That the vulnerability is actively exploited", "Describe what you know. Do not wait for certainty."),
        ("Member States where the product is made available (where known)", None),
    ],
    (clocks.VULNERABILITY, clocks.NOTIFICATION): [
        ("General information about the product concerned", None),
        ("General nature of the exploit and of the vulnerability", None),
        ("Corrective or mitigating measures taken by you", None),
        ("Corrective or mitigating measures users can take", None),
        ("How sensitive you consider this information to be (where applicable)", None),
    ],
    (clocks.VULNERABILITY, clocks.FINAL): [
        ("Description of the vulnerability, including its severity and impact", None),
        ("Information about the malicious actor exploiting it (where available)", None),
        ("Details of the security update or other corrective measure made available", None),
    ],
    (clocks.INCIDENT, clocks.EARLY): [
        ("Whether the incident is suspected to be caused by unlawful or malicious acts", None),
        ("Member States where the product is made available (where known)", None),
    ],
    (clocks.INCIDENT, clocks.NOTIFICATION): [
        ("General information about the nature of the incident", None),
        ("Initial assessment of the incident", None),
        ("Corrective or mitigating measures taken, and measures users can take", None),
        ("How sensitive you consider this information to be (where applicable)", None),
    ],
    (clocks.INCIDENT, clocks.FINAL): [
        ("Detailed description of the incident, including its severity and impact", None),
        ("Type of threat or root cause that likely triggered the incident", None),
        ("Mitigation measures applied and ongoing", None),
    ],
}


def _t(moment: datetime | None) -> str:
    return moment.strftime("%Y-%m-%d %H:%M UTC") if moment else "-"


def _product(state: CaseState) -> str:
    return " ".join(x for x in (state.component, state.version) if x) or TODO


def render_draft(state: CaseState, stage: str) -> str:
    deadline = next(d for d in state.deadlines() if d.stage == stage)
    article = clocks.ARTICLE[state.track]
    lines = [
        f"# {clocks.STAGE_LABEL[stage]} - DRAFT - {state.case_id}",
        "",
        DRAFT_BANNER,
        "",
        f"Basis: CRA {article} ({state.track} track). Check the article reference against the regulation text.",
        "",
        "## Facts already recorded",
        "",
        f"- Case: {state.case_id} - {state.title}",
        f"- Product / component: {_product(state)}",
        f"- CVE IDs: {', '.join(state.cve_ids) or TODO}",
        f"- Became aware (UTC): {_t(state.aware_at)}",
        f"- How the manufacturer became aware: {state.aware_basis}",
        f"- Deadline for this stage: {_t(deadline.due) if deadline.due else 'not started (' + (deadline.waiting_for or '') + ')'}",
        f"- Member States recorded: {', '.join(state.member_states) or TODO}",
        *_scan_lines(state),
    ]
    if state.fix_at:
        lines.append(f"- Corrective/mitigating measure available (UTC): {_t(state.fix_at)} - {state.fix_description or ''}")
    lines += ["", "## Content to provide", ""]
    for title, hint in FIELDS[(state.track, stage)]:
        lines += [f"### {title}", "", f"{TODO}" + (f"  _({hint})_" if hint else ""), ""]
    lines += [
        "## Before you submit",
        "",
        "- [ ] Checked against ENISA's current form and the CRA text",
        "- [ ] Sign-off recorded: `keelbook case signoff " + f"{state.case_id} {stage} --approver \"NAME\"`",
        "- [ ] After submitting on the platform: `keelbook case submit " + f"{state.case_id} {stage} --reference \"PLATFORM REFERENCE\"`",
        "",
    ]
    return "\n".join(lines)


def _md(text: str) -> str:
    return str(text).replace("|", "\\|").replace("\n", " ").replace("\r", " ")


def _scan_lines(state: CaseState) -> list[str]:
    scan = state.from_scan
    if not scan:
        return []
    lines = [f"- Opened from scan file: {_md(scan.get('file') or '-')}, SHA-256 `{scan.get('sha256') or '-'}`",
             f"- Finding in that scan: {_md(scan.get('finding') or '-')}"]
    facts = [f"{label}: {_md(scan[key])}" for key, label in (
        ("severity", "severity"), ("kev_candidate", "CISA KEV"), ("euvd_exploited", "EUVD exploited"),
        ("producer_status", "producer statement")) if scan.get(key)]
    if facts:
        lines.append(f"- Scan data at the time: {'; '.join(facts)} (signals only, not a decision)")
    return lines


def render_record(state: CaseState, verification: VerifyResult, now: datetime, tool_version: str) -> str:
    lines = [
        f"# Case record - {state.case_id}",
        "",
        f"- Generated (UTC): {_t(now)}",
        f"- Tool: keelbook {tool_version}",
        f"- Title: {_md(state.title)}",
        f"- Track: {state.track} (CRA {clocks.ARTICLE[state.track]}, verify against the regulation text)",
        f"- Product / component: {_md(_product(state))}",
        f"- CVE IDs: {_md(', '.join(state.cve_ids) or '-')}",
        f"- Member States recorded: {', '.join(state.member_states) or '-'}",
        f"- Status: {'open' if state.is_open else 'closed - ' + _md(state.closed['reason'])}",
        "",
        "## Awareness",
        "",
        f"- Became aware (UTC): {_t(state.aware_at)}",
        f"- Basis stated by {_md(state.opened_by)}: {_md(state.aware_basis)}",
        f"- Recorded in the log at (UTC): {_t(state.opened_at)}",
        *_scan_lines(state),
        "",
        "## Deadlines and what happened",
        "",
        "| Stage | Rule | Due (UTC) | Submitted (UTC) | Result | Reference | Signed off before submission |",
        "|---|---|---|---|---|---|---|",
    ]
    for d in state.deadlines():
        sub = state.submissions.get(d.stage, [None])[0]
        submitted_at = sub["at"] if sub else None
        result = clocks.classify(d, submitted_at, now)
        if sub:
            signed = "yes" if state.signed_off_before_submission(d.stage) else "NO"
            ref = _md(sub["reference"] or "-")
        else:
            signed, ref = "-", "-"
        due = _t(d.due) if d.due else f"not started ({d.waiting_for})"
        lines.append(f"| {d.label} | {d.rule} | {due} | {_t(submitted_at)} | {result} | {ref} | {signed} |")
    if state.fix_at:
        lines += ["", f"Corrective or mitigating measure available (UTC): {_t(state.fix_at)} - {_md(state.fix_description or '')}"]

    lines += ["", "## Timeline (from the audit log)", "", "| # | Recorded (UTC) | By | Event | Details | Entry hash |", "|---|---|---|---|---|---|"]
    for e in state.events:
        details = ", ".join(f"{k}: {v}" for k, v in sorted(e.data.items()) if v not in (None, "", []))
        lines.append(f"| {e.seq} | {e.ts} | {_md(e.actor)} | {e.type} | {_md(details)} | `{e.hash[:12]}` |")

    lines += [
        "",
        "## Integrity of the log",
        "",
        f"- Chain check at generation time: {'OK' if verification.ok else 'FAILED - ' + str(verification.problem)}",
        f"- Entries in the whole log: {verification.count}",
        f"- Head hash: `{verification.head}`",
        "",
        "Keep the head hash somewhere outside this computer (ticket, email). Re-check later with "
        "`keelbook audit verify --head HASH`. Removing the newest entries is only detectable by comparing this value.",
        "",
        "## Important",
        "",
        "This record shows what people entered in the tool and when. Awareness, sign-offs and submissions "
        "are statements by named people, not verified facts. The tool does not submit anything to ENISA. "
        "Working aid, not legal advice.",
        "",
    ]
    return "\n".join(lines)
