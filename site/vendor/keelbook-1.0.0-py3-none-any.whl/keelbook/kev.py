"""CISA Known Exploited Vulnerabilities (KEV) matching.

The catalogue is read from a file you downloaded (--kev FILE), or downloaded by
the tool from CISA's official JSON feed (--kev-download, kept 24 hours in the user
cache folder). Either way the catalogue's release date is shown. Nothing about
your product is sent. Feed: https://www.cisa.gov/known-exploited-vulnerabilities-catalog

A KEV hit means "a candidate for an actively exploited vulnerability" (CRA
Art. 3(42)/Art. 14). It is NOT a legal decision: KEV is a US list, it is not
complete for EU products, and a person must decide what is reportable.
"""

from __future__ import annotations

import json
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable

from keelbook import __version__
from keelbook.errors import KevFileError, VulnLookupError
from keelbook.vulns import Finding

KEV_URL = "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json"
CACHE_TTL = timedelta(hours=24)
TIMEOUT_SECONDS = 60
KevHttpFn = Callable[[str], bytes]


@dataclass(frozen=True)
class KevEntry:
    cve_id: str
    date_added: str | None = None
    due_date: str | None = None
    ransomware: str | None = None  # "Known" / "Unknown" as published by CISA
    required_action: str | None = None


@dataclass(frozen=True)
class KevCatalogue:
    entries: dict[str, KevEntry]
    released: str | None = None  # dateReleased, so the user sees how old the data is
    version: str | None = None
    downloaded_at: str | None = None  # ISO time, when the tool downloaded it (--kev-download)
    from_cache: bool = False  # True: a copy downloaded earlier was used


def _str(value: Any) -> str | None:
    return value.strip() if isinstance(value, str) and value.strip() else None


def load_kev(path: Path) -> KevCatalogue:
    try:
        raw = path.read_text(encoding="utf-8")
    except FileNotFoundError as exc:
        raise KevFileError(f"KEV file not found: {path}") from exc
    except (OSError, UnicodeDecodeError) as exc:
        raise KevFileError(f"Could not read KEV file {path}: {exc}") from exc
    return parse_kev(raw, path)


def default_cache_file() -> Path:
    from keelbook.nvd import cache_root
    return cache_root() / "cisa-kev.json"


def _default_http(url: str) -> bytes:
    request = urllib.request.Request(url, headers={"User-Agent": f"keelbook/{__version__}"})
    with urllib.request.urlopen(request, timeout=TIMEOUT_SECONDS) as response:
        return response.read()


def fetch_kev(cache_file: Path | None, http: KevHttpFn = _default_http,
              now: datetime | None = None) -> tuple[KevCatalogue, str | None]:
    """Download CISA KEV, or use a copy younger than 24 h. Returns (catalogue, warning).

    If the download fails, an older copy is used with a warning; without any copy
    the error is raised (VulnLookupError).
    """
    now = now or datetime.now(timezone.utc)
    cached = _read_cache(cache_file)
    if cached is not None and now - cached[1] < CACHE_TTL:
        return _with(cached[0], cached[1], from_cache=True), None
    try:
        raw = http(KEV_URL)
        catalogue = parse_kev(raw.decode("utf-8"), KEV_URL)
    except (KevFileError, UnicodeDecodeError) as exc:
        error = f"CISA's KEV feed returned something unexpected ({exc})."
    except Exception as exc:  # network or HTTP problem
        error = f"Could not download CISA KEV ({exc})."
    else:
        if cache_file is not None:
            try:
                cache_file.parent.mkdir(parents=True, exist_ok=True)
                cache_file.write_text(json.dumps({"downloaded_at": now.isoformat(), "raw": raw.decode("utf-8")}),
                                      encoding="utf-8")
            except OSError:
                pass  # a cache that cannot be written only costs a download next time
        return _with(catalogue, now, from_cache=False), None
    if cached is not None:
        age = now - cached[1]
        return (_with(cached[0], cached[1], from_cache=True),
                f"{error} Using the copy downloaded {cached[1].date().isoformat()} "
                f"({age.days} day(s) old).")
    raise VulnLookupError(error)


def _with(catalogue: KevCatalogue, when: datetime, from_cache: bool) -> KevCatalogue:
    return KevCatalogue(catalogue.entries, catalogue.released, catalogue.version,
                        downloaded_at=when.replace(microsecond=0).isoformat(), from_cache=from_cache)


def _read_cache(cache_file: Path | None) -> tuple[KevCatalogue, datetime] | None:
    if cache_file is None or not cache_file.exists():
        return None
    try:
        data = json.loads(cache_file.read_text(encoding="utf-8"))
        return parse_kev(data["raw"], cache_file), datetime.fromisoformat(data["downloaded_at"])
    except (OSError, ValueError, KeyError, TypeError, KevFileError):
        return None


def parse_kev(raw: str, path: Path | str) -> KevCatalogue:
    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise KevFileError(f"KEV file {path} is not valid JSON (line {exc.lineno}).") from exc

    items = data.get("vulnerabilities") if isinstance(data, dict) else None
    if not isinstance(items, list):
        raise KevFileError(
            f"{path} does not look like the CISA KEV JSON catalogue "
            "(no 'vulnerabilities' list). Download the JSON version, not the CSV."
        )

    entries: dict[str, KevEntry] = {}
    for item in items:
        if not isinstance(item, dict):
            continue
        cve = _str(item.get("cveID"))
        if not cve:
            continue
        entries[cve.upper()] = KevEntry(
            cve_id=cve.upper(),
            date_added=_str(item.get("dateAdded")),
            due_date=_str(item.get("dueDate")),
            ransomware=_str(item.get("knownRansomwareCampaignUse")),
            required_action=_str(item.get("requiredAction")),
        )
    if not entries:
        raise KevFileError(f"{path} contains no usable KEV entries.")
    return KevCatalogue(
        entries=entries,
        released=_str(data.get("dateReleased")),
        version=_str(data.get("catalogVersion")),
    )


def kev_matches(finding: Finding, catalogue: KevCatalogue) -> list[KevEntry]:
    """KEV entries for any CVE ID of this finding (empty if none)."""
    return [catalogue.entries[c] for c in finding.cve_ids if c in catalogue.entries]
