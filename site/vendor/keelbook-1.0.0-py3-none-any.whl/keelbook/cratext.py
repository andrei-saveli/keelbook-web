"""Short verbatim quotes from the Cyber Resilience Act for the evidence record.

Each text is copied word for word from Regulation (EU) 2024/2847 as published on
EUR-Lex (documents/Cyber-Resilience-Act.md in this repository). A test checks that
every quote still appears verbatim in that file, so a typo cannot slip in.
Quotes are context for the reader, not a legal assessment.
"""

from __future__ import annotations

SOURCE = ("Regulation (EU) 2024/2847 of the European Parliament and of the Council of 23 October 2024 "
          "(Cyber Resilience Act), OJ L, 20.11.2024, https://eur-lex.europa.eu/eli/reg/2024/2847/oj")

# (reference, verbatim text)
QUOTES: tuple[tuple[str, str], ...] = (
    ("Art. 13(7)",
     "The manufacturers shall systematically document, in a manner that is proportionate to the nature and "
     "the cybersecurity risks, relevant cybersecurity aspects concerning the products with digital elements, "
     "including vulnerabilities of which they become aware and any relevant information provided by third "
     "parties, and shall, where applicable, update the cybersecurity risk assessment of the products."),
    ("Art. 13(8), first subparagraph",
     "Manufacturers shall ensure, when placing a product with digital elements on the market, and for the "
     "support period, that vulnerabilities of that product, including its components, are handled effectively "
     "and in accordance with the essential cybersecurity requirements set out in Part II of Annex I."),
    ("Annex I, Part II, point (1)",
     "identify and document vulnerabilities and components contained in products with digital elements, "
     "including by drawing up a software bill of materials in a commonly used and machine-readable format "
     "covering at the very least the top-level dependencies of the products;"),
    ("Annex I, Part II, point (2)",
     "in relation to the risks posed to products with digital elements, address and remediate vulnerabilities "
     "without delay, including by providing security updates; where technically feasible, new security updates "
     "shall be provided separately from functionality updates;"),
    ("Annex I, Part II, point (5)",
     "put in place and enforce a policy on coordinated vulnerability disclosure;"),
    ("Annex I, Part II, point (6)",
     "take measures to facilitate the sharing of information about potential vulnerabilities in their product "
     "with digital elements as well as in third-party components contained in that product, including by "
     "providing a contact address for the reporting of the vulnerabilities discovered in the product with "
     "digital elements;"),
    ("Art. 13(17), first subparagraph",
     "For the purposes of this Regulation, manufacturers shall designate a single point of contact to enable "
     "users to communicate directly and rapidly with them, including in order to facilitate reporting on "
     "vulnerabilities of the product with digital elements."),
)
