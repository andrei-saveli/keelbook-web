"""Linux kernel: suggest "not affected" for CVEs in source files that are not built.

A kernel scan gives thousands of findings, most of them in drivers and features
a device does not build. The Linux kernel CNA names the source files each CVE
is in ("programFiles" in the CVE record, read via --cve-list). With the list of
files the kernel build compiled, a CVE whose files were all not compiled can be
suggested as "not affected: vulnerable code not present".

It is a SUGGESTION, shown like a producer statement. Nothing is decided: a person
adopts it ('product accept-producer') or decides otherwise. Rules, to stay safe:

* only findings for the Linux kernel (CPE product linux_kernel);
* only if the record names files, and every named file is a C or assembly file
  (a header can be used by built files even when no .o of its own exists);
* only if none of those files appears in the build list.

How to make the list (in the kernel build folder, after a build):
    find . -name '*.o' > kernel-sources.txt
Paths may be relative or absolute; .o names are read as the matching .c file.
"""

from __future__ import annotations

from pathlib import Path

from keelbook.cpe import parse_cpe, unescape
from keelbook.errors import SbomError
from keelbook.models import NOT_AFFECTED, VexStatement
from keelbook.vulns import Finding

# Top-level folders of the kernel source tree: used to cut absolute paths.
TOP_DIRS = ("arch", "block", "certs", "crypto", "drivers", "fs", "init", "io_uring", "ipc", "kernel",
            "lib", "mm", "net", "rust", "samples", "security", "sound", "virt", "usr")
BUILT_SUFFIXES = (".c", ".S", ".s")
SOURCE = "kernel build file list"


def _normalise(line: str) -> str | None:
    text = line.strip().replace("\\", "/")
    if not text or text.startswith("#"):
        return None
    parts = [p for p in text.split("/") if p not in ("", ".")]
    for i, part in enumerate(parts):
        if part in TOP_DIRS:
            parts = parts[i:]
            break
    path = "/".join(parts)
    if path.endswith(".o"):
        path = path[:-2] + ".c"
    return path or None


def load_kernel_sources(path: Path) -> set[str]:
    """Paths of compiled kernel source files, e.g. {'net/core/sock.c', ...}."""
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError as exc:
        raise SbomError(f"Could not read the kernel build list {path}: {exc}") from exc
    files = {p for p in (_normalise(line) for line in text.splitlines()) if p}
    if not files:
        raise SbomError(f"The kernel build list {path} contains no file names.")
    if not any(f.endswith(BUILT_SUFFIXES) for f in files):
        raise SbomError(f"The kernel build list {path} names no .c/.o files. Make it in the kernel build "
                        "folder with: find . -name '*.o' > kernel-sources.txt")
    return files


def is_kernel(finding: Finding) -> bool:
    cpe = parse_cpe(finding.component.cpe)
    return cpe is not None and unescape(cpe.product).lower() == "linux_kernel"


def suggestions(findings: list[Finding], built: set[str], list_name: str) -> list[VexStatement]:
    """'not affected' suggestions for kernel findings whose named files were not built."""
    out = []
    for finding in findings:
        files = finding.program_files
        if not files or not is_kernel(finding) or not finding.cve_ids:
            continue
        if not all(f.endswith(BUILT_SUFFIXES) for f in files):
            continue
        if any(f in built for f in files):
            continue
        names = {finding.component.name.lower(), *(n.lower() for n in finding.also_in)}
        shown = ", ".join(files[:3]) + (" ..." if len(files) > 3 else "")
        for cve in finding.cve_ids:
            out.append(VexStatement(
                cve_id=cve, status=NOT_AFFECTED, targets=frozenset(names),
                source=f"{SOURCE} ({list_name})",
                detail=f"vulnerable_code_not_present: not built ({shown})",
            ))
    return out
