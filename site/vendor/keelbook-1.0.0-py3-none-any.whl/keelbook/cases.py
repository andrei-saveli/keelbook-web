"""Case store: an append-only, hash-chained event log in SQLite.

Every action (open a case, record a fix, record a submission, sign off ...)
is ONE event row. Nothing is ever updated or deleted; the state of a case is
derived by replaying its events. Each event contains the hash of the previous
event, so changing or removing an old row breaks the chain and `verify()`
reports where.

Honest limits:
* Someone with full access to the file can rewrite the whole chain. To detect
  that, write down the head hash somewhere else (email, ticket) from time to
  time and compare it with `audit verify --head`.
* The 'actor' is a name the user gives, not an authenticated identity.
"""

from __future__ import annotations

import hashlib
import json
import re
import sqlite3
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from keelbook import clocks
from keelbook.errors import CaseError

GENESIS = "0" * 64

OPENED = "case_opened"
FIX = "fix_available"
SUBMITTED = "report_submitted"
SIGNOFF = "signoff"
NOTE = "note"
CLOSED = "case_closed"

SCHEMA = """
CREATE TABLE IF NOT EXISTS events (
    seq INTEGER PRIMARY KEY,
    case_id TEXT NOT NULL,
    type TEXT NOT NULL,
    ts TEXT NOT NULL,
    actor TEXT NOT NULL,
    data TEXT NOT NULL,
    prev_hash TEXT NOT NULL,
    hash TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS events_case ON events(case_id);
CREATE TRIGGER IF NOT EXISTS events_no_update BEFORE UPDATE ON events
BEGIN SELECT RAISE(ABORT, 'the audit log is append-only'); END;
CREATE TRIGGER IF NOT EXISTS events_no_delete BEFORE DELETE ON events
BEGIN SELECT RAISE(ABORT, 'the audit log is append-only'); END;
"""


@dataclass(frozen=True)
class Event:
    seq: int
    case_id: str
    type: str
    ts: str  # when it was recorded (UTC, ISO 8601)
    actor: str
    data: dict[str, Any]
    prev_hash: str
    hash: str


@dataclass(frozen=True)
class VerifyResult:
    ok: bool
    count: int
    head: str
    problem: str | None = None


def compute_hash(seq: int, case_id: str, type_: str, ts: str, actor: str, data: dict, prev_hash: str) -> str:
    canonical = json.dumps(
        {"seq": seq, "case_id": case_id, "type": type_, "ts": ts, "actor": actor, "data": data, "prev": prev_hash},
        sort_keys=True, separators=(",", ":"), ensure_ascii=True,
    )
    return hashlib.sha256(canonical.encode("ascii")).hexdigest()


def _iso(moment: datetime) -> str:
    return moment.astimezone(timezone.utc).replace(microsecond=0).isoformat()


def _from_iso(text: str) -> datetime:
    return datetime.fromisoformat(text).astimezone(timezone.utc)


def normalise_case_id(text: str) -> str:
    text = text.strip().upper()
    if text.isdigit():
        return f"CASE-{int(text):04d}"
    match = re.fullmatch(r"CASE-?(\d+)", text)
    return f"CASE-{int(match.group(1)):04d}" if match else text


@dataclass
class CaseState:
    case_id: str
    track: str
    title: str
    component: str | None
    version: str | None
    cve_ids: list[str]
    member_states: list[str]
    aware_at: datetime
    aware_basis: str
    opened_by: str
    opened_at: datetime
    fix_at: datetime | None = None
    fix_description: str | None = None
    submissions: dict[str, list[dict]] = field(default_factory=dict)
    signoffs: dict[str, list[dict]] = field(default_factory=dict)
    closed: dict | None = None
    events: list[Event] = field(default_factory=list)
    from_scan: dict | None = None  # which scan file/finding the case was opened from

    def first_submission_at(self, stage: str) -> datetime | None:
        items = self.submissions.get(stage)
        return items[0]["at"] if items else None

    def deadlines(self) -> list[clocks.Deadline]:
        return clocks.compute_deadlines(
            self.track, self.aware_at, self.fix_at, self.first_submission_at(clocks.NOTIFICATION)
        )

    def signed_off_before_submission(self, stage: str) -> bool:
        subs, signs = self.submissions.get(stage), self.signoffs.get(stage)
        if not subs or not signs:
            return False
        return any(s["seq"] < subs[0]["seq"] for s in signs)

    @property
    def is_open(self) -> bool:
        return self.closed is None


def _build_state(case_id: str, events: list[Event]) -> CaseState:
    if not events or events[0].type != OPENED:
        raise CaseError(f"No such case: {case_id}")
    first = events[0]
    d = first.data
    state = CaseState(
        case_id=case_id,
        track=d["track"],
        title=d["title"],
        component=d.get("component"),
        version=d.get("version"),
        cve_ids=list(d.get("cve_ids") or []),
        member_states=list(d.get("member_states") or []),
        aware_at=_from_iso(d["aware_at"]),
        aware_basis=d.get("aware_basis", ""),
        opened_by=first.actor,
        opened_at=_from_iso(first.ts),
        events=events,
        from_scan=d.get("from_scan") if isinstance(d.get("from_scan"), dict) else None,
    )
    for event in events[1:]:
        d = event.data
        if event.type == FIX:
            state.fix_at = _from_iso(d["at"])
            state.fix_description = d.get("description")
        elif event.type == SUBMITTED:
            state.submissions.setdefault(d["stage"], []).append(
                {"at": _from_iso(d["at"]), "reference": d.get("reference"), "by": event.actor,
                 "recorded_at": _from_iso(event.ts), "seq": event.seq}
            )
        elif event.type == SIGNOFF:
            state.signoffs.setdefault(d["stage"], []).append(
                {"approver": d["approver"], "note": d.get("note"), "by": event.actor,
                 "at": _from_iso(event.ts), "seq": event.seq}
            )
        elif event.type == CLOSED:
            state.closed = {"reason": d.get("reason", ""), "at": _from_iso(event.ts), "by": event.actor}
    return state


def _need_stage(stage: str) -> None:
    if stage not in clocks.STAGES:
        raise CaseError(f"Unknown stage '{stage}'. Use one of: {', '.join(clocks.STAGES)}.")


class Store:
    def __init__(self, path: Path, create: bool = False):
        path = Path(path)
        if not create and not path.exists():
            raise CaseError(f"No database at {path}. Start with 'keelbook product add' (register) or "
                            "'keelbook case open' (Art. 14 case), or point --db / KEELBOOK_DB at your file.")
        try:
            self._db = sqlite3.connect(str(path), isolation_level=None)  # explicit transactions
            self._db.executescript(SCHEMA)  # idempotent
        except sqlite3.Error as exc:
            raise CaseError(f"Cannot open the case database {path}: {exc}") from exc

    def close(self) -> None:
        self._db.close()

    # --- writing -----------------------------------------------------------

    def _append(self, case_id: str | None, type_: str, actor: str, data: dict, now: datetime | None) -> Event:
        return self._append_many([(case_id, type_, actor, data)], now, cases_only=True)[0]

    def append_subject_events(self, items: list[tuple[str, str, str, dict]], now: datetime | None = None) -> list[Event]:
        """Append events for a non-case subject (e.g. "PRODUCT:router-x") in ONE transaction:
        either all are recorded or none. Used by the vulnerability register."""
        for subject, *_ in items:
            if not subject or subject.upper().startswith("CASE"):
                raise CaseError(f"Invalid subject for the log: {subject!r}")
        return self._append_many(items, now, cases_only=False)

    def events_for(self, subject: str) -> list[Event]:
        return self._events(subject)

    def _append_many(self, items: list[tuple[str | None, str, str, dict]], now: datetime | None,
                     cases_only: bool) -> list[Event]:
        ts = _iso(now or datetime.now(timezone.utc))
        cur = self._db.cursor()
        cur.execute("BEGIN IMMEDIATE")  # one writer at a time, so the chain stays linear
        events: list[Event] = []
        try:
            row = cur.execute("SELECT seq, hash FROM events ORDER BY seq DESC LIMIT 1").fetchone()
            seq, prev = (row[0], row[1]) if row else (0, GENESIS)
            for case_id, type_, actor, data in items:
                seq += 1
                if cases_only and case_id is None:
                    count = cur.execute("SELECT COUNT(*) FROM events WHERE type = ?", (OPENED,)).fetchone()[0]
                    case_id = f"CASE-{count + 1:04d}"
                elif cases_only:
                    exists = cur.execute(
                        "SELECT 1 FROM events WHERE case_id = ? AND type = ? LIMIT 1", (case_id, OPENED)
                    ).fetchone()
                    if not exists:
                        raise CaseError(f"No such case: {case_id}")
                digest = compute_hash(seq, case_id, type_, ts, actor, data, prev)
                cur.execute(
                    "INSERT INTO events (seq, case_id, type, ts, actor, data, prev_hash, hash) VALUES (?,?,?,?,?,?,?,?)",
                    (seq, case_id, type_, ts, actor, json.dumps(data, sort_keys=True, separators=(",", ":")),
                     prev, digest),
                )
                events.append(Event(seq, case_id, type_, ts, actor, data, prev, digest))
                prev = digest
            cur.execute("COMMIT")
        except BaseException:
            cur.execute("ROLLBACK")
            raise
        return events

    def open_case(self, *, track: str, title: str, component: str | None, version: str | None,
                  cve_ids: list[str], member_states: list[str], aware_at: datetime, aware_basis: str,
                  actor: str, now: datetime | None = None, from_scan: dict | None = None) -> Event:
        if track not in clocks.TRACKS:
            raise CaseError(f"Unknown track '{track}'.")
        if not title.strip() or not aware_basis.strip():
            raise CaseError("A case needs a title and a statement of how you became aware.")
        data = {"track": track, "title": title.strip(), "component": component, "version": version,
                "cve_ids": sorted(set(c.upper() for c in cve_ids)), "member_states": sorted(set(m.upper() for m in member_states)),
                "aware_at": _iso(aware_at), "aware_basis": aware_basis.strip()}
        if from_scan:
            data["from_scan"] = from_scan  # only added when used, so older hashes stay valid
        return self._append(None, OPENED, actor, data, now)

    def add_fix(self, case_id: str, at: datetime, description: str, actor: str, now: datetime | None = None) -> Event:
        state = self.state(case_id)
        if state.track != clocks.VULNERABILITY:
            raise CaseError("'fix' only applies to the vulnerability track. For an incident, the final-report "
                            "clock starts when the notification is submitted ('case submit').")
        return self._append(state.case_id, FIX, actor, {"at": _iso(at), "description": description.strip()}, now)

    def add_submission(self, case_id: str, stage: str, at: datetime, reference: str | None, actor: str,
                       now: datetime | None = None) -> Event:
        self._need_open(case_id)
        _need_stage(stage)
        return self._append(normalise_case_id(case_id), SUBMITTED, actor,
                            {"stage": stage, "at": _iso(at), "reference": reference}, now)

    def add_signoff(self, case_id: str, stage: str, approver: str, note: str | None, actor: str,
                    now: datetime | None = None) -> Event:
        self._need_open(case_id)
        _need_stage(stage)
        if not approver.strip():
            raise CaseError("A sign-off needs the name of the approver.")
        return self._append(normalise_case_id(case_id), SIGNOFF, actor,
                            {"stage": stage, "approver": approver.strip(), "note": note}, now)

    def add_note(self, case_id: str, text: str, actor: str, now: datetime | None = None) -> Event:
        self.state(case_id)
        return self._append(normalise_case_id(case_id), NOTE, actor, {"text": text.strip()}, now)

    def close_case(self, case_id: str, reason: str, actor: str, now: datetime | None = None) -> Event:
        self._need_open(case_id)
        return self._append(normalise_case_id(case_id), CLOSED, actor, {"reason": reason.strip()}, now)

    def _need_open(self, case_id: str) -> None:
        if not self.state(case_id).is_open:
            raise CaseError(f"{normalise_case_id(case_id)} is closed.")

    # --- reading -----------------------------------------------------------

    def _events(self, case_id: str | None = None) -> list[Event]:
        query = "SELECT seq, case_id, type, ts, actor, data, prev_hash, hash FROM events"
        args: tuple = ()
        if case_id:
            query += " WHERE case_id = ?"
            args = (case_id,)
        rows = self._db.execute(query + " ORDER BY seq", args).fetchall()
        return [Event(r[0], r[1], r[2], r[3], r[4], json.loads(r[5]), r[6], r[7]) for r in rows]

    def state(self, case_id: str) -> CaseState:
        case_id = normalise_case_id(case_id)
        return _build_state(case_id, self._events(case_id))

    def cases(self) -> list[CaseState]:
        by_case: dict[str, list[Event]] = {}
        for event in self._events():
            by_case.setdefault(event.case_id, []).append(event)
        # The same log also holds the vulnerability register (subjects "PRODUCT:...").
        return [_build_state(cid, evs) for cid, evs in by_case.items() if evs[0].type == OPENED]

    def verify(self) -> VerifyResult:
        prev, count = GENESIS, 0
        for event in self._events():
            count += 1
            if event.seq != count:
                return VerifyResult(False, count, prev, f"entry {count} is missing or out of order (found #{event.seq})")
            if event.prev_hash != prev:
                return VerifyResult(False, count, prev, f"entry #{event.seq} does not link to the entry before it")
            expected = compute_hash(event.seq, event.case_id, event.type, event.ts, event.actor, event.data, prev)
            if expected != event.hash:
                return VerifyResult(False, count, prev, f"entry #{event.seq} ({event.case_id}, {event.type}) was changed")
            prev = event.hash
        return VerifyResult(True, count, prev)
