"""Command-line layer for the Art. 14 case workflow (click + rich).

Presentation only: the rules live in `clocks`, the data in `cases`, the text
output in `casereport`. Exit codes: 0 ok, 1 problem the user can fix (unknown
case, bad time, closed case, tampered log), 2 wrong usage.
"""

from __future__ import annotations

import getpass
from datetime import datetime, timezone
from pathlib import Path

import click
from rich.console import Console
from rich.markup import escape
from rich.table import Table
from rich.text import Text

from keelbook import __version__, clocks
from keelbook.casereport import render_draft, render_record
from keelbook.cases import CaseState, Store, normalise_case_id
from keelbook.errors import CaseError
from keelbook.scanlink import finding_from_csv

NOT_SENT = (
    "This tool sends nothing. A person submits each report on ENISA's single reporting "
    "platform and then records it here with 'case submit'."
)


def _default_actor() -> str:
    try:
        return getpass.getuser()
    except Exception:  # no login name available (containers, odd environments)
        return "unknown"


DEFAULT_DB = "keelbook.db"
OLD_DEFAULT_DB = "cra-cases.db"  # name used before the rename to Keelbook


def _default_db() -> str:
    """keelbook.db, unless only a database from before the rename exists here."""
    if not Path(DEFAULT_DB).exists() and Path(OLD_DEFAULT_DB).exists():
        return OLD_DEFAULT_DB
    return DEFAULT_DB


def common_options(func):
    """--db and --by, shared by every command."""
    func = click.option(
        "--by", "actor", default=_default_actor, envvar=["KEELBOOK_USER", "CRA_TOOL_USER"],
        show_default="your login name",
        help="Who is recording this. A name for the log, not a login check.",
    )(func)
    func = click.option(
        "--db", "db_path", type=click.Path(path_type=Path, dir_okay=False), default=_default_db,
        envvar=["KEELBOOK_DB", "CRA_TOOL_DB"], show_default=DEFAULT_DB,
        help="Database file (register, cases and log). Default: keelbook.db in the current folder.",
    )(func)
    return func


def _fmt(moment: datetime | None) -> str:
    return moment.astimezone(timezone.utc).strftime("%Y-%m-%d %H:%M UTC") if moment else "-"


def _when(text: str) -> datetime:
    try:
        return clocks.parse_when(text)
    except ValueError as exc:
        raise CaseError(str(exc)) from exc


def _fail(exc: Exception) -> None:
    Console(stderr=True).print(f"[bold red]Error:[/bold red] {escape(str(exc))}")
    raise click.exceptions.Exit(1) from exc


def _deadline_lines(console: Console, state: CaseState, now: datetime) -> None:
    for d in state.deadlines():
        sub_at = state.first_submission_at(d.stage)
        status = clocks.classify(d, sub_at, now)
        if d.due is None:
            when = f"not started - {d.waiting_for}" if not sub_at else "submitted"
        else:
            when = f"{_fmt(d.due)}  ({'submitted ' + _fmt(sub_at) if sub_at else clocks.time_left_text(d.due, now)})"
        style = {"overdue": "bold red", "LATE": "bold red", "on time": "green", "open": "yellow"}.get(status, "dim")
        console.print(Text(f"  {d.label:<13} {status:<9} {when}", style=style))


@click.group()
def case() -> None:
    """Art. 14 reporting cases: open, track deadlines, sign off, draft, export."""


@case.command("open")
@click.option("--track", type=click.Choice(clocks.TRACKS), required=True,
              help="vulnerability = actively exploited vulnerability; incident = severe incident.")
@click.option("--title", help="Short description, e.g. 'log4j exploited in the field'. "
              "Required unless --from-csv is used.")
@click.option("--component", help="Affected component name.")
@click.option("--product-version", "version", help="Affected version.")
@click.option("--cve", "cves", multiple=True, help="CVE ID (repeatable).")
@click.option("--member-state", "member_states", multiple=True, help="EU Member State code where the product is on the market (repeatable).")
@click.option("--aware-at", default="now", show_default=True,
              help="When the manufacturer BECAME AWARE (ISO time or 'now'). This starts the 24h/72h clocks.")
@click.option("--basis", required=True, help="How and why you became aware (what evidence). A person's judgement, recorded verbatim.")
@click.option("--from-csv", "from_csv", type=click.Path(path_type=Path, dir_okay=False),
              help="Take component, version and CVE IDs from a findings CSV written by 'keelbook scan --csv'. "
              "The case records the file and its SHA-256. Needs --finding.")
@click.option("--finding", "finding_id", help="The finding to open the case for (CVE or other ID in the CSV).")
@common_options
def open_cmd(track, title, component, version, cves, member_states, aware_at, basis, from_csv, finding_id,
             db_path, actor):
    """Open a case. Starts the clocks from the moment you became aware."""
    console = Console()
    if bool(from_csv) != bool(finding_id):
        raise click.UsageError("--from-csv and --finding go together.")
    if not from_csv and not title:
        raise click.UsageError("Missing option '--title' (or use --from-csv with --finding).")
    try:
        from_scan = None
        if from_csv:
            facts = finding_from_csv(from_csv, finding_id, component)
            component = component or facts["component"]
            version = version or facts["version"]
            cves = tuple(cves) or tuple(facts["cve_ids"])
            from_scan = facts["scan"]
            title = title or f"{', '.join(cves) or facts['finding']} in {component or '?'} {version or ''}".strip()
        aware = _when(aware_at)
        store = Store(db_path, create=True)
        try:
            event = store.open_case(track=track, title=title, component=component, version=version,
                                    cve_ids=list(cves), member_states=list(member_states),
                                    aware_at=aware, aware_basis=basis, actor=actor, from_scan=from_scan)
            state = store.state(event.case_id)
        finally:
            store.close()
    except CaseError as exc:
        _fail(exc)
    now = datetime.now(timezone.utc)
    console.print(f"[bold]Opened {event.case_id}[/bold] ({track} track, {clocks.ARTICLE[track]})")
    console.print(f"Aware at: {_fmt(aware)}  <- check this is the time you meant")
    if from_scan:
        console.print(Text(f"From scan: {from_scan['file']} (SHA-256 {from_scan['sha256'][:12]}...), "
                           f"finding {from_scan['finding']} in {state.component or '-'} {state.version or ''}"))
    _deadline_lines(console, state, now)
    console.print(f"[dim]{escape(NOT_SENT)}[/dim]")
    console.print(f"[dim]Log entry #{event.seq}, hash {event.hash[:12]}. Article references: verify against the CRA text.[/dim]")


@case.command("list")
@click.option("--all", "show_all", is_flag=True, help="Include closed cases.")
@common_options
def list_cmd(show_all, db_path, actor):
    """List cases with their next deadline."""
    console = Console()
    try:
        store = Store(db_path)
        try:
            cases = store.cases()
        finally:
            store.close()
    except CaseError as exc:
        _fail(exc)
    now = datetime.now(timezone.utc)
    table = Table(title="Cases")
    for col in ("Case", "Track", "Title", "Status", "Next deadline"):
        table.add_column(col, overflow="fold")
    shown = 0
    for st in cases:
        if not st.is_open and not show_all:
            continue
        shown += 1
        pending = [d for d in st.deadlines() if d.due and not st.first_submission_at(d.stage)]
        nxt = min(pending, key=lambda d: d.due) if pending else None
        text = f"{nxt.label}: {clocks.time_left_text(nxt.due, now)}" if nxt else ("nothing due" if st.is_open else "-")
        table.add_row(Text(st.case_id), Text(st.track), Text(st.title), Text("open" if st.is_open else "closed"), Text(text))
    if not shown:
        console.print("No open cases." + ("" if show_all else " (use --all to include closed ones)"))
        return
    console.print(table)


@case.command("show")
@click.argument("case_id")
@common_options
def show_cmd(case_id, db_path, actor):
    """Show one case: facts, deadlines and timeline."""
    console = Console()
    try:
        store = Store(db_path)
        try:
            st = store.state(case_id)
        finally:
            store.close()
    except CaseError as exc:
        _fail(exc)
    now = datetime.now(timezone.utc)
    console.print(Text(f"{st.case_id}: {st.title}", style="bold"))
    console.print(Text(f"Track: {st.track} ({clocks.ARTICLE[st.track]}) | Status: {'open' if st.is_open else 'closed: ' + st.closed['reason']}"))
    console.print(Text(f"Product: {' '.join(x for x in (st.component, st.version) if x) or '-'} | CVE: {', '.join(st.cve_ids) or '-'}"))
    console.print(Text(f"Aware at: {_fmt(st.aware_at)} | Basis: {st.aware_basis}"))
    if st.from_scan:
        console.print(Text(f"Opened from scan: {st.from_scan.get('file')} (SHA-256 {str(st.from_scan.get('sha256'))[:12]}...), "
                           f"finding {st.from_scan.get('finding')}"))
    if st.fix_at:
        console.print(Text(f"Fix/mitigation available: {_fmt(st.fix_at)} - {st.fix_description or ''}"))
    console.print("Deadlines:")
    _deadline_lines(console, st, now)
    for stage in clocks.STAGES:
        subs = st.submissions.get(stage)
        if subs and not st.signed_off_before_submission(stage):
            console.print(Text(f"  Note: {clocks.STAGE_LABEL[stage]} was submitted without a sign-off recorded before it.", style="yellow"))
    console.print("Timeline:")
    for e in st.events:
        details = ", ".join(f"{k}={v}" for k, v in sorted(e.data.items()) if v not in (None, "", []))
        console.print(Text(f"  #{e.seq} {e.ts} {e.actor}: {e.type} {details}", style="dim"))


@case.command("fix")
@click.argument("case_id")
@click.option("--at", "at", default="now", show_default=True, help="When a corrective or mitigating measure became available.")
@click.option("--description", required=True, help="What the fix or mitigation is (e.g. 'firmware 2.1.4 released').")
@common_options
def fix_cmd(case_id, at, description, db_path, actor):
    """Record that a fix or mitigation is available. Starts the 14-day final-report clock (vulnerability track)."""
    console = Console()
    try:
        when = _when(at)
        store = Store(db_path)
        try:
            event = store.add_fix(case_id, when, description, actor)
            st = store.state(case_id)
        finally:
            store.close()
    except CaseError as exc:
        _fail(exc)
    console.print(f"Recorded fix/mitigation at {_fmt(when)} for {event.case_id}.")
    _deadline_lines(console, st, datetime.now(timezone.utc))
    console.print(f"[dim]Log entry #{event.seq}, hash {event.hash[:12]}.[/dim]")


@case.command("submit")
@click.argument("case_id")
@click.argument("stage", type=click.Choice(clocks.STAGES))
@click.option("--at", "at", default="now", show_default=True, help="When you submitted it on the platform.")
@click.option("--reference", help="Reference or ID the platform gave you.")
@common_options
def submit_cmd(case_id, stage, at, reference, db_path, actor):
    """Record that a person submitted a report on the platform (this tool sends nothing)."""
    console = Console()
    try:
        when = _when(at)
        store = Store(db_path)
        try:
            event = store.add_submission(case_id, stage, when, reference, actor)
            st = store.state(case_id)
        finally:
            store.close()
    except CaseError as exc:
        _fail(exc)
    deadline = next(d for d in st.deadlines() if d.stage == stage)
    verdict = clocks.classify(deadline, st.first_submission_at(stage), datetime.now(timezone.utc))
    console.print(f"Recorded {clocks.STAGE_LABEL[stage]} for {event.case_id} at {_fmt(when)}: [bold]{verdict}[/bold].")
    if not st.signed_off_before_submission(stage):
        console.print(f"[yellow]No sign-off was recorded before this submission ('case signoff').[/yellow]")
    _deadline_lines(console, st, datetime.now(timezone.utc))
    console.print(f"[dim]Log entry #{event.seq}, hash {event.hash[:12]}.[/dim]")


@case.command("signoff")
@click.argument("case_id")
@click.argument("stage", type=click.Choice(clocks.STAGES))
@click.option("--approver", required=True, help="Name of the person who approves this report's content.")
@click.option("--note", help="Optional comment.")
@common_options
def signoff_cmd(case_id, stage, approver, note, db_path, actor):
    """Record a named person's approval of a report before it is submitted."""
    console = Console()
    try:
        store = Store(db_path)
        try:
            event = store.add_signoff(case_id, stage, approver, note, actor)
        finally:
            store.close()
    except CaseError as exc:
        _fail(exc)
    console.print(f"Sign-off recorded: {escape(approver)} approves the {clocks.STAGE_LABEL[stage].lower()} for {event.case_id}.")
    console.print(f"[dim]Log entry #{event.seq}, hash {event.hash[:12]}.[/dim]")


@case.command("note")
@click.argument("case_id")
@click.argument("text")
@common_options
def note_cmd(case_id, text, db_path, actor):
    """Add a free-text note to the case log."""
    try:
        store = Store(db_path)
        try:
            event = store.add_note(case_id, text, actor)
        finally:
            store.close()
    except CaseError as exc:
        _fail(exc)
    Console().print(f"Note added to {event.case_id} (log entry #{event.seq}).")


@case.command("close")
@click.argument("case_id")
@click.option("--reason", required=True, help="Why the case is closed (e.g. 'final report accepted', 'not exploited').")
@common_options
def close_cmd(case_id, reason, db_path, actor):
    """Close a case. The log keeps everything."""
    try:
        store = Store(db_path)
        try:
            event = store.close_case(case_id, reason, actor)
        finally:
            store.close()
    except CaseError as exc:
        _fail(exc)
    Console().print(f"Closed {event.case_id} (log entry #{event.seq}).")


@case.command("draft")
@click.argument("case_id")
@click.argument("stage", type=click.Choice(clocks.STAGES))
@click.option("--out", "out_path", type=click.Path(path_type=Path, dir_okay=False), help="Write the draft to this Markdown file.")
@common_options
def draft_cmd(case_id, stage, out_path, db_path, actor):
    """Write a report DRAFT (template with the known facts filled in)."""
    try:
        store = Store(db_path)
        try:
            text = render_draft(store.state(case_id), stage)
        finally:
            store.close()
        if out_path:
            out_path.write_text(text, encoding="utf-8")
    except CaseError as exc:
        _fail(exc)
    except OSError as exc:
        _fail(CaseError(f"could not write {out_path}: {exc}"))
    if out_path:
        Console().print(f"Wrote draft: {escape(str(out_path))}")
    else:
        click.echo(text)


@case.command("export")
@click.argument("case_id")
@click.option("--md", "md_path", type=click.Path(path_type=Path, dir_okay=False), required=True, help="Markdown file to write.")
@common_options
def export_cmd(case_id, md_path, db_path, actor):
    """Write the case evidence record (deadlines vs. what happened, timeline, log integrity)."""
    console = Console()
    try:
        store = Store(db_path)
        try:
            st = store.state(case_id)
            verification = store.verify()
        finally:
            store.close()
        md_path.write_text(render_record(st, verification, datetime.now(timezone.utc), __version__), encoding="utf-8")
    except CaseError as exc:
        _fail(exc)
    except OSError as exc:
        _fail(CaseError(f"could not write {md_path}: {exc}"))
    console.print(f"Wrote case record: {escape(str(md_path))}")
    if not verification.ok:
        console.print(f"[bold red]Warning: the audit log failed its integrity check: {escape(str(verification.problem))}[/bold red]")
    console.print(f"[dim]Log head hash (keep a copy outside this computer): {verification.head}[/dim]")


@click.command("clocks")
@click.option("--case", "case_id", help="Only this case.")
@common_options
def clocks_cmd(case_id, db_path, actor):
    """Show every open deadline, most urgent first."""
    console = Console()
    try:
        store = Store(db_path)
        try:
            states = [store.state(case_id)] if case_id else [s for s in store.cases() if s.is_open]
        finally:
            store.close()
    except CaseError as exc:
        _fail(exc)
    now = datetime.now(timezone.utc)
    rows, waiting = [], []
    for st in states:
        for d in st.deadlines():
            if st.first_submission_at(d.stage):
                continue
            (rows if d.due else waiting).append((st, d))
    if not rows and not waiting:
        console.print("No open deadlines.")
        return
    rows.sort(key=lambda item: item[1].due)
    for st, d in rows:
        status = clocks.classify(d, None, now)
        style = "bold red" if status == "overdue" else "yellow"
        console.print(Text(f"{st.case_id}  {d.label:<13} {_fmt(d.due)}  {clocks.time_left_text(d.due, now)}  {st.title}", style=style))
    for st, d in waiting:
        console.print(Text(f"{st.case_id}  {d.label:<13} not started - {d.waiting_for}  {st.title}", style="dim"))
    console.print(f"[dim]{escape(NOT_SENT)}[/dim]")


@click.group()
def audit() -> None:
    """Check the integrity of the case log."""


@audit.command("verify")
@click.option("--head", "expected_head", help="Head hash you wrote down earlier. Detects removed newest entries.")
@common_options
def verify_cmd(expected_head, db_path, actor):
    """Re-compute the hash chain. Exit code 1 if anything was changed."""
    console = Console()
    try:
        store = Store(db_path)
        try:
            result = store.verify()
        finally:
            store.close()
    except CaseError as exc:
        _fail(exc)
    if not result.ok:
        Console(stderr=True).print(f"[bold red]LOG FAILED THE CHECK:[/bold red] {escape(str(result.problem))}")
        raise click.exceptions.Exit(1)
    console.print(f"[green]Chain intact.[/green] {result.count} entr{'y' if result.count == 1 else 'ies'}.")
    console.print(f"Head hash: {result.head}")
    if expected_head:
        if expected_head.strip().lower() == result.head:
            console.print("[green]Head matches the value you gave.[/green]")
        else:
            Console(stderr=True).print("[bold red]Head does NOT match the value you gave:[/bold red] entries may have been removed or replaced.")
            raise click.exceptions.Exit(1)
    else:
        console.print("[dim]Tip: note this head hash elsewhere and pass it with --head next time.[/dim]")
