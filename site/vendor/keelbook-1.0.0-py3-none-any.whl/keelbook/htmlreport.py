"""HTML reports for people: one self-contained file that opens in any browser.

No internet, no external files: styles and the small script for sorting and
filtering tables are inside the file. Prints cleanly (Ctrl+P -> Save as PDF) for
an auditor. Same content as the Markdown records, laid out for reading:
summary first, what to act on, then the details.
"""

from __future__ import annotations

from datetime import datetime, timezone
from html import escape
from typing import Any, Iterable

from keelbook import models
from keelbook.cratext import QUOTES, SOURCE
from keelbook.euvd import EuvdCatalogue, euvd_matches
from keelbook.kev import KevCatalogue, kev_matches
from keelbook.report import ScanContext, candidate_sources, ordered, status_text
from keelbook.vulns import Finding, LookupResult, clean_summary, display_name, upgrade_summary

DISCLAIMER = ("Working aid, not legal advice. Findings come from public vulnerability databases matched "
              "against the SBOM. A known vulnerability is not the same as an actively exploited one "
              "(CRA Art. 3(42), Art. 14): a person decides what is reportable.")

_CSS = """
:root{--ink:#1d1d1f;--muted:#6e6e73;--line:#d2d2d7;--tile:#f5f5f7;--blue:#0066cc;
--crit:#d70015;--crit-bg:#ffe9eb;--high:#c93400;--high-bg:#fff0e5;--med:#a05a00;--med-bg:#fff8e1;
--low:#0071e3;--low-bg:#e8f2ff;--unk:#6e6e73;--unk-bg:#f0f0f2;--ok:#248a3d;--ok-bg:#e9f8ee}
*{box-sizing:border-box}
body{margin:0;color:var(--ink);background:#fff;-webkit-font-smoothing:antialiased;
font:15px/1.47 -apple-system,BlinkMacSystemFont,"SF Pro Text","Segoe UI","Helvetica Neue",Helvetica,Arial,sans-serif;letter-spacing:-.01em}
main{max-width:1120px;margin:0 auto;padding:0 22px 64px}
a{color:var(--blue);text-decoration:none}a:hover{text-decoration:underline}
.hero{background:#000;color:#f5f5f7;border-radius:28px;text-align:center;padding:60px 28px 52px;margin:22px 0 8px}
.eyebrow{margin:0 0 8px;color:#a1a1a6;font-size:17px;font-weight:600;letter-spacing:0}
h1{margin:0;font-size:44px;line-height:1.08;font-weight:600;letter-spacing:-.025em;overflow-wrap:anywhere}
.lede{margin:14px auto 0;max-width:720px;font-size:21px;line-height:1.38;color:#f5f5f7;font-weight:400}
.lede .hot{color:#ff453a;font-weight:600}
h2{margin:56px 0 14px;font-size:28px;line-height:1.14;font-weight:600;letter-spacing:-.02em}
h2 .n{color:var(--muted);font-weight:500;margin-right:10px}
h3{margin:22px 0 8px;font-size:19px;font-weight:600;letter-spacing:-.01em}
p{margin:8px 0}.small{font-size:13px;color:var(--muted)}
.box{border-radius:14px;padding:14px 18px;margin:12px 0;background:var(--tile)}
.box.alert{background:var(--crit-bg)}.box.alert b:first-child{color:var(--crit)}
.box.warn{background:var(--med-bg)}.box.note{background:var(--ok-bg)}
.tiles{display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:12px;margin:14px 0}
.tile{background:var(--tile);border-radius:18px;padding:18px 18px 16px}
.tile .v{display:block;font-size:40px;line-height:1.05;font-weight:600;letter-spacing:-.03em}
.tile .k{display:block;margin-top:6px;font-size:14px;color:var(--muted);font-weight:500}
.tile.critical .v{color:var(--crit)}.tile.high .v{color:var(--high)}.tile.medium .v{color:var(--med)}
.tile.low .v{color:var(--low)}.tile.unknown .v{color:var(--unk)}.tile.ok .v{color:var(--ok)}
.tile.dark{background:#1d1d1f;color:#f5f5f7}.tile.dark .k{color:#a1a1a6}
table{width:100%;border-collapse:collapse;font-size:13px;margin:6px 0}
th,td{text-align:left;padding:10px 12px;border-bottom:1px solid #e8e8ed;vertical-align:top}td{overflow-wrap:anywhere}
th{font-size:12px;font-weight:600;color:var(--muted);background:#fff;white-space:nowrap;position:sticky;top:0;border-bottom:1px solid var(--line)}
tbody tr:hover td{background:#fafafc}
table.sortable th{cursor:pointer}th[data-dir=asc]:after{content:" \2191"}th[data-dir=desc]:after{content:" \2193"}
td.num,th.num{text-align:right;font-variant-numeric:tabular-nums}
table.kv{background:var(--tile);border-radius:18px;overflow:hidden}
table.kv th,table.kv td{border-bottom:1px solid #e8e8ed;background:transparent;position:static}
table.kv tr:last-child th,table.kv tr:last-child td{border-bottom:0}
table.kv th{width:28%;white-space:normal;font-size:14px;color:var(--muted);font-weight:500;padding:12px 18px}
table.kv td{font-size:14px;padding:12px 18px}table.kv tr:hover td{background:transparent}
.sev{display:inline-block;min-width:68px;padding:2px 10px;border-radius:980px;font-size:12px;font-weight:600;text-align:center;
white-space:nowrap;color:var(--unk);background:var(--unk-bg)}
.sev.critical{color:var(--crit);background:var(--crit-bg)}.sev.high{color:var(--high);background:var(--high-bg)}
.sev.medium{color:var(--med);background:var(--med-bg)}.sev.low,.sev.none{color:var(--low);background:var(--low-bg)}
.score{font-size:12px;color:var(--muted);margin-left:6px;font-variant-numeric:tabular-nums}.sevw{white-space:nowrap}
.vd{background:var(--tile);border-radius:18px;margin:14px 0;padding:6px 6px 4px;page-break-inside:avoid}
.vd h3{margin:0;padding:12px 14px 8px;font-size:17px}.vd table{margin:0}
.vd th,.vd td{background:transparent;position:static;border-bottom:1px solid #e8e8ed;font-size:13px}
.vd tr:last-child th,.vd tr:last-child td{border-bottom:0}.vd th{width:18%;font-weight:500}.vd tr:hover td{background:transparent}
.tag{display:inline-block;font-size:12px;font-weight:600;padding:1px 9px;border-radius:980px}
.tag.kev{color:#fff;background:var(--crit)}.tag.no{color:var(--muted);font-weight:400;padding:0}.tag.fix{color:var(--ok)}
.id{font-family:ui-monospace,"SF Mono",Menlo,Consolas,monospace;font-size:12px;white-space:nowrap;letter-spacing:0}
.tools{display:flex;gap:8px;flex-wrap:wrap;margin:10px 0}
.tools input,.tools select{font:inherit;font-size:14px;padding:8px 14px;border:1px solid var(--line);border-radius:980px;background:#fff;color:var(--ink)}
.tools input{flex:1;min-width:220px}.tools input:focus,.tools select:focus{outline:none;border-color:var(--blue);box-shadow:0 0 0 3px rgba(0,113,227,.2)}
.count{color:var(--muted);align-self:center;font-size:13px}
blockquote{margin:10px 0;padding:12px 18px;background:var(--tile);border-radius:14px;color:var(--ink)}
ul{padding-left:20px}li{margin:4px 0}
details summary{cursor:pointer;margin:6px 0;color:var(--blue)}
footer{margin-top:56px;padding-top:16px;border-top:1px solid var(--line);color:var(--muted);font-size:12px}
table.kv .id{white-space:normal;word-break:break-all}
@media (max-width:640px){main{padding:0 14px 48px}h1{font-size:32px}.lede{font-size:18px}h2{font-size:24px}
.hero{padding:40px 18px 32px;margin-top:14px}table{display:block;overflow-x:auto}table.kv{display:table}th{position:static}
table.kv th{width:38%;padding:10px 12px}table.kv td{padding:10px 12px}}
@media print{*{-webkit-print-color-adjust:exact;print-color-adjust:exact}.tools{display:none}th{position:static}
main{max-width:none;padding:0}.hero{margin:0 0 8px;border-radius:18px;padding:28px;background:var(--tile);color:var(--ink)}
.hero .lede{color:var(--ink)}.hero .lede .hot{color:var(--crit)}.eyebrow{color:var(--muted)}h1{font-size:30px}h2{font-size:22px;margin-top:28px}
h2{page-break-after:avoid}tr{page-break-inside:avoid}details{display:block}details>*{display:block}}
"""

_JS = """
document.querySelectorAll('table.sortable').forEach(function(t){
  t.querySelectorAll('th').forEach(function(th,i){th.addEventListener('click',function(){
    var b=t.tBodies[0],rows=Array.from(b.rows),asc=th.dataset.dir!=='asc';
    t.querySelectorAll('th').forEach(function(h){delete h.dataset.dir});th.dataset.dir=asc?'asc':'desc';
    rows.sort(function(x,y){var a=x.cells[i].dataset.v||x.cells[i].textContent,c=y.cells[i].dataset.v||y.cells[i].textContent;
      var na=parseFloat(a),nc=parseFloat(c);var r=(!isNaN(na)&&!isNaN(nc))?na-nc:a.localeCompare(c,undefined,{numeric:true});
      return asc?r:-r});rows.forEach(function(r){b.appendChild(r)});});});});
document.querySelectorAll('.tools').forEach(function(box){
  var t=document.getElementById(box.dataset.table),q=box.querySelector('input'),s=box.querySelectorAll('select'),n=box.querySelector('.count');
  function run(){var text=(q.value||'').toLowerCase(),shown=0;
    Array.from(t.tBodies[0].rows).forEach(function(r){var ok=r.textContent.toLowerCase().indexOf(text)>=0;
      s.forEach(function(sel){if(sel.value&&r.dataset[sel.dataset.key]!==sel.value)ok=false});
      r.style.display=ok?'':'none';if(ok)shown++});n.textContent=shown+' of '+t.tBodies[0].rows.length+' shown';}
  q.addEventListener('input',run);s.forEach(function(sel){sel.addEventListener('change',run)});run();});
"""


def _e(text: Any) -> str:
    return escape("" if text is None else str(text))


def page(title: str, body: str) -> str:
    return (f'<!doctype html><html lang="en"><head><meta charset="utf-8">'
            f'<meta name="viewport" content="width=device-width,initial-scale=1"><title>{_e(title)}</title>'
            f"<style>{_CSS}</style></head><body><main>{body}</main><script>{_JS}</script></body></html>")


def sev_badge(label: str | None, score: float | None = None) -> str:
    label = label or "unknown"
    shown = "low" if label == "none" else label
    score_text = f'<span class="score">{score:.1f}</span>' if score is not None else ""
    return f'<span class="sevw"><span class="sev {_e(label)}">{_e(shown)}</span>{score_text}</span>'


def hero(eyebrow: str, title: str, lede: str = "") -> str:
    """The page header: a soft panel with a large title (values are HTML-escaped by the caller)."""
    return (f'<header class="hero"><p class="eyebrow">{eyebrow}</p><h1>{title}</h1>'
            + (f'<p class="lede">{lede}</p>' if lede else "") + "</header>")


def tiles(items: list[tuple[str, str, str]]) -> str:
    """Big-number tiles: (css class, number text, label)."""
    return '<div class="tiles">' + "".join(
        f'<div class="tile {cls}"><span class="v">{v}</span><span class="k">{_e(k)}</span></div>'
        for cls, v, k in items) + "</div>"


def info_table(pairs: list[tuple[str, str]]) -> str:
    """Label / value table (values are HTML)."""
    return '<table class="kv">' + "".join(f"<tr><th>{_e(k)}</th><td>{v}</td></tr>" for k, v in pairs) + "</table>"


SEVERITY_ORDER = ("critical", "high", "medium", "low", "unknown")


def severity_summary(counts: dict[str, int]) -> str:
    """The classic scanner summary: one coloured column per severity, then the total."""
    return tiles([(k, f"{counts.get(k, 0):,}", k.capitalize()) for k in SEVERITY_ORDER]
                 + [("dark", f"{sum(counts.values()):,}", "Total")])


def reference_links(ids: Iterable[str]) -> str:
    links = []
    for i in ids:
        u = i.upper()
        if u.startswith("CVE-"):
            links.append(f'<a href="https://nvd.nist.gov/vuln/detail/{_e(u)}">NVD {_e(u)}</a>')
            links.append(f'<a href="https://www.cve.org/CVERecord?id={_e(u)}">CVE.org {_e(u)}</a>')
        elif u.startswith("GHSA-"):
            links.append(f'<a href="https://github.com/advisories/{_e(i)}">GitHub {_e(i)}</a>')
        else:
            links.append(f'<a href="https://osv.dev/vulnerability/{_e(i)}">OSV {_e(i)}</a>')
    return "<br>".join(links)


def _finding_sev(f: Finding) -> tuple[str, float | None]:
    return (f.severity.label, f.severity.score) if f.severity else ("unknown", None)


def table(table_id: str, headers: list[str], rows: Iterable[list[str]], numeric: Iterable[int] = (),
          row_attrs: Iterable[str] | None = None, sortable: bool = True) -> str:
    numeric = set(numeric)
    tip = ' title="Click to sort"' if sortable else ""
    head = "".join(f'<th class="num"{tip}>{_e(h)}</th>' if i in numeric else f"<th{tip}>{_e(h)}</th>"
                   for i, h in enumerate(headers))
    attrs = list(row_attrs) if row_attrs is not None else None
    body = []
    for n, row in enumerate(rows):
        cells = "".join(f'<td class="num">{c}</td>' if i in numeric else f"<td>{c}</td>" for i, c in enumerate(row))
        body.append(f"<tr {attrs[n] if attrs else ''}>{cells}</tr>")
    cls = ' class="sortable"' if sortable else ""
    return f'<table id="{table_id}"{cls}><thead><tr>{head}</tr></thead><tbody>{"".join(body)}</tbody></table>'


def filter_tools(table_id: str, placeholder: str, selects: list[tuple[str, str, list[str]]] = ()) -> str:
    """Search box (and optional drop-downs filtering on data-* attributes of the rows)."""
    parts = [f'<div class="tools" data-table="{table_id}"><input type="search" placeholder="{_e(placeholder)}">']
    for key, label, values in selects:
        options = "".join(f'<option value="{_e(v)}">{_e(v)}</option>' for v in values)
        parts.append(f'<select data-key="{key}"><option value="">{_e(label)}</option>{options}</select>')
    parts.append('<span class="count"></span></div>')
    return "".join(parts)


def _sev_cell(label: str, score: float | None) -> str:
    return sev_badge(label, score)


def _sort_value(score: float | None, label: str) -> str:
    band = {"critical": 9.0, "high": 7.0, "medium": 4.0, "low": 0.1, "none": 0.0}.get(label, -1)
    return f"{score if score is not None else band:.1f}"


# --- scan report -----------------------------------------------------------------


def scan_html(ctx: ScanContext, lookup: LookupResult, catalogue: KevCatalogue | None,
              euvd: EuvdCatalogue | None = None) -> str:
    open_findings = ordered([f for f in lookup.findings if f.vex_status not in models.RESOLVED_STATUSES],
                            catalogue, euvd)
    resolved = [f for f in lookup.findings if f.vex_status in models.RESOLVED_STATUSES]
    lists_used = " and ".join(x for x, used in (("CISA KEV", catalogue), ("ENISA EUVD", euvd is not None)) if used)
    hits = [f for f in ordered(lookup.findings, catalogue, euvd) if candidate_sources(f, catalogue, euvd)]
    skipped_total = sum(lookup.skipped.values())
    counts = {k: 0 for k in ("critical", "high", "medium", "low", "unknown")}
    for f in open_findings:
        label = f.severity.label if f.severity else "unknown"
        counts["low" if label == "none" else label] += 1

    n_comps = len({(f.component.name, f.component.version) for f in open_findings})
    section = _Sections()
    lede = f"{len(open_findings):,} open finding(s) in {n_comps:,} component(s)."
    if lists_used and hits:
        lede += f' <span class="hot">{len(hits):,} listed as exploited.</span>'
    elif not lists_used:
        lede += " Exploited-vulnerability lists not checked."
    if skipped_total:
        lede += f" {skipped_total:,} component(s) not checked."
    b = [hero("Vulnerability scan report", _e(ctx.sbom_name), lede)]
    sources = ", ".join(sorted(lookup.checked_by)) or "none"
    coverage = f"{ctx.total_components:,} in the SBOM, {lookup.checked:,} checked"
    if skipped_total:
        coverage += f", <b>{skipped_total:,} NOT checked</b>"
    info = [("Scanned file (SBOM)", _e(ctx.sbom_name)),
            ("SHA-256 of the file", f"<span class='id'>{_e(ctx.sbom_sha256)}</span>"),
            ("SBOM format", _e(f"{ctx.sbom_format} {ctx.spec_version or ''}".strip())),
            ("Components", coverage),
            ("Vulnerability sources", _e(sources)),
            ("Exploited-vulnerability lists", _e(lists_used) if lists_used
             else "<b>not used</b> (scan with --kev-download and/or --euvd)"),
            ("Report generated", f"{_e(ctx.generated_at)} UTC"),
            ("Tool", f"Keelbook {_e(ctx.tool_version)}")]
    b.append(section("Report information") + info_table(info))
    b.append(section("Summary"))
    b.append(f"<p>{len(open_findings):,} open finding(s) in {n_comps:,} component(s), by severity:</p>")
    b.append(severity_summary(counts))
    if lists_used:
        b.append(f"<p><b>Listed as exploited ({_e(lists_used)}): {len(hits):,}</b></p>")
    else:
        b.append("<p><b>Exploited-vulnerability lists: not checked.</b></p>")
    if skipped_total:
        reasons = "; ".join(f"{n} {_e(r)}" for r, n in sorted(lookup.skipped.items()))
        b.append(f'<div class="box warn"><b>Not checked: {skipped_total} component(s)</b> ({reasons}). '
                 "They are not reported as clean.</div>")
    if lookup.nvd_missed:
        missed = "; ".join(f"{n} {_e(r)}" for r, n in sorted(lookup.nvd_missed.items()))
        b.append(f'<div class="box warn"><b>Checked by the CVE List only, not by NVD:</b> {missed}.</div>')
    if "NVD" in lookup.checked_by and not lookup.cvelist_label:
        b.append('<div class="box warn"><b>Not checked against the official CVE List:</b> CVEs that NVD has not '
                 "analysed yet are missing. Scan with --cve-list.</div>")
    if lookup.checked == 0 and ctx.total_components:
        b.append('<div class="box alert"><b>Nothing could be checked.</b> An empty result does NOT mean the '
                 "product is free of known vulnerabilities.</div>")

    if lists_used:
        b.append(section(f"Act first: listed as exploited ({len(hits)})"))
        if hits:
            rows = []
            for f in hits:
                listed = [f"CISA KEV since {_e(k.date_added or '?')}"
                          + (" &middot; ransomware use known" if (k.ransomware or "").lower() == "known" else "")
                          for k in (kev_matches(f, catalogue) if catalogue else [])]
                listed += [f"EUVD {_e(e.euvd_id)}, exploited since {_e(e.exploited_since or '?')}"
                           for e in (euvd_matches(f, euvd) if euvd is not None else [])]
                label, score = _finding_sev(f)
                rows.append([f'<span class="id">{_e(" ".join(f.cve_ids))}</span>',
                             _e(display_name(f.component, f.also_in)), _sev_cell(label, score),
                             _e(f.fixed_text), "<br>".join(listed)])
            b.append(table("hits", ["Vulnerability", "Component", "Severity", "Fixed in", "Listed"], rows))
            b.append('<div class="box alert">If one of these is really exploited in your product, the CRA Art. 14 '
                     "clocks (24 h / 72 h) may be running. A listing is a candidate only: a person confirms with "
                     "reliable evidence (Art. 3(42)) and decides.</div>")
        else:
            b.append(f'<div class="box note">None of the findings is listed in {_e(lists_used)}.</div>')

    if open_findings:
        summary = upgrade_summary(open_findings)
        b.append(section(f"Results by component ({len(summary)})"))
        by_comp: dict[tuple, list[Finding]] = {}
        for f in open_findings:
            by_comp.setdefault((f.component.name, f.component.version or "-"), []).append(f)
        rows = []
        for r in summary:
            labels = [("low" if _finding_sev(f)[0] == "none" else _finding_sev(f)[0])
                      for f in by_comp.get((r.component, r.version), [])]
            extra = []
            if r.newer_line:
                extra.append(f"+{r.newer_line:,} only in a newer line")
            if r.unknown:
                extra.append(f"{r.unknown:,} without fix data")
            target = _e(r.upgrade_to or "unknown") + (f'<div class="small">{"; ".join(extra)}</div>' if extra else "")
            rows.append([_e(r.display), *(f"{labels.count(k):,}" if labels.count(k) else "" for k in SEVERITY_ORDER),
                         f"<b>{r.findings:,}</b>", target])
        b.append(table("components", ["Component", "Critical", "High", "Medium", "Low", "Unknown", "Total",
                                      "Upgrade to at least"], rows, numeric=range(1, 7)))
        b.append('<p class="small">"Upgrade to at least": the lowest version in the installed release line '
                 '(e.g. 6.12.x for a 6.12 kernel) that fixes all its findings. "Only in a newer line": findings no '
                 'update of that line fixes yet. Severity "unknown" means no score, not "low".</p>')

        b.append(section(f"Vulnerability list ({len(open_findings):,})"))
        comp_names = sorted({display_name(f.component, f.also_in) for f in open_findings})
        b.append(filter_tools("findings", "Search: CVE, component, text...",
                              [("comp", "All components", comp_names),
                               ("sev", "All severities", ["critical", "high", "medium", "low", "unknown"])]))
        b.append(_findings_table("findings", open_findings, catalogue, euvd))
        b.append(section("Vulnerability details"))
        shown = open_findings[:DETAIL_LIMIT]
        if len(open_findings) > len(shown):
            b.append(f"<p>The {len(shown):,} most urgent findings (exploited first, then by severity). All "
                     f"{len(open_findings):,} are in the vulnerability list above.</p>")
        b.extend(_detail_block(f, catalogue, euvd) for f in shown)

    checks = _scan_checks(lookup)
    if checks:
        b.append(section("Check once") + checks)
    if resolved:
        b.append(section(f"Marked fixed or not affected by the SBOM producer ({len(resolved)})")
                 +
                 '<p class="small">The producer\'s own statements (e.g. Yocto, VEX in the SBOM), shown as received; '
                 "not verified by the tool.</p>")
        b.append(_findings_table("resolved", ordered(resolved, catalogue, euvd), catalogue, euvd, producer=True))

    about = [f"SBOM file: {_e(ctx.sbom_name)}", f"SBOM SHA-256: <span class='id'>{_e(ctx.sbom_sha256)}</span>",
             f"SBOM format: {_e(ctx.sbom_format)} {_e(ctx.spec_version or '')}, {ctx.total_components} component(s)"]
    if "OSV" in lookup.checked_by or not lookup.checked_by:
        about.append("Vulnerability source: OSV (api.osv.dev), queried with package names and versions only")
    if "NVD" in lookup.checked_by:
        nvd = "Vulnerability source: NVD (services.nvd.nist.gov), queried with CPE vendor/product/version only"
        if lookup.nvd_oldest_data:
            nvd += f"; oldest answer fetched {_e(lookup.nvd_oldest_data)}"
        about.append(nvd)
    if lookup.cvelist_label:
        about.append(f"Vulnerability source: {_e(lookup.cvelist_label)} (official CVE records, local index)")
    if lookup.offline:
        about.append("Offline mode: no network was used; only data saved earlier")
    about.append(f"CISA KEV: released {_e((catalogue.released or 'unknown')[:10])}"
                 + (f", downloaded {_e(catalogue.downloaded_at)}" if catalogue.downloaded_at else "")
                 if catalogue else "CISA KEV: not used in this scan")
    about.append(f"ENISA EUVD: {euvd.total} entries" if euvd is not None else "ENISA EUVD: not used in this scan")
    if lookup.nvd_platform_only:
        about.append(f"{lookup.nvd_platform_only} CVE(s) left out: NVD lists the product only as a platform")
    if lookup.checked_by.keys() & {"NVD", "CVE List"}:
        about.append("Matching is by version number: a patch backported without a version change is not known "
                     "unless the producer says so (VEX, Yocto cve-check)")
    b.append(section("Scope and method") + "<ul>" + "".join(f"<li>{a}</li>" for a in about) + "</ul>")
    b.append(f"<footer>{_e(DISCLAIMER)}</footer>")
    return page(f"Keelbook report - {ctx.sbom_name}", "".join(b))


DETAIL_LIMIT = 100


class _Sections:
    """Numbered section headings, as in a printed report."""

    def __init__(self) -> None:
        self.n = 0

    def __call__(self, title: str) -> str:
        self.n += 1
        return f'<h2><span class="n">{self.n}</span>{_e(title)}</h2>'


def _detail_block(f: Finding, catalogue: KevCatalogue | None, euvd: EuvdCatalogue | None) -> str:
    label, score = _finding_sev(f)
    ids = [*f.cve_ids, *(i for i in (f.vuln_id, *f.aliases) if i not in f.cve_ids
                         and not any(c in i.upper() for c in f.cve_ids))]
    title = ids[0] if ids else f.vuln_id
    rows = [("Severity", sev_badge(label, score)
             + (f' <span class="small">CVSS {_e(f.severity.version)} ({_e(f.severity.source)})</span>'
                if f.severity and f.severity.version else "")),
            ("Component", _e(display_name(f.component, f.also_in).rsplit(" ", 1)[0] if f.component.version
                             else display_name(f.component, f.also_in))),
            ("Installed version", _e(f.component.version or "unknown")),
            ("Fixed in", _e(f.fixed_text))]
    if catalogue is not None or euvd is not None:
        listed = [f"CISA KEV since {k.date_added or '?'}" for k in (kev_matches(f, catalogue) if catalogue else [])]
        listed += [f"ENISA EUVD {e.euvd_id}" for e in (euvd_matches(f, euvd) if euvd is not None else [])]
        rows.append(("Exploited list", "<b>" + _e("; ".join(listed)) + "</b>" if listed
                     else ("unknown (no CVE ID)" if not f.cve_ids else "not listed")))
    rows.append(("Description", _e(clean_summary(f.summary) or "No description from the source.")))
    if len(ids) > 1:
        rows.append(("Other IDs", _e(", ".join(ids[1:]))))
    source = f.source + (f" (matched as {f.matched_as})" if f.matched_as else "")
    if f.vendor_unconfirmed:
        source += f"; vendor not confirmed, check: {', '.join(f.vendor_unconfirmed)}"
    rows.append(("Source", _e(source)))
    if f.vex_status:
        rows.append(("Producer says", _e(status_text(f))))
    rows.append(("References", reference_links(ids)))
    body = "".join(f"<tr><th>{_e(k)}</th><td>{v}</td></tr>" for k, v in rows)
    return (f'<div class="vd"><h3>{sev_badge(label)} &nbsp;{_e(title)} &middot; '
            f"{_e(display_name(f.component, f.also_in))}</h3><table>{body}</table></div>")


def _findings_table(table_id: str, findings: list[Finding], catalogue: KevCatalogue | None,
                    euvd: EuvdCatalogue | None, producer: bool = False) -> str:
    lists = catalogue is not None or euvd is not None
    headers = ["Vulnerability", "Severity", "Component", "Fixed in"] + (["Exploited list"] if lists else []) \
        + ["Summary"] + (["Producer says"] if producer else []) + ["Source"]
    rows, attrs = [], []
    for f in findings:
        label, score = _finding_sev(f)
        others = [i for i in (f.vuln_id, *f.aliases) if i not in f.cve_ids and not any(c in i.upper() for c in f.cve_ids)]
        ids = "".join(f'<div class="id">{_e(i)}</div>' for i in (*f.cve_ids, *others))
        comp = display_name(f.component, f.also_in)
        row = [ids, f'<span data-v="{_sort_value(score, label)}">{_sev_cell(label, score)}</span>', _e(comp),
               _e(f.fixed_text)]
        if lists:
            listed = candidate_sources(f, catalogue, euvd)
            row.append(" ".join(f'<span class="tag kev">{_e("KEV" if "KEV" in x else "EUVD")}</span>' for x in listed)
                       if listed else f'<span class="tag no">{"unknown" if not f.cve_ids else "no"}</span>')
        row.append(_e(clean_summary(f.summary) or "-"))
        if producer:
            row.append(_e(status_text(f)))
        source = _e(f.source)
        if f.vendor_unconfirmed:
            source += f'<div class="small">check vendor: {_e(", ".join(f.vendor_unconfirmed))}</div>'
        row.append(source)
        rows.append(row)
        attrs.append(f'data-comp="{_e(comp)}" data-sev="{_e("low" if label == "none" else label)}"')
    return table(table_id, headers, rows, row_attrs=attrs)


def _scan_checks(lookup: LookupResult) -> str:
    parts = []
    pairs: dict[tuple[str, str, str], int] = {}
    for f in lookup.findings:
        where = "NVD" if f.source.startswith("NVD") else "CVE record"
        for vendor in f.vendor_unconfirmed:
            key = (display_name(f.component, f.also_in), vendor, where)
            pairs[key] = pairs.get(key, 0) + 1
    if pairs:
        parts.append("<h3>Matched by product name only</h3><p>The SBOM gives no vendor for these components, and "
                     "the vendor named by NVD or the CVE record is not obviously the same project. If it is a "
                     "different product, its findings do not apply.</p>")
        rows = [[_e(c), _e(v), _e(w), f"{n:,}"] for (c, v, w), n in sorted(pairs.items(), key=lambda kv: -kv[1])]
        parts.append(table("vendors", ["Component", "Vendor named", "By", "Findings"], rows, numeric=[3]))
    if lookup.cvelist_unknown:
        total = sum(len(v) for v in lookup.cvelist_unknown.values())
        parts.append(f"<h3>CVE records whose versions could not be compared ({total})</h3><p>These records name "
                     "the component, but give versions as source commits, dates or distribution packages. Not "
                     "counted as findings, and not as clean.</p>")
        for name, ids in sorted(lookup.cvelist_unknown.items(), key=lambda kv: -len(kv[1])):
            parts.append(f"<details><summary>{_e(name)}: {len(ids)}</summary><p class='id' style='white-space:normal'>"
                         f"{_e(', '.join(ids))}</p></details>")
    if lookup.details_failed:
        parts.append(f"<p>{lookup.details_failed} finding(s) are listed by ID only (details could not be fetched).</p>")
    return "".join(parts)


# --- evidence record (register) ------------------------------------------------------


def evidence_html(state, release, rows, cases, verification, tool_version: str, now: datetime | None = None) -> str:
    from keelbook.register import AFFECTED, DECIDED, FIXED, NEEDS_DECISION, NOT_AFFECTED, RECONFIRM, STATUSES
    from keelbook.registerreport import _decision_text, _display, _producer_text, exploited, ordered as rordered

    now = now or datetime.now(timezone.utc)
    rows = rordered(rows)
    counts = {s: sum(1 for r in rows if r.state == s) for s in (NEEDS_DECISION, RECONFIRM, DECIDED)}
    d = state.details
    section = _Sections()
    lede = (f"{len(rows):,} finding(s). {counts[NEEDS_DECISION]:,} need a decision, "
            f"{counts[RECONFIRM]:,} to re-confirm, {counts[DECIDED]:,} decided.")
    b = [hero("Vulnerability register &middot; evidence record", f"{_e(state.name)}, release {_e(release.label)}", lede)]
    b.append(section("Report information") + info_table([
        ("Product", f"{_e(state.name)} ({_e(state.id)})"), ("Release", _e(release.label)),
        ("Record generated", f"{now.strftime('%Y-%m-%d %H:%M')} UTC"), ("Tool", f"Keelbook {_e(tool_version)}")]))
    b.append(section("Summary"))
    b.append(tiles([("dark", f"{len(rows):,}", "Findings"), ("high", f"{counts[NEEDS_DECISION]:,}", "Need a decision"),
                    ("medium", f"{counts[RECONFIRM]:,}", "Re-confirm (version changed)"),
                    ("ok", f"{counts[DECIDED]:,}", "Decided")]))
    sev_counts = {k: 0 for k in SEVERITY_ORDER}
    for r in rows:
        if r.state != DECIDED:
            label = ((r.finding.get("severity") or {}).get("label")) or "unknown"
            sev_counts["low" if label == "none" else label if label in sev_counts else "unknown"] += 1
    if any(sev_counts.values()):
        b.append("<p>Findings without a decision, by severity:</p>" + severity_summary(sev_counts))

    missing = "<i>not recorded</i> (keelbook product edit)"
    support = d.get("support_until")
    ended = support and support < now.date().isoformat()
    product = [("Name", f"{_e(state.name)} ({_e(state.id)})"),
               ("Manufacturer", _e(d["manufacturer"]) if d.get("manufacturer") else missing),
               ("Single point of contact for vulnerabilities (Art. 13(17))", _e(d["contact"]) if d.get("contact") else missing),
               ("Coordinated vulnerability disclosure policy (Annex I Part II (5))",
                _e(d["cvd_policy"]) if d.get("cvd_policy") else missing),
               ("End of support period (Art. 13(8))",
                (_e(support) + (" &middot; <b>the support period has ended</b>" if ended else "")) if support else missing)]
    b.append(section("Product") + info_table(product))

    skipped = sum(release.skipped.values())
    scan = [("SBOM", f"{_e(release.sbom_file)} &middot; SHA-256 <span class='id'>{_e(release.sbom_sha256)}</span>"),
            ("Scanned", f"{_e(release.scanned_at)} UTC by {_e(release.scanned_by)} with Keelbook {_e(release.tool_version)}"),
            ("Vulnerability sources", _e(", ".join(release.sources) or "-")),
            ("Coverage", f"{release.checked} of {release.total} component(s) checked"
             + (f" &middot; <b>NOT checked: {skipped}</b> (" + _e("; ".join(f"{n} {r}" for r, n in
                                                                          sorted(release.skipped.items()))) + ")"
                if skipped else ""))]
    b.append(section("Scan") + info_table(scan))
    if "NVD" in release.sources and not any(s.startswith("CVE List") for s in release.sources):
        b.append('<div class="box warn"><b>Not checked against the CVE List:</b> CVEs that NVD has not analysed '
                 "yet are not included in this scan. Scan with --cve-list.</div>")

    lists = [name for name, prefix in (("CISA KEV", "CISA KEV"), ("ENISA EUVD", "ENISA EUVD"))
             if any(s.startswith(prefix) for s in release.sources)]
    hits = [r for r in rows if exploited(r.finding)]
    if not lists:
        b.append(section("Exploited-vulnerability candidates") + '<div class="box warn"><b>Not checked:</b> no '
                 "exploited-vulnerability list (CISA KEV, ENISA EUVD) was used for this scan, so it is unknown "
                 "whether any finding is listed. Scan with --kev-download and/or --euvd.</div>")
    else:
        b.append(section(f"Exploited-vulnerability candidates ({' and '.join(lists)}): {len(hits)}"))
        if hits:
            trs = [[f'<span class="id">{_e(" ".join(r.finding.get("cve_ids") or []))}</span>', _e(_display(r.finding)),
                    _e(r.finding.get("version")), _rsev(r.finding), _e(r.state), _e(_decision_text(r.decision))]
                   for r in hits]
            b.append(table("ev-hits", ["CVE", "Component", "Version", "Severity", "State", "Decision"], trs))
            b.append('<div class="box alert">A listing is a candidate only. Whether a vulnerability is actively '
                     "exploited (CRA Art. 3(42)) and Art. 14 reporting are decided by a person.</div>")
        else:
            b.append(f'<div class="box note">None of the findings with a CVE ID is listed in {" or ".join(lists)}.</div>')

    by_comp: dict[str, list] = {}
    for r in rows:
        by_comp.setdefault(_display(r.finding), []).append(r)
    trs = []
    for name, comp_rows in sorted(by_comp.items(), key=lambda kv: (-sum(1 for r in kv[1] if r.state != DECIDED),
                                                                   -len(kv[1]), kv[0])):
        st = {s: sum(1 for r in comp_rows if r.state == DECIDED and r.decision.status == s) for s in STATUSES}
        n_open = sum(1 for r in comp_rows if r.state != DECIDED)
        trs.append([_e(name), f"{len(comp_rows):,}", f"{n_open:,}", f"{len(comp_rows) - n_open:,}",
                    *(f"{st[s]:,}" for s in STATUSES)])
    b.append(section(f"By component ({len(by_comp)})"))
    b.append(table("ev-comp", ["Component", "Findings", "Open", "Decided", *STATUSES], trs, numeric=range(1, 8)))

    open_rows = [r for r in rows if r.state != DECIDED]
    b.append(section(f"Open: no decision yet ({len(open_rows):,})"))
    if open_rows:
        b.append(filter_tools("ev-open", "Search: CVE, component, text...",
                              [("comp", "All components", sorted({_display(r.finding) for r in open_rows}))]))
        trs = [[f'<span class="id">{_e(r.finding["key"].split("|", 1)[1])}</span>', _e(_display(r.finding)),
                _e(r.finding.get("version")), _rsev(r.finding),
                _e(r.state) + (f'<div class="small">{_e(r.note)}</div>' if r.note else ""),
                _e(_producer_text(r.finding) or "-")] for r in open_rows]
        attrs = [f'data-comp="{_e(_display(r.finding))}"' for r in open_rows]
        b.append(table("ev-open", ["Vulnerability", "Component", "Version", "Severity", "State", "Producer says"],
                       trs, row_attrs=attrs))
    else:
        b.append('<div class="box note">Every finding of this release has a decision for its component version.</div>')

    decided = [r for r in rows if r.state == DECIDED]
    b.append(section(f"Decisions ({len(decided):,})"))
    if decided:
        groups: dict[tuple, list] = {}
        for r in decided:
            groups.setdefault((_decision_text(r.decision), r.decision.reason, r.decision.by), []).append(r)
        trs = []
        for (text, reason, by), group in sorted(groups.items(), key=lambda kv: -len(kv[1])):
            comps = sorted({_display(r.finding) for r in group})
            times = sorted(r.decision.at for r in group)
            when = times[0] if times[0] == times[-1] else f"{times[0]} to {times[-1]}"
            trs.append([f"{len(group):,}", _e(", ".join(comps[:3]) + (f" and {len(comps) - 3} more" if len(comps) > 3 else "")),
                        _e(text), _e(reason), _e(by), _e(when)])
        b.append("<p class='small'>Grouped: the same decision with the same reason by the same person.</p>")
        b.append(table("ev-groups", ["Findings", "Components", "Decision", "Reason", "By", "At (UTC)"], trs, numeric=[0]))
        b.append(f"<details><summary>Every decision ({len(decided):,})</summary>")
        b.append(filter_tools("ev-dec", "Search: CVE, component, reason..."))
        trs = [[f'<span class="id">{_e(r.finding["key"].split("|", 1)[1])}</span>', _e(_display(r.finding)),
                _e(r.finding.get("version")), _rsev(r.finding), _e(_decision_text(r.decision)), _e(r.decision.reason),
                _e(r.decision.by), _e(r.decision.at)] for r in decided]
        b.append(table("ev-dec", ["Vulnerability", "Component", "Version", "Severity", "Decision", "Reason", "By",
                                  "At (UTC)"], trs))
        b.append("</details>")

    cves = {c for r in rows for c in r.finding.get("cve_ids") or []}
    related = [c for c in cases if set(c.cve_ids) & cves]
    b.append(section(f"Art. 14 cases about these vulnerabilities ({len(related)})"))
    if related:
        b.append("<ul>" + "".join(f"<li>{_e(c.case_id)}: {_e(c.title)} ({_e(c.track)}, "
                                  f"{'open' if c.is_open else 'closed'}; aware at "
                                  f"{c.aware_at.strftime('%Y-%m-%d %H:%M UTC')})</li>" for c in related) + "</ul>")
    else:
        b.append("<p>No case in this log names a CVE of this release.</p>")

    b.append(section("Integrity of the log"))
    if verification.ok:
        b.append(f'<div class="box note">The append-only log was verified: {verification.count} entries, head hash '
                 f'<span class="id">{_e(verification.head)}</span>. Keep this hash somewhere else (e.g. in an '
                 "email): removing the newest entries can only be detected by comparing it.</div>")
    else:
        b.append(f'<div class="box alert"><b>The log FAILED verification: {_e(verification.problem)}. Do not rely '
                 "on this record.</b></div>")

    b.append(section("CRA provisions this record relates to (quoted)"))
    for reference, text in QUOTES:
        b.append(f"<blockquote><b>{_e(reference)}:</b> {_e(text)}</blockquote>")
    b.append(f'<p class="small">Source: {_e(SOURCE)}. Quoted for context; which provisions apply to a product, and '
             "whether this record meets them, is a legal assessment this tool does not make.</p>")
    b.append("<footer>Working aid, not legal advice. Findings come from public vulnerability databases matched against "
             "the SBOM; decisions are statements by the named people, recorded verbatim. Producer statements are "
             "shown as received and were not verified by the tool.</footer>")
    return page(f"Keelbook evidence - {state.name} {release.label}", "".join(b))


def _rsev(f: dict[str, Any]) -> str:
    sev = f.get("severity") or {}
    label, score = sev.get("label") or "unknown", sev.get("score")
    return f'<span data-v="{_sort_value(score, label)}">{sev_badge(label, score)}</span>'
