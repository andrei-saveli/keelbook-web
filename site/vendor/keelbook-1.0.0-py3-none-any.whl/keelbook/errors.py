"""Exceptions raised by the business logic.

The business layer never prints or exits. It raises these, and the CLI layer
decides how to show them. Messages are written for end users, not developers.
"""


class SbomError(Exception):
    """Base class: anything wrong with the SBOM input that the user can fix."""


class SbomReadError(SbomError):
    """The file could not be found, opened, or decoded as text."""


class SbomFormatError(SbomError):
    """The file was read, but its content is not a valid or supported SBOM."""


class VulnLookupError(Exception):
    """The vulnerability service could not be reached or gave an unusable answer.

    Deliberately NOT an SbomError: the SBOM is fine, the lookup failed. The CLI
    uses a different exit code so scripts can tell the two apart.
    """


class KevFileError(Exception):
    """The CISA KEV file could not be read or is not a KEV catalogue.

    Separate from SbomError: the SBOM is fine, the extra data file is not.
    """


class CaseError(Exception):
    """A problem with a case or the case database that the user can fix."""
