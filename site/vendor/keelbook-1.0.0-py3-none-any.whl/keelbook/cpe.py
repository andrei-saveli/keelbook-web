"""CPE (Common Platform Enumeration) names: parsing and normalising.

Embedded build systems (Yocto, Buildroot, Zephyr) usually identify packages by
CPE instead of purl, for example ``cpe:2.3:*:*:busybox:1.36.1:*:*:*:*:*:*:*``.
NVD indexes vulnerabilities by CPE, so this is the key that makes such SBOMs
checkable at all.

CPE 2.3 formatted string: ``cpe:2.3:part:vendor:product:version:update:edition:
language:sw_edition:target_sw:target_hw:other``. A colon inside a field is
escaped as ``\\:``. ``*`` means ANY, ``-`` means NOT APPLICABLE.
"""

from __future__ import annotations

from dataclasses import dataclass

ANY = "*"
NA = "-"


@dataclass(frozen=True)
class Cpe:
    part: str  # a (application), o (operating system), h (hardware) or *
    vendor: str
    product: str
    version: str

    @property
    def has_version(self) -> bool:
        return self.version not in (ANY, NA, "")

    def with_version(self, version: str) -> "Cpe":
        return Cpe(self.part, self.vendor, self.product, escape(version))

    def match_string(self) -> str:
        """The prefix NVD's ``virtualMatchString`` parameter expects."""
        return f"cpe:2.3:{self.part}:{self.vendor}:{self.product}:{self.version}"

    def label(self) -> str:
        """Short human-readable form, e.g. 'openssl:openssl 3.0.8' or '*:busybox 1.36.1'."""
        return f"{unescape(self.vendor)}:{unescape(self.product)} {unescape(self.version)}"


def _split_fields(text: str) -> list[str]:
    """Split on ':' but not on an escaped '\\:'."""
    fields, current, escaped = [], [], False
    for char in text:
        if escaped:
            current.append(char)
            escaped = False
        elif char == "\\":
            current.append(char)
            escaped = True
        elif char == ":":
            fields.append("".join(current))
            current = []
        else:
            current.append(char)
    fields.append("".join(current))
    return fields


def escape(value: str) -> str:
    """Escape a plain value for use inside a CPE 2.3 formatted string.

    Letters, digits, '_', '.' and '-' stay as they are (NVD writes versions
    such as 3.0.8 unescaped); anything else gets a backslash.
    """
    out = []
    for char in value:
        if char.isalnum() or char in "_.-":
            out.append(char)
        else:
            out.append("\\" + char)
    return "".join(out)


def unescape(value: str) -> str:
    out, escaped = [], False
    for char in value:
        if escaped:
            out.append(char)
            escaped = False
        elif char == "\\":
            escaped = True
        else:
            out.append(char)
    return "".join(out)


def parse_cpe(text: object) -> Cpe | None:
    """Parse a CPE 2.3 formatted string or a CPE 2.2 URI. None if unusable.

    A CPE is unusable for lookup when it names no product.
    """
    if not isinstance(text, str):
        return None
    text = text.strip()
    lowered = text.lower()
    if lowered.startswith("cpe:2.3:"):
        fields = _split_fields(text[len("cpe:2.3:"):])
        if len(fields) < 4:
            return None
        part, vendor, product, version = (f.strip().lower() for f in fields[:4])
    elif lowered.startswith("cpe:/"):
        # CPE 2.2 URI: cpe:/a:vendor:product:version (missing parts mean ANY)
        fields = text[len("cpe:/"):].split(":")
        fields += [""] * (4 - len(fields))
        part, vendor, product, version = (f.strip().lower() for f in fields[:4])
        vendor, product, version = (escape(_uri_decode(v)) if v else ANY for v in (vendor, product, version))
        part = part or ANY
    else:
        return None
    if product in ("", ANY, NA):
        return None
    if part not in ("a", "o", "h", ANY):
        return None
    return Cpe(part or ANY, vendor or ANY, product, version or ANY)


def _uri_decode(value: str) -> str:
    from urllib.parse import unquote

    return unquote(value)
