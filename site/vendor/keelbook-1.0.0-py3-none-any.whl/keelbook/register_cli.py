"""'product' commands: the vulnerability register (presentation only).

Typical flow for each release of a product:

    keelbook product add gateway-x --name "Gateway X200"
    keelbook product scan gateway-x --release 2.1.0 --sbom image.spdx.json --vex vex.json
    keelbook product review gateway-x                      # what needs a decision
    keelbook product decide gateway-x CVE-2023-0464 --status not_affected \\
        --justification vulnerable_code_not_in_execute_path --reason "policy API not used"
    keelbook product sheet gateway-x --out review.xlsx    # or decide many in a spreadsheet ...
    keelbook product import gateway-x --sheet review.xlsx # ... and import them
    keelbook product vex gateway-x --author "ACME GmbH" --out gateway-x-2.1.0.openvex.json
    keelbook product evidence gateway-x --md evidence-2.1.0.md
"""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

import click
from rich import box
from rich.console import Console
from rich.markup import escape
from rich.table import Table
from rich.text import Text

from keelbook import __version__
from keelbook.cases import Store
from keelbook.cases_cli import _fail, common_options
from keelbook.errors import CaseError, SbomError
from keelbook.parsers import load_sbom
from keelbook.register import (
    DECIDED, JUSTIFICATIONS, NEEDS_DECISION, RECONFIRM, STATUSES, DecisionInput, Register, RegisterError,
    finding_record,
)
from keelbook.registerreport import (
    evidence_markdown, exploited, openvex, openvex_json, ordered, read_review_sheet, review_sheet, severity_text,
)
from keelbook.report import candidate_sources, sha256_of
from keelbook.scanpipe import LookupOptions, lookup_options, run_pipeline

ROWS_SHOWN = 20
COMPONENT_ROWS = 10


def _record_component(f: dict) -> "Component":
    from keelbook.models import Component
    return Component(name=f["component"], version=f.get("version"), cpe=f.get("cpe"))


def _display(f: dict) -> str:
    from keelbook.vulns import display_name
    return display_name(_record_component(f), tuple(f.get("also_in") or ()))


def _component_matches(f: dict, text: str) -> bool:
    """--component accepts the package name, the short name shown on screen, or the CPE product."""
    wanted = text.strip().lower()
    shown = _display(f).lower()
    cpe = (f.get("cpe") or "").split(":")
    product = cpe[4].replace("_", " ").lower() if len(cpe) > 4 else ""
    return wanted in (f["component"].lower(), shown, shown.rsplit(" ", 1)[0], product,
                      product.replace(" ", "_")) or any(wanted == n.lower() for n in f.get("also_in") or [])


def _fix_target(findings: list[dict]) -> str:
    """Same rule as the scan report: highest fix in the installed line (6.12.115 for a 6.12.49
    kernel), else the version that fixes them in a newer line (glibc 2.41 -> 2.45)."""
    from keelbook.vulns import is_version, parse_version, same_line
    own, newer = [], []
    for f in findings:
        fixes = [v for v in f.get("fixed_in") or [] if is_version(v)]
        mine = [v for v in fixes if same_line(f.get("version"), v)]
        if mine:
            own.append(min(mine, key=parse_version))
        elif fixes:
            newer.append(min(fixes, key=parse_version))
    pool = own or newer
    return max(pool, key=parse_version) if pool else "unknown"


def _open(db_path: Path, create: bool = False) -> tuple[Store, Register]:
    store = Store(db_path, create=create)
    return store, Register(store)


def _write(path: Path, text: str) -> None:
    try:
        path.write_text(text, encoding="utf-8")
    except OSError as exc:
        raise CaseError(f"Could not write {path}: {exc.strerror or exc}") from exc


@click.group()
def product() -> None:
    """Vulnerability register per product and release (CRA Art. 13(7), Annex I Part II)."""



def _detail_options(func):
    """Product details shown in the evidence record."""
    options = [
        click.option("--manufacturer", help="Manufacturer name (and address) as it should appear in the evidence."),
        click.option("--contact", help="Single point of contact for vulnerability reports (CRA Art. 13(17)), "
                     "e.g. security@example.com."),
        click.option("--cvd-policy", "cvd_policy", help="Where your coordinated vulnerability disclosure policy is "
                     "published (CRA Annex I Part II (5)), e.g. a URL."),
        click.option("--support-until", "support_until", metavar="YYYY-MM-DD",
                     help="End of the support period for this product (CRA Art. 13(8))."),
    ]
    for option in reversed(options):
        func = option(func)
    return func

@product.command("add")
@click.argument("product_id")
@click.option("--name", help="Human-readable product name (default: the ID).")
@_detail_options
@common_options
def add_cmd(product_id, name, manufacturer, contact, cvd_policy, support_until, db_path, actor):
    """Add a product to the register."""
    details = {"manufacturer": manufacturer, "contact": contact, "cvd_policy": cvd_policy,
               "support_until": support_until}
    try:
        store, reg = _open(db_path, create=True)
        try:
            reg.add_product(product_id, name, actor, details=details)
            state = reg.product(product_id)
        finally:
            store.close()
    except CaseError as exc:
        _fail(exc)
    Console().print(f"Added product [bold]{escape(state.id)}[/bold] ({escape(state.name)}). "
                    f"Next: keelbook product scan {state.id} --release VERSION --sbom FILE")


@product.command("edit")
@click.argument("product_id")
@_detail_options
@common_options
def edit_cmd(product_id, manufacturer, contact, cvd_policy, support_until, db_path, actor):
    """Record product details for the evidence record (the earlier values stay in the log)."""
    details = {"manufacturer": manufacturer, "contact": contact, "cvd_policy": cvd_policy,
               "support_until": support_until}
    try:
        store, reg = _open(db_path)
        try:
            reg.set_details(product_id, details, actor)
            state = reg.product(product_id)
        finally:
            store.close()
    except CaseError as exc:
        _fail(exc)
    shown = "; ".join(f"{k.replace('_', ' ')}: {v}" for k, v in state.details.items())
    Console().print(f"Recorded details of {escape(state.id)}: {escape(shown)}")


@product.command("list")
@common_options
def list_cmd(db_path, actor):
    """List products with their latest release and how much still needs a decision."""
    console = Console()
    try:
        store, reg = _open(db_path)
        try:
            table = Table(title="Products")
            for col in ("Product", "Name", "Releases", "Latest", "Need decision", "Re-confirm", "Decided"):
                table.add_column(col)
            for state in reg.products():
                latest = state.latest_release()
                rows = reg.review(state, latest) if latest else []
                count = {s: sum(1 for r in rows if r.state == s) for s in (NEEDS_DECISION, RECONFIRM, DECIDED)}
                table.add_row(Text(state.id), Text(state.name), str(len(state.releases)),
                              Text(latest.label if latest else "-"), str(count[NEEDS_DECISION]),
                              str(count[RECONFIRM]), str(count[DECIDED]))
        finally:
            store.close()
    except CaseError as exc:
        _fail(exc)
    console.print(table)


@product.command("scan")
@click.argument("product_id")
@click.option("--release", "release", required=True, help="Release/version of the product this SBOM is for.")
@click.option("--sbom", "sbom_path", required=True, type=click.Path(path_type=Path),
              help="SBOM file, folder or archive (as for 'keelbook scan').")
@click.option("--include-files", is_flag=True, help="Also list CycloneDX entries of type 'file'.")
@click.option("--min-coverage", type=click.IntRange(0, 100), default=None, metavar="PERCENT",
              help="Exit with code 4 if fewer than PERCENT of the components could be checked.")
@lookup_options
@common_options
def scan_cmd(product_id, release, sbom_path, include_files, min_coverage, db_path, actor, **lookup):
    """Scan the SBOM of a release and record its findings in the register."""
    console, err = Console(), Console(stderr=True)
    try:  # check the product exists before any slow lookup
        store, reg = _open(db_path)
        try:
            reg.product(product_id)
        finally:
            store.close()
    except CaseError as exc:
        _fail(exc)
    try:
        with console.status("Parsing SBOM..."):
            sbom = load_sbom(sbom_path, include_files=include_files)
    except SbomError as exc:
        _fail(exc)
    for warning in sbom.warnings:
        err.print(f"[yellow]Warning:[/yellow] {escape(warning)}")
    for note in sbom.notes:
        console.print(f"[dim]Note: {escape(note)}[/dim]")

    opts = LookupOptions(**lookup)
    result = run_pipeline(console, err, sbom, opts)
    lookup = result.lookup
    records = []
    for finding in lookup.findings:
        names = candidate_sources(finding, result.kev, result.euvd)
        kev = None if result.kev is None or not finding.cve_ids else "CISA KEV" in names
        euvd = None if result.euvd is None or not finding.cve_ids else "EUVD" in names
        records.append(finding_record(finding, kev, euvd))
    try:
        store, reg = _open(db_path)
        try:
            reg.record_scan(product_id, release, sbom_file=sbom_path.name, sbom_sha256=sha256_of(sbom_path),
                            findings=records, total=len(sbom.components), checked=lookup.checked,
                            skipped=lookup.skipped, sources=result.sources(), tool_version=__version__, actor=actor)
            state = reg.product(product_id)
            rel = reg.release(state, release)
            rows = reg.review(state, rel)
        finally:
            store.close()
    except CaseError as exc:
        _fail(exc)

    count = {s: sum(1 for r in rows if r.state == s) for s in (NEEDS_DECISION, RECONFIRM, DECIDED)}
    skipped = sum(lookup.skipped.values())
    console.print(f"[bold]Recorded release {escape(rel.label)} of {escape(state.id)}[/bold]: "
                  f"{len(rows)} finding(s) from {escape(rel.sbom_file)} (SHA-256 {rel.sbom_sha256[:12]}...).")
    console.print(f"Checked {lookup.checked} of {len(sbom.components)} component(s)"
                  + (f"; [yellow]NOT checked: {skipped} ("
                     + escape("; ".join(f"{n} {r}" for r, n in sorted(lookup.skipped.items()))) + ")[/yellow]"
                     if skipped else "") + ".")
    console.print(f"Need a decision: [bold]{count[NEEDS_DECISION]}[/bold] | re-confirm (version changed): "
                  f"[bold]{count[RECONFIRM]}[/bold] | already decided (carried over): {count[DECIDED]}")
    hits = [r for r in rows if exploited(r.finding)]
    if hits:
        console.print(f"[bold red]{len(hits)} finding(s) are on an exploited-vulnerability list (KEV/EUVD).[/bold red] "
                      "Review these first; if one is really exploited in your product, the Art. 14 clocks may be running.")
    suggestions = reg.producer_suggestions(state, rel)
    if suggestions:
        console.print(f"The SBOM producer marks {len(suggestions)} open finding(s) as fixed/not affected. To adopt "
                      f"those statements as your decisions: keelbook product accept-producer {state.id} "
                      f"--release {rel.label} --reason \"...\"")
    from keelbook.cli import _print_checks  # shared presentation helper
    _print_checks(console, lookup, show_all=False)
    console.print(f"Next: keelbook product review {state.id}   or   keelbook product sheet {state.id} --out review.xlsx")
    console.print("[dim]Working aid, not legal advice. Every decision is made and recorded by a person.[/dim]")

    total = len(sbom.components)
    percent = 100 * lookup.checked / total if total else 100
    if (lookup.checked == 0 and total) or (min_coverage is not None and percent < min_coverage):
        err.print(f"[bold red]Only {percent:.0f}% of the components could be checked.[/bold red] Findings for "
                  "unchecked components are unknown, not absent.")
        raise click.exceptions.Exit(4)


@product.command("review")
@click.argument("product_id")
@click.option("--release", help="Release (default: the latest scanned).")
@click.option("--all", "show_all", is_flag=True, help="Also show findings that are already decided.")
@common_options
def review_cmd(product_id, release, show_all, db_path, actor):
    """Show what needs a decision in a release, most urgent first."""
    console = Console()
    try:
        store, reg = _open(db_path)
        try:
            state = reg.product(product_id)
            rel = reg.release(state, release)
            rows = ordered(reg.review(state, rel))
        finally:
            store.close()
    except CaseError as exc:
        _fail(exc)
    shown = [r for r in rows if show_all or r.state != DECIDED]
    count = {s: sum(1 for r in rows if r.state == s) for s in (NEEDS_DECISION, RECONFIRM, DECIDED)}
    console.print(f"[bold]{escape(state.name)} ({state.id}), release {escape(rel.label)}[/bold]")
    console.print(f"Need a decision: [bold]{count[NEEDS_DECISION]:,}[/bold]  ·  re-confirm (version changed): "
                  f"[bold]{count[RECONFIRM]:,}[/bold]  ·  decided: {count[DECIDED]:,}")
    if not shown:
        console.print("[green]Every finding of this release has a decision for its component version.[/green]")
        return

    by_component: dict[str, list] = {}
    for r in shown:
        by_component.setdefault(_display(r.finding), []).append(r)
    comp_table = Table(box=box.SIMPLE_HEAD, pad_edge=False, title="By component", title_justify="left")
    comp_table.add_column("Component", min_width=12)
    for col in ("Open", "Crit/high", "Exploited"):
        comp_table.add_column(col, justify="right", no_wrap=True)
    comp_table.add_column("Upgrade to", no_wrap=True)
    items = sorted(by_component.items(), key=lambda kv: (-sum(1 for r in kv[1] if exploited(r.finding)),
                                                        -len(kv[1]), kv[0]))
    for name, comp_rows in items[:None if show_all else COMPONENT_ROWS]:
        sev = sum(1 for r in comp_rows if ((r.finding.get("severity") or {}).get("label")) in ("critical", "high"))
        hot = sum(1 for r in comp_rows if exploited(r.finding))
        comp_table.add_row(name, f"{len(comp_rows):,}", f"{sev:,}", Text(str(hot), style="bold red" if hot else "dim"),
                           _fix_target([r.finding for r in comp_rows]))
    console.print()
    console.print(comp_table)
    if not show_all and len(items) > COMPONENT_ROWS:
        console.print(f"[dim]{COMPONENT_ROWS} of {len(items)} components shown (--all for all).[/dim]")

    listing = shown[:None if show_all else ROWS_SHOWN]
    infos = []
    for r in listing:
        f = r.finding
        if r.decision:
            infos.append(r.decision.status + (f" - {r.note}" if r.note else ""))
        elif f.get("producer_status"):
            infos.append(f"producer: {f['producer_status']}")
        else:
            infos.append("")
    show_state = len({r.state for r in listing}) > 1
    show_info = any(infos)
    names = {_display(r.finding) for r in listing}
    only = names.pop() if len(names) == 1 and len(listing) > 1 else None
    table = Table(box=box.SIMPLE_HEAD, pad_edge=False, title_justify="left",
                  title="Most urgent" + (f", all in {only}" if only else ""))
    table.add_column("Vulnerability", no_wrap=True)
    if not only:
        table.add_column("Component", min_width=12)
    table.add_column("Severity", no_wrap=True)
    table.add_column("Listed?", no_wrap=True)  # on an exploited-vulnerability list (KEV / EUVD)
    table.add_column("Fixed in", no_wrap=True)
    if show_state:
        table.add_column("State", min_width=8)
    if show_info:
        table.add_column("Decision / producer", min_width=10)
    for r, info in zip(listing, infos):
        f = r.finding
        listed = ", ".join(x for x, v in (("KEV", f.get("kev")), ("EUVD", f.get("euvd"))) if v is True)
        if not listed:
            known = [v for v in (f.get("kev"), f.get("euvd")) if v is not None]
            listed_text = Text("no" if known else "unknown", style="dim")  # unknown: not checked or no CVE ID
        else:
            listed_text = Text(listed, style="bold red")
        sev = f.get("severity") or {}
        severity = (f"{sev['score']:.1f} {sev['label']}" if sev.get("score") is not None
                    else sev.get("label") or "unknown")
        fixes = f.get("fixed_in") or []
        row = [Text(f["key"].split("|", 1)[1])] + ([] if only else [Text(_display(f))]) \
            + [Text(severity), listed_text, Text(min(fixes, key=len) if fixes else "unknown")]
        if show_state:
            row.append(Text(r.state))
        if show_info:
            row.append(Text(info or "-"))
        table.add_row(*row)
    console.print()
    console.print(table)
    if not show_all and len(shown) > ROWS_SHOWN:
        console.print(f"[dim]{ROWS_SHOWN} of {len(shown):,} shown. All of them: --all, or a spreadsheet: "
                      f"keelbook product sheet {state.id} --out review.xlsx[/dim]")
    first_name, first_rows = items[0]
    first = first_name.rsplit(" ", 1)[0]
    target = _fix_target([r.finding for r in first_rows])
    console.print()
    console.print("[bold]Decide one:[/bold]   keelbook product decide "
                  f"{state.id} CVE-... --status not_affected --justification ... --reason \"...\"")
    if target != "unknown":
        console.print("[bold]Decide many:[/bold]  keelbook product decide "
                      f"{state.id} --all-open --component \"{escape(first)}\" --fixed-by {escape(target)} "
                      f"--status affected --action \"Upgrade to {escape(target)}\" --reason \"...\"")
    else:
        console.print("[bold]Decide many:[/bold]  keelbook product decide "
                      f"{state.id} --all-open --component \"{escape(first)}\" --status ... --reason \"...\"")
    console.print("[dim]Deciding many shows a preview first; add --yes to record.[/dim]")


def _select_open(rows, component: str | None, fixed_by: str | None) -> list:
    from keelbook.vulns import is_version, parse_version, same_line
    out = []
    target = parse_version(fixed_by) if fixed_by else None
    if fixed_by and target is None:
        raise RegisterError(f"--fixed-by needs a version number like 6.12.115, not {fixed_by!r}.")
    for r in rows:
        if r.state not in (NEEDS_DECISION, RECONFIRM):
            continue
        f = r.finding
        if component and not _component_matches(f, component):
            continue
        if target is not None:
            fixes = [v for v in f.get("fixed_in") or [] if is_version(v) and same_line(fixed_by, v)]
            if not any(parse_version(v) <= target for v in fixes):
                continue
        out.append(r)
    return out


def _resolve(rows, finding: str, component: str | None) -> str:
    """A finding given as a key ('openssl|CVE-...') or an ID ('CVE-...'), plus --component."""
    text = finding.strip()
    keys = {r.finding["key"] for r in rows}
    if text.lower() in {k.lower() for k in keys}:
        return next(k for k in keys if k.lower() == text.lower())
    wanted = text.upper()
    matches = {r.finding["key"]: r.finding for r in rows
               if wanted in [c.upper() for c in r.finding.get("cve_ids") or []]
               or wanted == r.finding["vuln_id"].upper()
               or wanted in [a.upper() for a in r.finding.get("aliases") or []]}
    if component:
        matches = {k: f for k, f in matches.items() if _component_matches(f, component)}
    if not matches:
        raise RegisterError(f"No finding '{finding}'" + (f" for component {component}" if component else "")
                            + " in this release.")
    if len(matches) > 1:
        names = ", ".join(sorted({f["component"] for f in matches.values()}))
        raise RegisterError(f"'{finding}' is reported for several components ({names}). Add --component.")
    return next(iter(matches))


@product.command("decide")
@click.argument("product_id")
@click.argument("findings", nargs=-1)
@click.option("--all-open", "all_open", is_flag=True,
              help="Select every finding that needs a decision or re-confirmation (narrow it with --component "
              "and --fixed-by). Shows a preview; records only with --yes.")
@click.option("--fixed-by", "fixed_by", metavar="VERSION",
              help="With --all-open: only findings that VERSION fixes (a fix in the same release line, at or below it).")
@click.option("--yes", is_flag=True, help="With --all-open: record the decisions (without it, only a preview).")
@click.option("--status", required=True, type=click.Choice(STATUSES))
@click.option("--reason", required=True, help="Why (recorded verbatim, shown in evidence and VEX).")
@click.option("--justification", type=click.Choice(JUSTIFICATIONS), help="For not_affected (OpenVEX vocabulary).")
@click.option("--impact", help="For not_affected: explanation instead of / in addition to a justification.")
@click.option("--action", help="For affected: what is being done (fix planned, workaround, ...).")
@click.option("--fixed-in", "fixed_in", help="For fixed: release or version that contains the fix.")
@click.option("--component", help="Component name, if the vulnerability is reported for several components.")
@click.option("--release", help="Release (default: the latest scanned).")
@common_options
def decide_cmd(product_id, findings, all_open, fixed_by, yes, status, reason, justification, impact, action,
               fixed_in, component, release, db_path, actor):
    """Record a decision for one or more findings (CVE IDs or keys) of a release.

    Many at once: --all-open (with --component / --fixed-by) shows what would be decided;
    --yes records it. Every finding gets its own logged decision with your reason.
    """
    if bool(findings) == bool(all_open):
        raise click.UsageError("Give finding IDs, or --all-open (not both).")
    if fixed_by and not all_open:
        raise click.UsageError("--fixed-by works with --all-open.")
    console = Console()
    try:
        store, reg = _open(db_path)
        try:
            state = reg.product(product_id)
            rel = reg.release(state, release)
            rows = reg.review(state, rel)
            if all_open:
                selected = _select_open(rows, component, fixed_by)
                if not selected:
                    raise RegisterError("No open finding matches" + (f" component '{component}'" if component else "")
                                        + (f" fixed by {fixed_by}" if fixed_by else "") + ".")
                keys = [r.finding["key"] for r in selected]
            else:
                keys = list(dict.fromkeys(_resolve(rows, f, component) for f in findings))
            items = [DecisionInput(k, status, reason, justification, impact, action, fixed_in) for k in keys]
            if all_open and not yes:
                from keelbook.register import validate_decision
                problems = validate_decision(items[0])  # same input for all: report it now, not after the preview
                if problems:
                    raise RegisterError("Nothing was recorded. Fix these problems:\n  " + "\n  ".join(problems))
                sample = ", ".join(k.split("|", 1)[1] for k in keys[:8]) + (" ..." if len(keys) > 8 else "")
                console.print(f"[yellow]Nothing recorded yet.[/yellow] {len(keys):,} finding(s) would be decided "
                              f"as [bold]{status}[/bold]: {escape(sample)}")
                console.print("Check the selection (keelbook product review), then run the same command with --yes.")
                return
            events = reg.decide(product_id, rel.label, items, actor)
        finally:
            store.close()
    except CaseError as exc:
        _fail(exc)
    if len(keys) > 10:
        console.print(f"Recorded {len(keys):,} decisions -> {status} (release {rel.label}, by {escape(actor)}).")
        console.print(f"[dim]{len(events)} log entries; last hash {events[-1].hash[:12]}.[/dim]")
        return
    for key in keys:
        console.print(Text(f"Recorded: {key} -> {status} (release {rel.label}, by {actor})"))
    console.print(f"[dim]{len(events)} log entr{'y' if len(events) == 1 else 'ies'}; last hash "
                  f"{events[-1].hash[:12]}.[/dim]")


@product.command("sheet")
@click.argument("product_id")
@click.option("--release", help="Release (default: the latest scanned).")
@click.option("--out", "out_path", required=True, type=click.Path(path_type=Path, dir_okay=False),
              help="File to write: review.xlsx (Excel, with drop-down lists) or review.csv.")
@common_options
def sheet_cmd(product_id, release, out_path, db_path, actor):
    """Write a review spreadsheet: fill in the new_* columns, then 'product import'."""
    try:
        store, reg = _open(db_path)
        try:
            state = reg.product(product_id)
            rel = reg.release(state, release)
            rows = reg.review(state, rel)
        finally:
            store.close()
        if out_path.suffix.lower() == ".xlsx":
            from keelbook.xlsxreport import review_workbook
            try:
                review_workbook(out_path, state, rel, rows)
            except OSError as exc:
                raise RegisterError(f"Cannot write {out_path}: {exc.strerror or exc}") from exc
        else:
            # The UTF-8 marker makes Excel show non-ASCII text (e.g. Romanian diacritics) correctly.
            _write(out_path, "\ufeff" + review_sheet(state, rel, rows))
    except CaseError as exc:
        _fail(exc)
    if out_path.suffix.lower() == ".xlsx":
        Console().print(f"Wrote {len(rows)} finding(s) to {escape(str(out_path))}. Open it, fill in the yellow "
                        f"columns for the findings you have decided, save it, then run:\n"
                        f"  keelbook product import {state.id} --sheet {escape(out_path.name)}")
        return
    Console().print(
        f"Wrote {len(rows)} finding(s) to {escape(str(out_path))}. Fill in new_status "
        f"({', '.join(STATUSES)}), new_reason and, depending on the status, new_justification "
        f"({', '.join(JUSTIFICATIONS)}) or new_impact, new_action, new_fixed_in. Rows without new_status "
        f"are ignored. Then: keelbook product import {state.id} --sheet {out_path.name}"
    )


@product.command("import")
@click.argument("product_id")
@click.option("--sheet", "sheet_path", required=True, type=click.Path(path_type=Path, dir_okay=False))
@click.option("--release", help="Release (default: the release named in the sheet must be the latest).")
@common_options
def import_cmd(product_id, sheet_path, release, db_path, actor):
    """Import decisions from a filled-in review sheet (.xlsx or .csv): all of them, or none if any row is invalid."""
    excel = sheet_path.suffix.lower() == ".xlsx"
    try:
        text = None
        if excel:
            if not sheet_path.is_file():
                raise RegisterError(f"Cannot read {sheet_path}: file not found")
        else:
            try:
                text = sheet_path.read_text(encoding="utf-8-sig")
            except UnicodeDecodeError as exc:
                raise RegisterError(
                    f"{sheet_path} is not UTF-8 text. Save it as .xlsx, or in Excel use File > Save As > "
                    "'CSV UTF-8 (Comma delimited)'; in LibreOffice choose character set 'Unicode (UTF-8)'."
                ) from exc
            except OSError as exc:
                raise RegisterError(f"Cannot read {sheet_path}: {exc.strerror or exc}") from exc
        store, reg = _open(db_path)
        try:
            state = reg.product(product_id)
            rel = reg.release(state, release)
            if excel:
                from keelbook.xlsxreport import read_review_workbook
                items = read_review_workbook(sheet_path, state, rel)
            else:
                items = read_review_sheet(text, state, rel)
            events = reg.decide(product_id, rel.label, items, actor)
        finally:
            store.close()
    except CaseError as exc:
        _fail(exc)
    Console().print(f"Imported {len(items)} decision(s) for {state.id} {rel.label} "
                    f"({len(events)} log entr{'y' if len(events) == 1 else 'ies'}), recorded by {escape(actor)}.")


@product.command("accept-producer")
@click.argument("product_id")
@click.option("--release", help="Release (default: the latest scanned).")
@click.option("--reason", required=True, help="Why you accept the producer's statements (recorded with each decision).")
@click.option("--yes", is_flag=True, help="Record them. Without --yes, only show what would be recorded.")
@common_options
def accept_producer_cmd(product_id, release, reason, yes, db_path, actor):
    """Adopt the SBOM producer's fixed / not-affected statements as your decisions (explicitly)."""
    console = Console()
    try:
        store, reg = _open(db_path)
        try:
            state = reg.product(product_id)
            rel = reg.release(state, release)
            suggestions = reg.producer_suggestions(state, rel)
            items = [DecisionInput(s.key, s.status, reason, s.justification, s.impact, s.action, s.fixed_in)
                     for s in suggestions]
            if items and yes:
                reg.decide(product_id, rel.label, items, actor)
        finally:
            store.close()
    except CaseError as exc:
        _fail(exc)
    if not items:
        console.print("No open finding has a fixed / not-affected statement from the producer.")
        return
    for item in items[:ROWS_SHOWN]:
        console.print(Text(f"  {item.key} -> {item.status} ({item.fixed_in or item.impact})"))
    if len(items) > ROWS_SHOWN:
        console.print(f"  ... and {len(items) - ROWS_SHOWN} more")
    if yes:
        console.print(f"[bold]Recorded {len(items)} decision(s) by {escape(actor)}[/bold], each citing the "
                      "producer's statement and your reason. You remain responsible for them.")
    else:
        console.print(f"[yellow]Nothing recorded yet: {len(items)} decision(s) would be recorded. "
                      "Check the list, then run again with --yes.[/yellow]")


@product.command("vex")
@click.argument("product_id")
@click.option("--release", help="Release (default: the latest scanned).")
@click.option("--author", required=True, help="Who issues the VEX (organisation or person).")
@click.option("--out", "out_path", required=True, type=click.Path(path_type=Path, dir_okay=False))
@click.option("--product-iri", help="Identifier of the product in the VEX (default: urn:keelbook:product:ID:RELEASE).")
@click.option("--include-open", is_flag=True,
              help="Also export findings without a decision, as under_investigation.")
@common_options
def vex_cmd(product_id, release, author, out_path, product_iri, include_open, db_path, actor):
    """Export the decisions of a release as an OpenVEX document (for customers / their tools)."""
    try:
        store, reg = _open(db_path)
        try:
            state = reg.product(product_id)
            rel = reg.release(state, release)
            document, counts = openvex(state, rel, reg.review(state, rel), author, product_iri, include_open)
        finally:
            store.close()
        _write(out_path, openvex_json(document))
    except CaseError as exc:
        _fail(exc)
    console = Console()
    console.print(f"Wrote {escape(str(out_path))}: {counts['exported']} decision(s)"
                  + (f", {counts['open_as_under_investigation']} open finding(s) as under_investigation"
                     if include_open else "") + ".")
    if counts["open_left_out"]:
        console.print(f"[yellow]{counts['open_left_out']} finding(s) without a decision for their component "
                      "version are NOT in the file (use --include-open to list them as under_investigation).[/yellow]")


@product.command("evidence")
@click.argument("product_id")
@click.option("--release", help="Release (default: the latest scanned).")
@click.option("--html", "html_path", type=click.Path(path_type=Path, dir_okay=False),
              help="Write the record as a web page (opens in any browser; print it to PDF for an auditor).")
@click.option("--md", "md_path", type=click.Path(path_type=Path, dir_okay=False),
              help="Write the record as Markdown (for GitHub/GitLab or a document system).")
@common_options
def evidence_cmd(product_id, release, html_path, md_path, db_path, actor):
    """Write the evidence record of a release: coverage, decisions, open items, cases, log integrity."""
    if not html_path and not md_path:
        raise click.UsageError("Give --html FILE (a web page) and/or --md FILE (Markdown).")
    from keelbook.htmlreport import evidence_html
    try:
        store, reg = _open(db_path)
        try:
            state = reg.product(product_id)
            rel = reg.release(state, release)
            args = (state, rel, reg.review(state, rel), store.cases(), store.verify(), __version__,
                    datetime.now(timezone.utc))
            text = evidence_markdown(*args) if md_path else None
            page = evidence_html(*args) if html_path else None
        finally:
            store.close()
        if md_path:
            _write(md_path, text)
        if html_path:
            _write(html_path, page)
    except CaseError as exc:
        _fail(exc)
    for path in (html_path, md_path):
        if path:
            Console().print(f"Wrote evidence record {escape(str(path))}.")

