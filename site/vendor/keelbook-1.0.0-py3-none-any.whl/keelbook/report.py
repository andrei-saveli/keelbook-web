"""Evidence-pack output (CSV and Markdown) for a vulnerability scan.

Pure functions: no printing, no network. The same data as the terminal table,
plus what an auditor needs to reproduce it: tool version, time, SBOM file name
and SHA-256, KEV catalogue date and the coverage (what was NOT checked).
"""

from __future__ import annotations

import csv
import hashlib
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from keelbook import models
from keelbook.euvd import EuvdCatalogue, euvd_matches
from keelbook.kev import KevCatalogue, kev_matches
from keelbook.vulns import Finding, LookupResult, clean_summary, display_name, upgrade_summary

DISCLAIMER = (
    "A known vulnerability is not the same as an actively exploited one (CRA Art. 3(42), "
    "Art. 14). KEV hits are candidates only. A person must confirm and decide what is "
    "reportable. This file is a working aid, not legal advice."
)

# New columns are only ever appended, so existing spreadsheets keep working.
CSV_COLUMNS = (
    "component", "version", "purl", "vuln_id", "other_ids", "cve_ids",
    "kev_candidate", "kev_date_added", "kev_ransomware", "kev_fix_due", "fixed_in", "summary",
    "source", "cpe", "matched_as", "also_in", "producer_status", "producer_detail", "producer_statement_source",
    "cvss_score", "severity", "cvss_version", "fix_note", "euvd_exploited", "euvd_id", "euvd_exploited_since",
    "vendor_unconfirmed",
)


def candidate_sources(finding: Finding, kev: KevCatalogue | None, euvd: EuvdCatalogue | None) -> list[str]:
    """Which exploited-vulnerability lists name this finding (candidates, not decisions)."""
    sources = []
    if kev is not None and kev_matches(finding, kev):
        sources.append("CISA KEV")
    if euvd is not None and euvd_matches(finding, euvd):
        sources.append("EUVD")
    return sources


def ordered(findings: list[Finding], kev: KevCatalogue | None = None,
            euvd: EuvdCatalogue | None = None) -> list[Finding]:
    """Most urgent first: exploited candidates, then by severity; unknown severity last."""
    def key(f: Finding):
        sev = f.severity.sort_key() if f.severity else (-1.0, 0)
        return (not candidate_sources(f, kev, euvd), -sev[0], -sev[1], f.component.name.lower(), f.vuln_id)
    return sorted(findings, key=key)


def severity_text(finding: Finding) -> str:
    return finding.severity.text() if finding.severity else "unknown"


def _euvd_state(finding: Finding, euvd: EuvdCatalogue | None) -> tuple[str, list]:
    if euvd is None:
        return "not checked (no --euvd)", []
    if not finding.cve_ids:
        return "unknown (no CVE ID)", []
    entries = euvd_matches(finding, euvd)
    return ("yes" if entries else "no"), entries

_STATUS_WORDS = {
    models.FIXED: "fixed",
    models.NOT_AFFECTED: "not affected",
    models.AFFECTED: "affected",
    models.UNDER_INVESTIGATION: "under investigation",
}


def status_text(finding: Finding) -> str:
    """What the SBOM producer says, e.g. 'fixed (Yocto cve-check: backported-patch)'."""
    if not finding.vex_status:
        return "no statement"
    text = _STATUS_WORDS.get(finding.vex_status, finding.vex_status)
    extra = ": ".join(x for x in (finding.vex_source, finding.vex_detail) if x)
    return f"{text} ({extra})" if extra else text


@dataclass(frozen=True)
class ScanContext:
    sbom_name: str
    sbom_sha256: str
    sbom_format: str
    spec_version: str | None
    total_components: int
    tool_version: str
    generated_at: str  # ISO 8601, UTC


def sha256_of(path: Path) -> str:
    """SHA-256 of a file. For a folder of SBOM files: SHA-256 over the sorted
    list of "relative path, file SHA-256" lines, so any change is detected."""
    if path.is_dir():
        from keelbook.parsers import sbom_files

        manifest = "".join(
            f"{p.relative_to(path).as_posix()}\t{sha256_of(p)}\n" for p in sbom_files(path)
        )
        return hashlib.sha256(manifest.encode()).hexdigest()
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def make_context(sbom_path: Path, fmt: str, spec_version: str | None, total: int, tool_version: str) -> ScanContext:
    name = sbom_path.name
    if sbom_path.is_dir():
        from keelbook.parsers import sbom_files

        name += f"/ (folder, {len(sbom_files(sbom_path))} .json file(s); SHA-256 below is over all of them)"
    return ScanContext(
        sbom_name=name,
        sbom_sha256=sha256_of(sbom_path),
        sbom_format=fmt,
        spec_version=spec_version,
        total_components=total,
        tool_version=tool_version,
        generated_at=datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
    )


def _kev_state(finding: Finding, catalogue: KevCatalogue | None) -> tuple[str, list]:
    if catalogue is None:
        return "not checked (no KEV file)", []
    if not finding.cve_ids:
        return "unknown (no CVE ID)", []
    entries = kev_matches(finding, catalogue)
    return ("yes" if entries else "no"), entries


def _csv_safe(text: str) -> str:
    """Stop spreadsheets from running a cell that starts like a formula."""
    return "\'" + text if text[:1] in ("=", "+", "-", "@", "\t", "\r") else text


def write_csv(path: Path, lookup: LookupResult, catalogue: KevCatalogue | None,
              euvd: EuvdCatalogue | None = None) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(CSV_COLUMNS)
        for f in ordered(lookup.findings, catalogue, euvd):
            state, entries = _kev_state(f, catalogue)
            euvd_state, euvd_entries = _euvd_state(f, euvd)
            first = entries[0] if entries else None
            writer.writerow([
                _csv_safe(f.component.name),
                f.component.version or "",
                f.component.purl or "",
                f.vuln_id,
                " ".join(a for a in f.aliases if a not in f.cve_ids),
                " ".join(f.cve_ids),
                state,
                first.date_added if first and first.date_added else "",
                first.ransomware if first and first.ransomware else "",
                first.due_date if first and first.due_date else "",
                " ".join(f.fixed_in),
                _csv_safe(f.summary or ""),
                f.source,
                f.component.cpe or "",
                f.matched_as or "",
                _csv_safe(" ".join(f.also_in)),
                _STATUS_WORDS.get(f.vex_status or "", ""),
                _csv_safe(f.vex_detail or ""),
                f.vex_source or "",
                f"{f.severity.score:.1f}" if f.severity and f.severity.score is not None else "",
                f.severity.label if f.severity else "unknown",
                f.severity.version or "" if f.severity else "",
                f.fix_note or "",
                euvd_state,
                " ".join(e.euvd_id for e in euvd_entries),
                " ".join(e.exploited_since or "" for e in euvd_entries).strip(),
                " ".join(f.vendor_unconfirmed),
            ])


def _md(text: str) -> str:
    return text.replace("|", "\\|").replace("\n", " ").replace("\r", " ")


FINDINGS_SHOWN_PER_COMPONENT = 25  # more are folded away (<details>), never left out


def _severity_counts(findings: list[Finding]) -> dict[str, int]:
    counts = {k: 0 for k in ("critical", "high", "medium", "low", "unknown")}
    for f in findings:
        label = f.severity.label if f.severity else "unknown"
        counts["low" if label == "none" else label] += 1
    return counts


def _short_sev(f: Finding) -> str:
    s = f.severity
    if s is None:
        return "unknown"
    return f"{s.score:.1f} {s.label}" if s.score is not None else f"{s.label} (label only)"


def _ids(f: Finding) -> str:
    others = [i for i in (f.vuln_id, *f.aliases)
              if i not in f.cve_ids and not any(c in i.upper() for c in f.cve_ids)]
    return ", ".join([*f.cve_ids, *others])


def render_markdown(ctx: ScanContext, lookup: LookupResult, catalogue: KevCatalogue | None,
                    euvd: EuvdCatalogue | None = None) -> str:
    open_findings = ordered([f for f in lookup.findings if f.vex_status not in models.RESOLVED_STATUSES],
                            catalogue, euvd)
    resolved = [f for f in lookup.findings if f.vex_status in models.RESOLVED_STATUSES]
    lists_used = " and ".join(x for x, used in (("CISA KEV", catalogue), ("ENISA EUVD", euvd is not None)) if used)
    hits = [f for f in ordered(lookup.findings, catalogue, euvd) if candidate_sources(f, catalogue, euvd)]
    skipped_total = sum(lookup.skipped.values())
    unknown_total = sum(len(v) for v in lookup.cvelist_unknown.values())
    by_source = ", ".join(f"{src}: {n}" for src, n in sorted(lookup.checked_by.items()))

    lines = [f"# Vulnerability scan report: {_md(ctx.sbom_name)}", "",
             f"Generated {ctx.generated_at} (UTC) by keelbook {ctx.tool_version}. Working aid, not legal advice.",
             "", "## Summary", "", "| | |", "|---|---|"]
    if open_findings:
        components = len({(f.component.name, f.component.version) for f in open_findings})
        counts = _severity_counts(open_findings)
        lines += [f"| Open findings | **{len(open_findings):,}** in {components} component(s) |",
                  "| Severity | " + " · ".join(f"{k} {v:,}" for k, v in counts.items() if v) + " |"]
    elif lookup.checked == 0 and ctx.total_components:
        lines.append("| Result | **Nothing could be checked. An empty result does NOT mean the product is free of "
                     "known vulnerabilities.** |")
    else:
        lines.append("| Open findings | none for the checked components |")
    if lists_used:
        lines.append(f"| Listed as exploited ({lists_used}) | **{len(hits)}** (candidates; a person decides) |")
    else:
        lines.append("| Listed as exploited | **not checked**: no exploited-vulnerability list was used "
                     "(--kev-download, --euvd) |")
    if resolved:
        lines.append(f"| Marked fixed or not affected by the SBOM producer | {len(resolved):,} |")
    coverage = f"Checked {lookup.checked} of {ctx.total_components} component(s)" + (f" ({by_source})" if by_source else "")
    if skipped_total:
        reasons = "; ".join(f"{n} {_md(r)}" for r, n in sorted(lookup.skipped.items()))
        coverage += f"; **NOT checked: {skipped_total}** ({reasons}), not reported as clean"
    lines.append(f"| Coverage | {coverage} |")
    if unknown_total:
        lines.append(f"| Could not be compared | {unknown_total} CVE record(s) give versions that cannot be compared "
                     "with yours (see Check once): not counted, not clean |")
    if "NVD" in lookup.checked_by and not lookup.cvelist_label:
        lines.append("| CVE List | **not used**: CVEs that NVD has not analysed yet are missing (--cve-list) |")

    if lists_used:
        lines += ["", f"## Act first: listed as exploited ({len(hits)})", ""]
        if hits:
            lines += ["| Vulnerability | Component | Severity | Fixed in | Listed in |", "|---|---|---|---|---|"]
            for f in hits:
                listed = []
                for k in kev_matches(f, catalogue) if catalogue else []:
                    listed.append(f"CISA KEV since {k.date_added or '?'}, ransomware use {k.ransomware or '?'}")
                for e in euvd_matches(f, euvd) if euvd is not None else []:
                    listed.append(f"EUVD {e.euvd_id}, exploited since {e.exploited_since or '?'}")
                lines.append(f"| {_md(' '.join(f.cve_ids))} | {_md(display_name(f.component, f.also_in))} | "
                             f"{_short_sev(f)} | {_md(f.fixed_text)} | {_md('; '.join(listed))} |")
            lines += ["", "If one of these is really exploited in your product, the CRA Art. 14 clocks (24 h / 72 h) "
                      "may be running. A listing is a candidate only: Art. 3(42) needs reliable evidence of "
                      "exploitation, and a person decides."]
        else:
            lines.append(f"None of the findings is listed in {lists_used}.")
        no_cve = sum(1 for f in lookup.findings if not f.cve_ids)
        if no_cve:
            lines.append(f"\n{no_cve} finding(s) have no CVE ID and could not be matched against these lists.")

    if open_findings:
        rows = upgrade_summary(open_findings)
        lines += ["", f"## Components ({len(rows)})", "",
                  "| Component | Findings | Critical | High | Medium | Low | Unknown | Upgrade to at least | "
                  "Only in a newer line | Without fix data |",
                  "|---|--:|--:|--:|--:|--:|--:|---|--:|--:|"]
        by_component: dict[tuple[str, str], list[Finding]] = {}
        for f in open_findings:
            by_component.setdefault((f.component.name, f.component.version or "-"), []).append(f)
        for r in rows:
            c = _severity_counts(by_component[(r.component, r.version)])
            lines.append(f"| {_md(r.display)} | {r.findings:,} | {c['critical']:,} | {c['high']:,} | {c['medium']:,} | "
                         f"{c['low']:,} | {c['unknown']:,} | **{_md(r.upgrade_to or 'unknown')}** | "
                         f"{f'{r.newer_line:,}' if r.newer_line else '-'} | {f'{r.unknown:,}' if r.unknown else '-'} |")
        lines += ["", "'Upgrade to at least' stays in the installed release line (e.g. 6.12.x for a 6.12 kernel); "
                  "'Only in a newer line' counts findings that no update of that line fixes yet. 'unknown' means "
                  "no usable data, not that no fix exists."]

        lines += ["", "## Findings by component", ""]
        for r in rows:
            items = by_component[(r.component, r.version)]
            lines += [f"### {_md(r.display)}: {len(items):,} finding(s)", ""]
            first = items[0]
            if first.also_in:
                names = [first.component.name, *first.also_in]
                shown = ", ".join(names[:5]) + (f" and {len(names) - 5} more" if len(names) > 5 else "")
                lines += [f"Built from the same source: {len(names)} package(s) ({_md(shown)})", ""]
            table = _finding_table(items, catalogue, euvd)
            head, body = table[:2], table[2:]
            lines += head + body[:FINDINGS_SHOWN_PER_COMPONENT]
            if len(body) > FINDINGS_SHOWN_PER_COMPONENT:
                lines += ["", f"<details><summary>Show the other {len(body) - FINDINGS_SHOWN_PER_COMPONENT:,} "
                          "finding(s)</summary>", "", *head, *body[FINDINGS_SHOWN_PER_COMPONENT:], "", "</details>"]
            lines.append("")
    elif lookup.checked:
        lines += ["", "## Findings", "", "No open known vulnerabilities for the checked components."]

    vendor_rows: dict[tuple[str, str, str], int] = {}
    for f in lookup.findings:
        where = "NVD" if f.source.startswith("NVD") else "CVE record"
        for vendor in f.vendor_unconfirmed:
            key = (display_name(f.component, f.also_in), vendor, where)
            vendor_rows[key] = vendor_rows.get(key, 0) + 1
    if vendor_rows or lookup.cvelist_unknown or lookup.details_failed:
        lines += ["", "## Check once", ""]
        if vendor_rows:
            lines += ["### Matched by product name only", "",
                      "The SBOM gives no vendor for these components, and the vendor named by NVD or the CVE "
                      "record is not obviously the same project. If it is a different product, its findings do "
                      "not apply.", "", "| Component | Vendor named | By | Findings |", "|---|---|---|--:|"]
            for (name, vendor, where), n in sorted(vendor_rows.items(), key=lambda kv: (-kv[1], kv[0])):
                lines.append(f"| {_md(name)} | {_md(vendor)} | {where} | {n} |")
        if lookup.cvelist_unknown:
            lines += ["", "### CVE records whose versions could not be compared", "",
                      "These records name the component, but give versions as source commits, dates or "
                      "distribution packages. Not counted as findings, and not as clean.", ""]
            for name, ids in sorted(lookup.cvelist_unknown.items(), key=lambda kv: -len(kv[1])):
                lines.append(f"- **{_md(name)}** ({len(ids)}): {', '.join(ids)}")
        if lookup.details_failed:
            lines.append(f"\n{lookup.details_failed} finding(s) are listed by ID only (details could not be fetched).")

    if resolved:
        lines += ["", f"## Marked fixed or not affected by the SBOM producer: {len(resolved)}", "",
                  "These are the producer's own statements (e.g. Yocto cve-check, VEX in the SBOM). "
                  "The tool shows them as they are and does not verify them.", ""]
        lines += _finding_table(ordered(resolved, catalogue, euvd), catalogue, euvd)

    lines += ["", "## About this report", "",
              f"- SBOM file: {_md(ctx.sbom_name)}",
              f"- SBOM SHA-256: `{ctx.sbom_sha256}`",
              f"- SBOM format: {ctx.sbom_format} {ctx.spec_version or ''}".rstrip()
              + f", {ctx.total_components} component(s)"]
    if "OSV" in lookup.checked_by or not lookup.checked_by:
        lines.append("- Vulnerability source: OSV (api.osv.dev), queried with package names and versions only")
    if "NVD" in lookup.checked_by:
        nvd = "- Vulnerability source: NVD (services.nvd.nist.gov), queried with CPE vendor/product/version only"
        if lookup.nvd_oldest_data:
            nvd += (f"; oldest answer used was fetched {lookup.nvd_oldest_data} "
                    + ("(offline mode: saved answers of any age)" if lookup.offline else "(cached up to 24 h)"))
        lines.append(nvd)
    if lookup.cvelist_label:
        lines.append(f"- Vulnerability source: {lookup.cvelist_label} (official CVE records by the CNAs, local "
                     "index; nothing sent)")
    if lookup.offline:
        lines.append("- Offline mode: no network was used; only data saved earlier (dates above)")
    if catalogue:
        kev = f"- CISA KEV catalogue: released {(catalogue.released or 'unknown')[:10]}"
        if catalogue.version:
            kev += f", version {catalogue.version}"
        if catalogue.downloaded_at:
            kev += (f"; downloaded from cisa.gov {catalogue.downloaded_at}"
                    + (" (copy kept up to 24 h)" if catalogue.from_cache else ""))
        lines.append(kev)
    else:
        lines.append("- CISA KEV catalogue: not used in this scan")
    if euvd is not None:
        fetched = euvd.fetched_at.replace(microsecond=0).isoformat() if euvd.fetched_at else "unknown"
        lines.append(f"- ENISA EUVD exploited list: {euvd.total} entries, downloaded {fetched}"
                     + (" (from cache, up to 24 h old)" if euvd.from_cache else ""))
    else:
        lines.append("- ENISA EUVD exploited list: not used in this scan")
    if lookup.nvd_missed:
        missed = "; ".join(f"{n} {_md(r)}" for r, n in sorted(lookup.nvd_missed.items()))
        lines.append(f"- **Checked by the CVE List only, NOT by NVD:** {missed}")
    if lookup.nvd_platform_only:
        lines.append(f"- {lookup.nvd_platform_only} CVE(s) left out because NVD lists the product only as a "
                     "platform the vulnerable software runs on, not as vulnerable itself")
    if lookup.checked_by.keys() & {"NVD", "CVE List"}:
        lines.append("- Matching is by version number. A security patch backported without a version change is "
                     "not known unless the producer says so (VEX, Yocto cve-check)")
    lines += ["", "## Important", "", DISCLAIMER, ""]
    return "\n".join(lines)


def _finding_table(findings: list[Finding], catalogue: KevCatalogue | None,
                   euvd: EuvdCatalogue | None = None) -> list[str]:
    lists = catalogue is not None or euvd is not None
    show_status = any(f.vex_status for f in findings)
    head = "| Vulnerability | Severity | Fixed in |" + (" Exploited? |" if lists else "") + " Source |" \
        + (" Producer says |" if show_status else "") + " Summary |"
    lines = [head, "|" + "---|" * head.count(" |")]
    for f in findings:
        source = f.source
        if f.vendor_unconfirmed:
            source += f" (vendor? {', '.join(f.vendor_unconfirmed)})"
        row = f"| {_md(_ids(f))} | {_short_sev(f)} | {_md(f.fixed_text)} |"
        if lists:
            exploited = candidate_sources(f, catalogue, euvd)
            row += f" {'**' + ', '.join(exploited) + '**' if exploited else ('unknown (no CVE ID)' if not f.cve_ids else 'no')} |"
        row += f" {_md(source)} |"
        if show_status:
            row += f" {_md(status_text(f) or '-')} |"
        row += f" {_md(clean_summary(f.summary) or '-')} |"
        lines.append(row)
    return lines


def write_markdown(path: Path, ctx: ScanContext, lookup: LookupResult, catalogue: KevCatalogue | None,
                   euvd: EuvdCatalogue | None = None) -> None:
    path.write_text(render_markdown(ctx, lookup, catalogue, euvd), encoding="utf-8")
