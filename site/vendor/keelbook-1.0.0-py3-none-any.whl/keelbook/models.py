"""Plain data containers shared by the parsers and the CLI.

Kept free of any I/O or formatting so later features (vulnerability matching,
case files, deadline tracking) can reuse them without pulling in the CLI.
"""

from __future__ import annotations

from dataclasses import dataclass, field

# Normalised VEX statuses (CISA/OpenVEX vocabulary). Yocto cve-check's
# Patched/Ignored/Unpatched and SPDX 3.0 VEX relationship types map onto these.
FIXED = "fixed"
NOT_AFFECTED = "not_affected"
AFFECTED = "affected"
UNDER_INVESTIGATION = "under_investigation"
# Statuses that mean "the producer of the SBOM says this does not need action".
RESOLVED_STATUSES = frozenset({FIXED, NOT_AFFECTED})


@dataclass(frozen=True)
class Component:
    """One software component listed in an SBOM."""

    name: str
    version: str | None = None
    # Package ecosystem taken from the purl type (npm, pypi, maven, ...).
    # None when the SBOM gives no purl, which is common for firmware and C/C++
    # components in embedded products.
    ecosystem: str | None = None
    # Package URL, the most reliable identifier for matching against OSV.
    purl: str | None = None
    # Component type as declared by the SBOM (CycloneDX: library, firmware,
    # operating-system, ...). None for SPDX, which has no equivalent field.
    kind: str | None = None
    # CPE 2.3 name (cpe:2.3:part:vendor:product:version:...). Embedded build
    # systems such as Yocto identify packages this way instead of with a purl.
    cpe: str | None = None
    # The source package / recipe this binary package was built from
    # (Yocto: busybox-syslog comes from the busybox recipe). Used to match
    # build-system statements, which are made per recipe.
    source_package: str | None = None
    # CycloneDX "bom-ref": the SBOM's own ID for this component. VEX files
    # point at components by this ID, not by name.
    ref: str | None = None
    # SPDX 2.x links across documents (Yocto 5.0 writes one document per
    # package and per recipe): "namespace#SPDXID" of this package and of the
    # recipe it was GENERATED_FROM. Not part of a component's identity.
    spdx_address: str | None = field(default=None, compare=False)
    generated_from: str | None = field(default=None, compare=False)


@dataclass(frozen=True)
class VexStatement:
    """A statement by the SBOM producer about one vulnerability.

    Example: Yocto says CVE-2023-42364 is fixed in busybox (a backported patch).
    The tool never decides this itself; it only shows what the producer stated.
    """

    cve_id: str
    status: str  # one of FIXED, NOT_AFFECTED, AFFECTED, UNDER_INVESTIGATION
    # Lower-case package/recipe names the statement is about.
    targets: frozenset[str]
    source: str  # where the statement came from, e.g. "SPDX 3.0 VEX", "Yocto cve-check"
    detail: str | None = None  # justification, e.g. "backported-patch"


@dataclass
class Sbom:
    """A parsed SBOM, independent of the input format."""

    format: str  # "CycloneDX" or "SPDX"
    spec_version: str | None
    components: list[Component] = field(default_factory=list)
    # Non-fatal problems (e.g. skipped malformed entries). Shown to the user
    # so a partially broken SBOM is never silently treated as complete.
    warnings: list[str] = field(default_factory=list)
    # Informational messages about things deliberately left out (e.g. file
    # entries, the product's own root package). Not problems, but the user
    # should know the list was filtered.
    notes: list[str] = field(default_factory=list)
    # VEX statements found inside the SBOM (SPDX 3.0 from Yocto carries them).
    vex: list[VexStatement] = field(default_factory=list)
    serial: str | None = None  # CycloneDX serialNumber (urn:uuid:...), used to check VEX links
