"""Open an Art. 14 case from a finding in a scan's CSV file (keelbook scan --csv).

This only saves typing and keeps the link to the evidence: the component,
version and CVE IDs come from the scan, and the case records which scan file
(with its SHA-256) the finding came from. Whether the vulnerability is
actively exploited, and when the manufacturer became aware, are still stated
by a person when the case is opened.
"""

from __future__ import annotations

import csv
import re
from pathlib import Path
from typing import Any

from keelbook.errors import CaseError
from keelbook.report import sha256_of

_FORMULA_GUARD = re.compile(r"^'(?=[=+\-@\t\r])")  # undo report._csv_safe


def _clean(value: Any) -> str:
    return _FORMULA_GUARD.sub("", value or "").strip()


def finding_from_csv(path: Path, finding_id: str, component: str | None = None) -> dict[str, Any]:
    """The facts of one finding from a scan CSV, plus a reference to that file."""
    try:
        with path.open(encoding="utf-8", newline="") as handle:
            rows = list(csv.DictReader(handle))
    except FileNotFoundError as exc:
        raise CaseError(f"Scan file not found: {path}") from exc
    except (OSError, UnicodeDecodeError, csv.Error) as exc:
        raise CaseError(f"Cannot read the scan file {path}: {exc}") from exc
    if not rows or not {"component", "vuln_id", "cve_ids"} <= set(rows[0]):
        raise CaseError(f"{path} is not a findings CSV written by 'keelbook scan --csv'.")

    wanted = finding_id.strip().upper()
    matches = [
        r for r in rows
        if wanted == _clean(r.get("vuln_id")).upper()
        or wanted in _clean(r.get("cve_ids")).upper().split()
        or wanted in _clean(r.get("other_ids")).upper().split()
    ]
    if component:
        matches = [r for r in matches if _clean(r.get("component")).lower() == component.strip().lower()]
    if not matches:
        raise CaseError(f"No finding {finding_id} in {path}" + (f" for component {component}." if component else "."))
    names = sorted({_clean(r.get("component")) for r in matches})
    if len(names) > 1:
        raise CaseError(
            f"{finding_id} was found in several components ({', '.join(names)}). "
            "Choose one with --component."
        )
    row = matches[0]
    cves = _clean(row.get("cve_ids")).split()
    return {
        "component": _clean(row.get("component")) or None,
        "version": _clean(row.get("version")) or None,
        "cve_ids": cves,
        "finding": _clean(row.get("vuln_id")),
        "scan": {
            "file": path.name,
            "sha256": sha256_of(path),
            "finding": _clean(row.get("vuln_id")),
            "kev_candidate": _clean(row.get("kev_candidate")) or None,
            "euvd_exploited": _clean(row.get("euvd_exploited")) or None,
            "severity": " ".join(x for x in (_clean(row.get("cvss_score")), _clean(row.get("severity"))) if x) or None,
            "producer_status": _clean(row.get("producer_status")) or None,
        },
    }
