"""Register outputs: review sheet (CSV out and in), OpenVEX, release evidence pack.

Pure functions: no printing, no network, no database writes.
"""

from __future__ import annotations

import csv
import io
import json
import re
import uuid
from datetime import datetime, timezone
from typing import Any, Iterable

from keelbook.cases import CaseState, VerifyResult
from keelbook.cratext import QUOTES, SOURCE
from keelbook.register import (
    AFFECTED, DECIDED, FIXED, NEEDS_DECISION, NOT_AFFECTED, RECONFIRM, STATUSES,
    UNDER_INVESTIGATION, DecisionInput, ProductState, RegisterError, Release, ReviewRow, validate_decision,
)

DISCLAIMER = (
    "Working aid, not legal advice. Findings come from public vulnerability databases matched against "
    "the SBOM; decisions are statements by the named people, recorded verbatim. Producer statements "
    "(Yocto, VEX in the SBOM) are shown as received and were not verified by the tool."
)
OPENVEX_CONTEXT = "https://openvex.dev/ns/v0.2.0"

SHEET_INFO = ("product", "release", "key", "component", "version", "cve_ids", "other_ids", "severity",
              "kev", "euvd_exploited", "source", "matched_as", "check_vendor", "producer_says",
              "fixed_in_per_source", "summary", "state", "current_status", "current_justification",
              "current_impact", "current_action", "current_fixed_in", "current_reason", "decided_by",
              "decided_at", "decided_for_version")
SHEET_INPUT = ("new_status", "new_justification", "new_impact", "new_action", "new_fixed_in", "new_reason")
SHEET_COLUMNS = SHEET_INFO + SHEET_INPUT


# --- shared helpers ------------------------------------------------------------


def severity_text(finding: dict[str, Any]) -> str:
    sev = finding.get("severity")
    if not sev:
        return "unknown"
    if sev.get("score") is None:
        return f"{sev.get('label')} (label only)"
    return f"{sev['score']:.1f} {sev['label']}"


def _severity_value(finding: dict[str, Any]) -> float:
    sev = finding.get("severity")
    if not sev:
        return -1.0
    if sev.get("score") is not None:
        return float(sev["score"])
    return {"critical": 9.0, "high": 7.0, "medium": 4.0, "low": 0.1, "none": 0.0}.get(sev.get("label"), -1.0)


def exploited(finding: dict[str, Any]) -> bool:
    return finding.get("kev") is True or finding.get("euvd") is True


def ordered(rows: Iterable[ReviewRow]) -> list[ReviewRow]:
    """Exploited candidates first, then open before decided, then by severity."""
    state_rank = {NEEDS_DECISION: 0, RECONFIRM: 1, DECIDED: 2}
    return sorted(rows, key=lambda r: (not exploited(r.finding), state_rank[r.state], -_severity_value(r.finding),
                                       r.finding["component"].lower(), r.finding["key"]))


def _yes_no(value: Any) -> str:
    return "yes" if value is True else "no" if value is False else "unknown"


def _csv_safe(text: Any) -> str:
    text = "" if text is None else str(text)
    return "'" + text if text[:1] in ("=", "+", "-", "@", "\t", "\r") else text


def _csv_unsafe(text: Any) -> str:
    return re.sub(r"^'(?=[=+\-@\t\r])", "", (text or "")).strip()


def _producer_text(f: dict[str, Any]) -> str:
    if not f.get("producer_status"):
        return ""
    extra = ": ".join(x for x in (f.get("producer_source"), f.get("producer_detail")) if x)
    return f"{f['producer_status']} ({extra})" if extra else f["producer_status"]


# --- review sheet -----------------------------------------------------------------


def review_rows(state: ProductState, release: Release, rows: list[ReviewRow]) -> list[list[str]]:
    """The review sheet's rows (without header): one per finding, the new_* columns empty."""
    out = []
    for row in ordered(rows):
        f, d = row.finding, row.decision
        state_text = row.state + (f" ({row.note})" if row.note else "")
        out.append([("" if x is None else str(x)) for x in (
            state.id, release.label, f["key"], f["component"], f.get("version") or "",
            " ".join(f.get("cve_ids") or []),
            " ".join(i for i in [f["vuln_id"], *(f.get("aliases") or [])] if i not in (f.get("cve_ids") or [])),
            severity_text(f), _yes_no(f.get("kev")), _yes_no(f.get("euvd")), f.get("source") or "",
            f.get("matched_as") or "", " ".join(f.get("vendor_unconfirmed") or []), _producer_text(f),
            " ".join(f.get("fixed_in") or []) or (f.get("fix_note") or "unknown"), " ".join((f.get("summary") or "").split()),
            state_text,
            d.status if d else "", (d.justification or "") if d else "", (d.impact or "") if d else "",
            (d.action or "") if d else "", (d.fixed_in or "") if d else "", d.reason if d else "",
            d.by if d else "", d.at if d else "", (d.version or "") if d else "",
        )] + [""] * len(SHEET_INPUT))
    return out


def review_sheet(state: ProductState, release: Release, rows: list[ReviewRow]) -> str:
    """CSV for a person to fill in: one row per finding, the new_* columns are the input."""
    out = io.StringIO()
    writer = csv.writer(out)
    writer.writerow(SHEET_COLUMNS)
    for row in review_rows(state, release, rows):
        writer.writerow([_csv_safe(x) for x in row])
    return out.getvalue()


# Which column fixes which problem (from register.validate_decision), for messages a person can act on.
_PROBLEM_COLUMNS = (("status must be", ("new_status",)), ("a reason is required", ("new_reason",)),
                    ("justification must be", ("new_justification",)),
                    ("not_affected needs", ("new_justification", "new_impact")),
                    ("justification is only used", ("new_justification",)),
                    ("affected needs an action", ("new_action",)), ("fixed needs", ("new_fixed_in",)))


def read_review_sheet(text: str, state: ProductState, release: Release,
                      labels: dict[str, str] | None = None) -> list[DecisionInput]:
    """Decisions from a filled-in review sheet. Rows without new_status are ignored.

    The sheet must be for this product and release (it says so in every row), so a
    sheet cannot be imported into the wrong product by accident. All problems are
    collected and reported together; the caller records nothing if there are any.
    """
    text = text.lstrip("\ufeff")
    header = text.split("\n", 1)[0]
    # Excel in most EU locales (incl. Romania) saves CSV with ';' instead of ','.
    delimiter = max((",", ";", "\t"), key=header.count)
    reader = csv.DictReader(io.StringIO(text), delimiter=delimiter)
    missing = [c for c in ("product", "release", "key", *SHEET_INPUT) if c not in (reader.fieldnames or [])]
    if missing:
        raise RegisterError(f"This is not a review sheet from 'keelbook product sheet' (missing columns: "
                            f"{', '.join(missing)}).")
    items: list[DecisionInput] = []
    problems: list[str] = []
    for number, raw in enumerate(reader, start=2):  # row 1 is the header
        row = {k: _csv_unsafe(v) for k, v in raw.items() if k}
        status = row.get("new_status", "").lower().replace(" ", "_").replace("-", "_")
        if not status:
            filled = [c for c in SHEET_INPUT if c != "new_status" and (row.get(c) or "").strip()]
            if filled:  # text without a decision: almost certainly a forgotten drop-down, not "skip this row"
                names = ", ".join(f"'{(labels or {}).get(c, c)}'" for c in filled)
                problems.append(f"row {number} ({row.get('cve_ids') or row.get('key', '')}, {row.get('component', '')}): "
                                f"{names} filled in but no decision -> choose one in "
                                f"'{(labels or {}).get('new_status', 'new_status')}' (or clear the row)")
            continue
        if row["product"] != state.id or row["release"] != release.label:
            problems.append(f"row {number}: sheet is for {row['product']} {row['release']}, "
                            f"not {state.id} {release.label}")
            continue
        justification = row.get("new_justification", "").lower().replace(" ", "_").replace("-", "_") or None
        item = DecisionInput(
            key=row["key"], status=status, reason=row.get("new_reason", ""), justification=justification,
            impact=row.get("new_impact") or None, action=row.get("new_action") or None,
            fixed_in=row.get("new_fixed_in") or None,
        )
        where = f"row {number} ({row.get('cve_ids') or row['key'].split('|')[-1]}, {row.get('component', '')})"
        for problem in validate_decision(item):
            columns = next((cols for start, cols in _PROBLEM_COLUMNS if problem.startswith(start)), ())
            names = " or ".join(f"'{(labels or {}).get(c, c)}'" for c in columns)
            problems.append(f"{where}: {problem}" + (f" -> fill in {names}" if names else ""))
        items.append(item)
    if problems:
        raise RegisterError("Nothing was recorded. Fix these problems:\n  " + "\n  ".join(problems))
    if not items:
        raise RegisterError("The sheet has no rows with new_status filled in, so there is nothing to import.")
    return items


# --- OpenVEX -----------------------------------------------------------------------


def _component_iri(f: dict[str, Any]) -> str:
    if f.get("purl"):
        return f["purl"]
    if f.get("cpe"):
        return f["cpe"]
    return f"urn:keelbook:component:{f['component']}@{f.get('version') or 'unknown'}"


def openvex(state: ProductState, release: Release, rows: list[ReviewRow], author: str,
            product_iri: str | None = None, include_open: bool = False,
            now: datetime | None = None, document_id: str | None = None) -> tuple[dict[str, Any], dict[str, int]]:
    """OpenVEX 0.2.0 document for one release, plus counts of what was (not) included.

    Only decisions made for the component version in this release are exported.
    With include_open, findings without such a decision are exported as
    under_investigation, saying no decision has been recorded.
    """
    if not author or not author.strip():
        raise RegisterError("A VEX document needs an author (your organisation or name): use --author.")
    now = now or datetime.now(timezone.utc)
    product = product_iri or f"urn:keelbook:product:{state.id}:{release.label}"
    statements = []
    counts = {"exported": 0, "open_left_out": 0, "open_as_under_investigation": 0}
    seen: set[tuple[str, str]] = set()
    for row in ordered(rows):
        f = row.finding
        ident = (f["key"], f.get("version") or "")
        if ident in seen:
            continue
        seen.add(ident)
        name = (f.get("cve_ids") or [f["vuln_id"]])[0]
        aliases = [i for i in [*(f.get("cve_ids") or []), f["vuln_id"], *(f.get("aliases") or [])] if i != name]
        statement: dict[str, Any] = {
            "vulnerability": {"name": name, **({"aliases": sorted(set(aliases))} if aliases else {})},
            "products": [{"@id": product, "subcomponents": [{"@id": _component_iri(f)}]}],
        }
        if row.state == DECIDED:
            d = row.decision
            statement["status"] = d.status
            statement["timestamp"] = d.at
            if d.status == NOT_AFFECTED:
                if d.justification:
                    statement["justification"] = d.justification
                if d.impact:
                    statement["impact_statement"] = d.impact
            elif d.status == AFFECTED:
                statement["action_statement"] = d.action
            notes = d.reason + (f" Fixed in: {d.fixed_in}." if d.status == FIXED and d.fixed_in else "")
            statement["status_notes"] = notes.strip()
            counts["exported"] += 1
        elif include_open:
            statement["status"] = UNDER_INVESTIGATION
            statement["timestamp"] = _iso(now)
            statement["status_notes"] = "No decision has been recorded for this component version yet."
            counts["open_as_under_investigation"] += 1
        else:
            counts["open_left_out"] += 1
            continue
        statements.append(statement)
    document = {
        "@context": OPENVEX_CONTEXT,
        "@id": document_id or f"urn:uuid:{uuid.uuid4()}",
        "author": author.strip(),
        "timestamp": _iso(now),
        "version": 1,
        "tooling": "keelbook",
        "statements": statements,
    }
    return document, counts


def _iso(moment: datetime) -> str:
    return moment.astimezone(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def openvex_json(document: dict[str, Any]) -> str:
    return json.dumps(document, indent=2, ensure_ascii=False) + "\n"


# --- evidence pack -----------------------------------------------------------------


def _md(text: Any) -> str:
    return str("" if text is None else text).replace("|", "\\|").replace("\n", " ").replace("\r", " ")


def _decision_text(d) -> str:
    if d is None:
        return "-"
    extra = {NOT_AFFECTED: d.justification or d.impact, AFFECTED: d.action, FIXED: f"in {d.fixed_in}",
             UNDER_INVESTIGATION: None}.get(d.status)
    return d.status + (f" ({extra})" if extra else "")


def evidence_markdown(state: ProductState, release: Release, rows: list[ReviewRow], cases: list[CaseState],
                      verification: VerifyResult, tool_version: str, now: datetime | None = None) -> str:
    now = now or datetime.now(timezone.utc)
    rows = ordered(rows)
    counts = {s: sum(1 for r in rows if r.state == s) for s in (NEEDS_DECISION, RECONFIRM, DECIDED)}
    by_status = {s: sum(1 for r in rows if r.state == DECIDED and r.decision.status == s) for s in STATUSES}
    skipped = sum(release.skipped.values())
    lines = [
        f"# Vulnerability register - {_md(state.name)} ({state.id}) release {_md(release.label)}",
        "",
        f"- Generated (UTC): {_iso(now)} by keelbook {tool_version}",
        f"- SBOM: {_md(release.sbom_file)}, SHA-256 `{release.sbom_sha256}`",
        f"- Scanned (UTC): {release.scanned_at} by {_md(release.scanned_by)} with keelbook {_md(release.tool_version)}"
        + (f" (this release was scanned {release.rescans + 1} times; the latest scan is used)" if release.rescans else ""),
        f"- Vulnerability sources: {_md(', '.join(release.sources) or '-')}",
        f"- Coverage: {release.checked} of {release.total} component(s) checked"
        + (f"; **NOT checked: {skipped}** ("
           + "; ".join(f"{n} {_md(r)}" for r, n in sorted(release.skipped.items())) + ")" if skipped else ""),
        "",
        "## Product",
        "",
        *_product_lines(state, now),
        "",
    ]
    if "NVD" in release.sources and not any(s.startswith("CVE List") for s in release.sources):
        lines += ["**Not checked against the CVE List:** CVEs that NVD has not analysed yet are not included "
                  "in this scan. Scan with --cve-list.", ""]
    lines += [
        "## Summary",
        "",
        f"- Findings: {len(rows):,}",
        f"- Need a decision: **{counts[NEEDS_DECISION]:,}**",
        f"- Decided for another version, need re-confirmation: **{counts[RECONFIRM]:,}**",
        f"- Decided: {counts[DECIDED]:,} (" + ", ".join(f"{s}: {n:,}" for s, n in by_status.items()) + ")",
        "",
    ]
    hits = [r for r in rows if exploited(r.finding)]
    lists = [name for name, prefix in (("CISA KEV", "CISA KEV"), ("ENISA EUVD", "ENISA EUVD"))
             if any(s.startswith(prefix) for s in release.sources)]
    if not lists:
        lines += ["## Exploited-vulnerability candidates", "",
                  "**Not checked:** no exploited-vulnerability list (CISA KEV, ENISA EUVD) was used for this scan, "
                  "so it is unknown whether any finding is listed. Scan with --kev and/or --euvd.", ""]
    else:
        lines += [f"## Exploited-vulnerability candidates ({' and '.join(lists)}): {len(hits)}", ""]
    if not lists:
        pass
    elif hits:
        lines += ["| Component | Version | CVE | Listed in | Severity | State | Decision |", "|---|---|---|---|---|---|---|"]
        for r in hits:
            f = r.finding
            listed = ", ".join(x for x, v in (("KEV", f.get("kev")), ("EUVD", f.get("euvd"))) if v is True)
            lines.append(f"| {_md(_display(f))} | {_md(f.get('version'))} | {_md(' '.join(f.get('cve_ids') or []))} | "
                         f"{listed} | {severity_text(f)} | {r.state} | {_md(_decision_text(r.decision))} |")
        lines += ["", "A listing is a candidate only. Whether a vulnerability is actively exploited (CRA Art. 3(42)) "
                  "and Art. 14 reporting are decided by a person; see the cases below."]
    else:
        lines.append(f"None of the findings with a CVE ID is listed in {' or '.join(lists)}.")

    open_rows = [r for r in rows if r.state != DECIDED]
    decided = [r for r in rows if r.state == DECIDED]

    by_comp: dict[str, list[ReviewRow]] = {}
    for r in rows:
        by_comp.setdefault(_display(r.finding), []).append(r)
    lines += ["", f"## By component ({len(by_comp)})", "",
              "| Component | Findings | Open | Decided | not_affected | affected | fixed | under_investigation |",
              "|---|--:|--:|--:|--:|--:|--:|--:|"]
    for name, comp_rows in sorted(by_comp.items(), key=lambda kv: (-sum(1 for r in kv[1] if r.state != DECIDED),
                                                                   -len(kv[1]), kv[0])):
        st = {s: sum(1 for r in comp_rows if r.state == DECIDED and r.decision.status == s) for s in STATUSES}
        n_open = sum(1 for r in comp_rows if r.state != DECIDED)
        lines.append(f"| {_md(name)} | {len(comp_rows):,} | {n_open:,} | {len(comp_rows) - n_open:,} | "
                     + " | ".join(f"{st[s]:,}" for s in STATUSES) + " |")

    lines += ["", f"## Open: {len(open_rows):,}", ""]
    if open_rows:
        head = ["| Component | Version | Vulnerability | Severity | State | Producer says |", "|---|---|---|---|---|---|"]
        body = [f"| {_md(_display(r.finding))} | {_md(r.finding.get('version'))} | "
                f"{_md(r.finding['key'].split('|', 1)[1])} | {severity_text(r.finding)} | "
                f"{r.state}{_md(' - ' + r.note) if r.note else ''} | {_md(_producer_text(r.finding)) or '-'} |"
                for r in open_rows]
        lines += _folded(head, body, "open finding(s)")
    else:
        lines.append("Every finding of this release has a decision for its component version.")

    lines += ["", f"## Decisions: {len(decided):,}", ""]
    if decided:
        groups: dict[tuple, list[ReviewRow]] = {}
        for r in decided:
            d = r.decision
            groups.setdefault((_decision_text(d), d.reason, d.by), []).append(r)
        lines += ["Grouped: the same decision with the same reason by the same person.", "",
                  "| Findings | Components | Decision | Reason | By | At (UTC) |", "|--:|---|---|---|---|---|"]
        for (text, reason, by), group in sorted(groups.items(), key=lambda kv: -len(kv[1])):
            comps = sorted({_display(r.finding) for r in group})
            shown = ", ".join(comps[:3]) + (f" and {len(comps) - 3} more" if len(comps) > 3 else "")
            times = sorted(r.decision.at for r in group)
            when = times[0] if times[0] == times[-1] else f"{times[0]} to {times[-1]}"
            lines.append(f"| {len(group):,} | {_md(shown)} | {_md(text)} | {_md(reason)} | {_md(by)} | {when} |")
        lines += ["", "### Every decision", ""]
        head = ["| Component | Version | Vulnerability | Severity | Decision | Reason | By | At (UTC) |",
                "|---|---|---|---|---|---|---|---|"]
        body = [f"| {_md(_display(r.finding))} | {_md(r.finding.get('version'))} | "
                f"{_md(r.finding['key'].split('|', 1)[1])} | {severity_text(r.finding)} | "
                f"{_md(_decision_text(r.decision))} | {_md(r.decision.reason)} | {_md(r.decision.by)} | "
                f"{r.decision.at} |" for r in decided]
        lines += _folded(head, body, "decision(s)")

    cves = {c for r in rows for c in r.finding.get("cve_ids") or []}
    related = [c for c in cases if set(c.cve_ids) & cves]
    lines += ["", f"## Art. 14 cases about these vulnerabilities: {len(related)}", ""]
    for c in related:
        lines.append(f"- {c.case_id}: {_md(c.title)} ({c.track}, {'open' if c.is_open else 'closed'}; "
                     f"aware at {c.aware_at.strftime('%Y-%m-%d %H:%M UTC')})")
    if not related:
        lines.append("No case in this log names a CVE of this release.")

    lines += ["", "## Integrity", ""]
    if verification.ok:
        lines.append(f"The append-only log was verified: {verification.count} entries, head hash `{verification.head}`. "
                     "Keep this hash somewhere else (e.g. in an email): removing the newest entries can only be "
                     "detected by comparing it.")
    else:
        lines.append(f"**The log FAILED verification: {_md(verification.problem)}. Do not rely on this record.**")
    lines += ["", "## CRA provisions this record relates to (quoted)", ""]
    for reference, text in QUOTES:
        lines += [f"> **{reference}:** {text}", ">"]
    lines[-1:] = ["", f"Source: {SOURCE}. Quoted for context; which provisions apply to a product, and whether "
                  "this record meets them, is a legal assessment this tool does not make."]
    lines += ["", "## Important", "", DISCLAIMER, ""]
    return "\n".join(lines)


ROWS_UNFOLDED = 25


def _folded(head: list[str], body: list[str], what: str) -> list[str]:
    """A table whose rows beyond ROWS_UNFOLDED are folded into <details>: shown on request, never left out."""
    out = head + body[:ROWS_UNFOLDED]
    if len(body) > ROWS_UNFOLDED:
        out += ["", f"<details><summary>Show the other {len(body) - ROWS_UNFOLDED:,} {what}</summary>", "",
                *head, *body[ROWS_UNFOLDED:], "", "</details>"]
    return out


def _display(f: dict[str, Any]) -> str:
    from keelbook.models import Component
    from keelbook.vulns import display_name
    name = display_name(Component(name=f["component"], version=f.get("version"), cpe=f.get("cpe")),
                        tuple(f.get("also_in") or ()))
    return name.rsplit(" ", 1)[0] if f.get("version") else name


def _product_lines(state: ProductState, now: datetime) -> list[str]:
    d = state.details
    missing = "**not recorded** (`keelbook product edit`)"
    support = d.get("support_until")
    if support and support < now.date().isoformat():
        support = f"{support} - **the support period has ended**"
    return [
        f"- Name: {_md(state.name)} (`{state.id}`)",
        f"- Manufacturer: {_md(d['manufacturer']) if d.get('manufacturer') else missing}",
        f"- Single point of contact for vulnerabilities (Art. 13(17)): {_md(d['contact']) if d.get('contact') else missing}",
        f"- Coordinated vulnerability disclosure policy (Annex I Part II (5)): "
        f"{_md(d['cvd_policy']) if d.get('cvd_policy') else missing}",
        f"- End of support period (Art. 13(8)): {_md(support) if support else missing}",
    ]
