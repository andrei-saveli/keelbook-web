"""Severity (CVSS) of a finding: computing, choosing and labelling it.

Sources:
* NVD gives a numeric base score per CVSS version. We prefer CVSS 4.0, then
  3.1, 3.0, 2.0, and NVD's own ("Primary") score over a third party's.
* OSV usually gives only a CVSS VECTOR (e.g. "CVSS:3.1/AV:N/AC:L/..."). For
  CVSS 3.x we compute the base score with the formula from the FIRST CVSS 3.1
  specification, section 7. CVSS 4.0 and 2.0 vectors are not computed; if the
  record carries a text label (GitHub advisories do: "HIGH"), that is used.

Missing data stays "unknown". It is never shown as "low" or "none".
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any

LABELS = ("critical", "high", "medium", "low", "none")


@dataclass(frozen=True)
class Severity:
    score: float | None  # CVSS base score 0.0-10.0, None if only a label is known
    label: str  # critical, high, medium, low, none
    version: str | None  # "4.0", "3.1", "3.0", "2.0" or None (label only)
    source: str  # "NVD", "OSV", "GitHub label", ...

    def text(self) -> str:
        if self.score is None:
            return f"{self.label} (label only)"
        return f"{self.score:.1f} {self.label}" + (f" (CVSS {self.version})" if self.version else "")

    def sort_key(self) -> tuple[float, int]:
        """Higher = worse. Label-only severities sort by their band's lower bound."""
        band = {"critical": 9.0, "high": 7.0, "medium": 4.0, "low": 0.1, "none": 0.0}[self.label]
        return (self.score if self.score is not None else band, 1 if self.score is not None else 0)


def label_for(score: float) -> str:
    """CVSS v3/v4 qualitative rating scale."""
    if score >= 9.0:
        return "critical"
    if score >= 7.0:
        return "high"
    if score >= 4.0:
        return "medium"
    if score > 0.0:
        return "low"
    return "none"


def _normalise_label(text: Any) -> str | None:
    if not isinstance(text, str):
        return None
    text = text.strip().lower()
    text = {"moderate": "medium", "important": "high"}.get(text, text)
    return text if text in LABELS else None


# --- CVSS 3.x base score -----------------------------------------------------

_AV = {"N": 0.85, "A": 0.62, "L": 0.55, "P": 0.2}
_AC = {"L": 0.77, "H": 0.44}
_PR_UNCHANGED = {"N": 0.85, "L": 0.62, "H": 0.27}
_PR_CHANGED = {"N": 0.85, "L": 0.68, "H": 0.5}
_UI = {"N": 0.85, "R": 0.62}
_CIA = {"H": 0.56, "L": 0.22, "N": 0.0}


def _roundup(value: float) -> float:
    """CVSS 3.1 Roundup: smallest number with one decimal >= value (float-safe)."""
    integer = round(value * 100000)
    if integer % 10000 == 0:
        return integer / 100000.0
    return (math.floor(integer / 10000) + 1) / 10.0


def cvss3_base_score(vector: str) -> float | None:
    """Base score of a CVSS 3.0/3.1 vector, or None if it is not a valid 3.x vector."""
    if not isinstance(vector, str) or not vector.startswith(("CVSS:3.0/", "CVSS:3.1/")):
        return None
    metrics: dict[str, str] = {}
    for part in vector.split("/")[1:]:
        key, sep, value = part.partition(":")
        if not sep:
            return None
        metrics[key] = value
    try:
        scope_changed = {"U": False, "C": True}[metrics["S"]]
        av, ac, ui = _AV[metrics["AV"]], _AC[metrics["AC"]], _UI[metrics["UI"]]
        pr = (_PR_CHANGED if scope_changed else _PR_UNCHANGED)[metrics["PR"]]
        c, i, a = _CIA[metrics["C"]], _CIA[metrics["I"]], _CIA[metrics["A"]]
    except KeyError:
        return None
    iss = 1 - (1 - c) * (1 - i) * (1 - a)
    if scope_changed:
        impact = 7.52 * (iss - 0.029) - 3.25 * (iss - 0.02) ** 15
    else:
        impact = 6.42 * iss
    exploitability = 8.22 * av * ac * pr * ui
    if impact <= 0:
        return 0.0
    total = (1.08 if scope_changed else 1.0) * (impact + exploitability)
    return _roundup(min(total, 10.0))


# --- choosing a severity from source records ----------------------------------


def from_osv(details: list[dict[str, Any]]) -> Severity | None:
    """Worst severity across the OSV records of one finding (merged aliases)."""
    best: Severity | None = None
    for detail in details:
        candidates = []
        for entry in detail.get("severity") or []:
            if not isinstance(entry, dict):
                continue
            vector = entry.get("score")
            score = cvss3_base_score(vector) if entry.get("type") == "CVSS_V3" else None
            if score is not None:
                candidates.append(Severity(score, label_for(score), vector[5:8], "OSV"))
        label = _normalise_label((detail.get("database_specific") or {}).get("severity"))
        if not candidates and label:
            candidates.append(Severity(None, label, None, "advisory label"))
        for candidate in candidates:
            if best is None or candidate.sort_key() > best.sort_key():
                best = candidate
    return best


_NVD_METRICS = (("cvssMetricV40", "4.0"), ("cvssMetricV31", "3.1"), ("cvssMetricV30", "3.0"), ("cvssMetricV2", "2.0"))


def from_nvd_metrics(metrics: Any) -> dict[str, Any] | None:
    """Pick one NVD score: newest CVSS version, NVD's own (Primary) before others.

    Returns a small dict (stored in the cache): {"score", "label", "version"}.
    """
    if not isinstance(metrics, dict):
        return None
    for key, version in _NVD_METRICS:
        entries = [m for m in metrics.get(key) or [] if isinstance(m, dict) and isinstance(m.get("cvssData"), dict)]
        entries.sort(key=lambda m: 0 if m.get("type") == "Primary" else 1)
        for entry in entries:
            score = entry["cvssData"].get("baseScore")
            if isinstance(score, (int, float)) and 0 <= score <= 10:
                label = _normalise_label(entry["cvssData"].get("baseSeverity") or entry.get("baseSeverity"))
                if version == "2.0" or label is None:
                    # CVSS 2 uses a different scale (no "critical"); keep NVD's label if given.
                    label = label or label_for(float(score))
                return {"score": float(score), "label": label, "version": version}
    return None


def from_cached(value: Any) -> Severity | None:
    if isinstance(value, dict) and isinstance(value.get("score"), (int, float)) and value.get("label") in LABELS:
        return Severity(float(value["score"]), value["label"], value.get("version"), "NVD")
    return None
