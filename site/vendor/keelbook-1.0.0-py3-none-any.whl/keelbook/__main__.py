"""Allows `python -m keelbook ...` as an alternative to the `keelbook` script."""

from keelbook.cli import run

if __name__ == "__main__":
    run(prog_name="keelbook")
