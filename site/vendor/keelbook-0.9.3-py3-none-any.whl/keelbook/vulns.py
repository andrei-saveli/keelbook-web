"""Vulnerability lookup against OSV (https://osv.dev).

Only package identifiers and versions are sent (purl, or name + ecosystem +
version). Never source code, never the SBOM file itself.

Important behaviour: a component that cannot be checked (no purl, no version,
unsupported ecosystem) is counted as SKIPPED, never as "clean". The caller must
show the skip counts, because silence about a component is not a safe result.

Network access goes through an injectable `http` function so tests run offline.
"""

from __future__ import annotations

import json
import re
import time
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from typing import Any, Callable

from keelbook import __version__
from keelbook.errors import VulnLookupError
from keelbook.models import Component
from keelbook.severity import Severity, from_osv

# Why a finding has no fixed-in version (instead of a bare "unknown"):
NO_FIX_RECORDED = "no fix recorded"  # the source names no fixed version at all
CANNOT_COMPARE = "could not compare"  # a fix exists, but the versions could not be compared reliably

OSV_BASE = "https://api.osv.dev"
BATCH_SIZE = 500  # OSV accepts up to 1000 queries per batch; stay well below
MAX_RETRIES = 3
TIMEOUT_SECONDS = 30
DETAIL_WORKERS = 8
RETRY_STATUS = {429, 500, 502, 503, 504}

# purl types that OSV resolves directly from a purl. Alpine (apk) is handled
# separately because it needs the distro release. deb/rpm are not supported yet.
PURL_TYPES_BY_PURL = {
    "npm", "pypi", "maven", "golang", "cargo", "nuget", "gem", "composer", "hex", "pub",
}

# (method, url, json_body_or_None) -> parsed JSON response
HttpFn = Callable[[str, str, "dict[str, Any] | None"], "dict[str, Any]"]


@dataclass(frozen=True)
class Finding:
    """A known vulnerability matched to a component."""

    component: Component
    vuln_id: str  # OSV ID, e.g. GHSA-..., ALPINE-CVE-...
    aliases: tuple[str, ...] = ()  # e.g. the CVE ID
    summary: str | None = None
    fixed_in: tuple[str, ...] = ()  # versions that fix it, when the source says so and we can compare reliably
    source: str = "OSV"  # where the finding came from: OSV, NVD, Yocto cve-check
    # Other packages in the SBOM that share the same CPE lookup (Yocto builds
    # several binary packages from one recipe: busybox, busybox-syslog, ...).
    also_in: tuple[str, ...] = ()
    matched_as: str | None = None  # NVD: the CPE product it was matched on, e.g. "*:busybox 1.36.1"
    # Statement by the SBOM producer / build system (VEX), never our own decision.
    vex_status: str | None = None  # fixed, not_affected, affected, under_investigation
    vex_detail: str | None = None
    vex_source: str | None = None
    severity: Severity | None = None  # None = unknown (never "low")
    # NVD only: the SBOM's CPE gave no vendor, so the match is on the product
    # name alone; these are the vendors NVD names. A person should check them.
    vendor_unconfirmed: tuple[str, ...] = ()
    fix_note: str | None = None  # NO_FIX_RECORDED or CANNOT_COMPARE when fixed_in is empty
    # CVE List only: source files the CVE record names (Linux kernel), for build-based filtering.
    program_files: tuple[str, ...] = ()

    @property
    def fixed_text(self) -> str:
        return ", ".join(self.fixed_in) or self.fix_note or "unknown"

    @property
    def cve_ids(self) -> tuple[str, ...]:
        """All CVE IDs for this finding, also those hidden inside IDs such as
        ALPINE-CVE-2023-0464 (Alpine files advisories without a CVE alias)."""
        found = {m.upper() for text in (self.vuln_id, *self.aliases) for m in _CVE_RE.findall(text)}
        return tuple(sorted(found))


_CVE_RE = re.compile(r"CVE-\d{4}-\d{4,}", re.IGNORECASE)


@dataclass
class LookupResult:
    findings: list[Finding] = field(default_factory=list)
    checked: int = 0  # components for which at least one query was sent
    skipped: dict[str, int] = field(default_factory=dict)  # reason -> count
    details_failed: int = 0  # findings listed by ID only (detail fetch failed)
    checked_by: dict[str, int] = field(default_factory=dict)  # source -> components checked
    nvd_requests: int = 0
    nvd_cache_hits: int = 0
    nvd_oldest_data: str | None = None  # ISO time of the oldest NVD answer used
    nvd_platform_only: int = 0  # CVEs dropped: product only listed as a platform, not vulnerable
    merged_duplicates: int = 0  # same CVE for the same component found via several CPEs, shown once
    cvelist_label: str | None = None  # "CVE List 2026-11-01" when the CVE List index was used
    # Components NVD could not check but the CVE List did: reason -> count (shown, never hidden).
    nvd_missed: dict[str, int] = field(default_factory=dict)
    offline: bool = False  # --offline: saved data only, of any age
    # Per component: CVE records naming the product whose versions could not be compared.
    cvelist_unknown: dict[str, list[str]] = field(default_factory=dict)


def default_http(method: str, url: str, body: dict[str, Any] | None) -> dict[str, Any]:
    """Real HTTP using only the standard library, with retry on transient errors."""
    data = json.dumps(body).encode() if body is not None else None
    request = urllib.request.Request(
        url,
        data=data,
        method=method,
        headers={"Content-Type": "application/json", "User-Agent": f"keelbook/{__version__}"},
    )
    last_problem = "unknown error"
    for attempt in range(MAX_RETRIES):
        try:
            with urllib.request.urlopen(request, timeout=TIMEOUT_SECONDS) as response:
                return json.loads(response.read())
        except urllib.error.HTTPError as exc:  # must come before URLError (its parent)
            last_problem = f"HTTP {exc.code}"
            if exc.code not in RETRY_STATUS:
                raise VulnLookupError(f"OSV answered with HTTP {exc.code} for {url}") from exc
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            reason = getattr(exc, "reason", exc)
            last_problem = str(reason)
        except json.JSONDecodeError as exc:
            raise VulnLookupError("OSV returned a response that is not valid JSON") from exc
        if attempt < MAX_RETRIES - 1:
            time.sleep(2**attempt)  # 1 s, then 2 s
    raise VulnLookupError(
        f"Could not get an answer from OSV ({last_problem}). "
        "Check your internet connection and try again."
    )


# --- Query building ---------------------------------------------------------


def _purl_qualifiers(purl: str) -> dict[str, str]:
    _, _, rest = purl.partition("?")
    rest = rest.split("#")[0]
    return {key: values[0] for key, values in urllib.parse.parse_qs(rest).items()}


def build_queries(component: Component) -> tuple[list[dict[str, Any]], str | None]:
    """Return (OSV query bodies, None) or ([], reason the component is skipped)."""
    if not component.purl:
        return [], "no purl"
    if not component.version:
        return [], "no version"

    if component.ecosystem == "apk":
        return _alpine_queries(component)
    if component.ecosystem in PURL_TYPES_BY_PURL:
        return [_purl_query(component)], None
    return [], f"ecosystem '{component.ecosystem or 'unknown'}' not supported yet"


def _purl_query(component: Component) -> dict[str, Any]:
    # Drop qualifiers/subpath. OSV rejects a versioned purl combined with a
    # separate "version" field, so add the version only when the purl lacks one.
    base = re.split(r"[?#]", component.purl or "")[0]
    if "@" in base.rsplit("/", 1)[-1]:
        return {"package": {"purl": base}}
    return {"package": {"purl": base}, "version": component.version}


def _alpine_queries(component: Component) -> tuple[list[dict[str, Any]], str | None]:
    qualifiers = _purl_qualifiers(component.purl or "")
    match = re.match(r"alpine-(\d+)\.(\d+)", qualifiers.get("distro", ""))
    if not match:
        return [], "apk package without an Alpine release in its purl"
    ecosystem = f"Alpine:v{match.group(1)}.{match.group(2)}"

    # Alpine advisories are filed under the SOURCE package (libssl3 -> openssl),
    # so query the binary name and, when the SBOM gives it, the upstream name.
    names = [component.name]
    upstream = qualifiers.get("upstream", "").split("@")[0].strip()
    if upstream and upstream not in names:
        names.append(upstream)
    return [
        {"package": {"name": name, "ecosystem": ecosystem}, "version": component.version}
        for name in names
    ], None


# --- Lookup -----------------------------------------------------------------


def check_vulnerabilities(
    components: list[Component],
    http: HttpFn = default_http,
    base_url: str = OSV_BASE,
    batch_size: int = BATCH_SIZE,
) -> LookupResult:
    """Look up known vulnerabilities for `components` in OSV."""
    result = LookupResult()

    # 1. Plan: one or more queries per checkable component.
    planned: list[tuple[int, dict[str, Any]]] = []
    for index, component in enumerate(components):
        queries, reason = build_queries(component)
        if reason:
            result.skipped[reason] = result.skipped.get(reason, 0) + 1
            continue
        result.checked += 1
        planned.extend((index, query) for query in queries)

    # 2. Batch-query, following pagination tokens.
    ids_by_component: dict[int, set[str]] = {}
    pending = planned
    while pending:
        next_pending: list[tuple[int, dict[str, Any]]] = []
        for start in range(0, len(pending), batch_size):
            chunk = pending[start : start + batch_size]
            response = http("POST", f"{base_url}/v1/querybatch", {"queries": [q for _, q in chunk]})
            answers = response.get("results") if isinstance(response, dict) else None
            if not isinstance(answers, list) or len(answers) != len(chunk):
                raise VulnLookupError("OSV returned an unexpected batch response")
            for (index, query), answer in zip(chunk, answers):
                answer = answer or {}
                for vuln in answer.get("vulns") or []:
                    if isinstance(vuln, dict) and isinstance(vuln.get("id"), str):
                        ids_by_component.setdefault(index, set()).add(vuln["id"])
                token = answer.get("next_page_token")
                if token:
                    next_pending.append((index, {**query, "page_token": token}))
        pending = next_pending

    # 3. Fetch details (aliases, summary) once per unique ID, in parallel.
    unique_ids = sorted({vid for ids in ids_by_component.values() for vid in ids})
    details: dict[str, dict[str, Any] | None] = {}

    def fetch(vuln_id: str) -> tuple[str, dict[str, Any] | None]:
        try:
            url = f"{base_url}/v1/vulns/{urllib.parse.quote(vuln_id, safe='')}"
            return vuln_id, http("GET", url, None)
        except VulnLookupError:
            return vuln_id, None  # keep the finding, listed by ID only

    if unique_ids:
        with ThreadPoolExecutor(max_workers=DETAIL_WORKERS) as pool:
            details = dict(pool.map(fetch, unique_ids))
    result.details_failed = sum(1 for d in details.values() if d is None)

    # 4. Assemble findings. The same flaw is often published under several IDs
    # (GHSA-..., PYSEC-..., CVE-...) that list each other as aliases. Merge
    # those into ONE finding per component so the report is not inflated.
    for index, ids in ids_by_component.items():
        for group in _alias_groups(ids, details):
            primary = min(group & ids, key=_id_rank)
            detail = details.get(primary) or {}
            others = sorted(group - {primary})
            group_details = [details.get(i) or {} for i in sorted(group)]
            fixed = fixed_versions(group_details, components[index])
            result.findings.append(
                Finding(
                    component=components[index],
                    vuln_id=primary,
                    aliases=tuple(others),
                    summary=_summary(detail),
                    fixed_in=fixed,
                    severity=from_osv(group_details),
                    fix_note=None if fixed else fix_note(group_details, components[index]),
                )
            )
    result.findings.sort(key=lambda f: (f.component.name.lower(), f.vuln_id))
    return result


def _id_rank(vuln_id: str) -> tuple[int, str]:
    """Prefer GHSA, then vendor/ecosystem IDs, then bare CVE as the primary ID."""
    if vuln_id.startswith("GHSA-"):
        return (0, vuln_id)
    if vuln_id.startswith("CVE-"):
        return (2, vuln_id)
    return (1, vuln_id)


def _alias_groups(ids: set[str], details: dict[str, dict[str, Any] | None]) -> list[set[str]]:
    """Group IDs that are the same vulnerability (share any ID or alias).

    Each returned set holds every ID/alias of the group, including the OSV IDs
    that were actually matched. The primary ID is always one of the matched IDs.
    """
    parent: dict[str, str] = {}

    def find(x: str) -> str:
        parent.setdefault(x, x)
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    for vuln_id in ids:
        find(vuln_id)
        for alias in (details.get(vuln_id) or {}).get("aliases") or []:
            if isinstance(alias, str):
                parent[find(alias)] = find(vuln_id)

    groups: dict[str, set[str]] = {}
    for node in list(parent):
        groups.setdefault(find(node), set()).add(node)
    # Keep only groups that contain at least one matched ID (always true here).
    return [g for g in groups.values() if g & ids]


def _summary(detail: dict[str, Any]) -> str | None:
    text = detail.get("summary")
    if not isinstance(text, str) or not text.strip():
        text = detail.get("details")
    if not isinstance(text, str) or not text.strip():
        return None
    # OpenSSL advisories all start with "Issue summary:", which hides the
    # useful part in a narrow table; some texts also contain HTML line breaks.
    text = re.sub(r"<br\s*/?>", " ", text.strip())
    first_line = re.sub(r"^issue summary:\s*", "", text.splitlines()[0], flags=re.IGNORECASE)
    return first_line if len(first_line) <= 100 else first_line[:97] + "..."


# --- fixed-in versions ------------------------------------------------------
#
# OSV lists, per affected package, ranges made of events such as
# {"introduced": "1.0.0"}, {"fixed": "1.2.3"}. We report a fixed version only
# when (a) the affected package name matches the component, (b) the range is
# SEMVER or ECOSYSTEM type, and (c) the installed version and every bound can
# be compared with plain dotted-number rules. Anything else is left empty,
# which the output shows as "unknown" (never as "no fix exists").

_VERSION_RE = re.compile(r"^v?(\d+(?:\.\d+)*)(?:-([0-9A-Za-z.-]+))?(?:\+.*)?$")


def parse_version(text: object) -> tuple | None:
    """Comparable key for simple dotted versions, or None if we cannot be sure."""
    if not isinstance(text, str):
        return None
    match = _VERSION_RE.match(text.strip())
    if not match:
        return None
    numbers = [int(n) for n in match.group(1).split(".")]
    while len(numbers) > 1 and numbers[-1] == 0:  # 1.2 == 1.2.0
        numbers.pop()
    pre = match.group(2)
    revision = re.fullmatch(r"r(\d+)", pre or "")
    if revision:  # Alpine/apk revision (3.0.8-r1): comes AFTER 3.0.8, not before
        return (tuple(numbers), 1, f"r{int(revision.group(1)):08d}")
    # A release sorts after its own pre-releases (1.0.0-rc1 < 1.0.0).
    return (tuple(numbers), 1 if pre is None else 0, pre or "")


def _norm_name(name: str) -> str:
    return name.strip().lower().replace(":", "/")


def fixed_versions(details: list[dict[str, Any]], component: Component) -> tuple[str, ...]:
    """Versions that fix the flaw for this component, taken from the OSV records."""
    installed = parse_version(component.version)
    if installed is None:
        return ()
    names = {_norm_name(component.name)}
    upstream = _purl_qualifiers(component.purl).get("upstream") if component.purl else None
    if upstream:
        names.add(_norm_name(upstream))

    found: dict[tuple, str] = {}
    for detail in details:
        for affected in detail.get("affected") or []:
            package = (affected.get("package") or {}).get("name")
            if not isinstance(package, str) or _norm_name(package) not in names:
                continue
            for rng in affected.get("ranges") or []:
                if rng.get("type") not in ("SEMVER", "ECOSYSTEM"):
                    continue
                fixed = _fixed_for(rng.get("events") or [], installed)
                if fixed is not None:
                    key = parse_version(fixed)
                    if key is not None:
                        found[key] = fixed
    return tuple(found[k] for k in sorted(found))


def fix_note(details: list[dict[str, Any]], component: Component) -> str:
    """Why no fixed-in version could be given: none recorded, or not comparable."""
    if parse_version(component.version) is None:
        return CANNOT_COMPARE
    names = {_norm_name(component.name)}
    upstream = _purl_qualifiers(component.purl).get("upstream") if component.purl else None
    if upstream:
        names.add(_norm_name(upstream))
    named = has_fixed = False
    for detail in details:
        for affected in detail.get("affected") or []:
            package = (affected.get("package") or {}).get("name")
            if not isinstance(package, str) or _norm_name(package) not in names:
                continue
            named = True
            for rng in affected.get("ranges") or []:
                if any("fixed" in event for event in rng.get("events") or []):
                    has_fixed = True
    return NO_FIX_RECORDED if named and not has_fixed else CANNOT_COMPARE


def _fixed_for(events: list[dict[str, Any]], installed: tuple) -> str | None:
    """The 'fixed' bound of the interval that contains the installed version."""
    start: tuple | None = None
    for event in events:
        if "introduced" in event:
            start = parse_version("0.0.0" if event["introduced"] == "0" else event["introduced"])
            if start is None:
                return None
        elif "fixed" in event or "last_affected" in event:
            if start is None:
                continue
            bound_text = event.get("fixed") or event.get("last_affected")
            bound = parse_version(bound_text)
            if bound is None:
                return None
            inside = installed >= start and (installed < bound if "fixed" in event else installed <= bound)
            if inside:
                return bound_text if "fixed" in event else None
            start = None
    return None


@dataclass(frozen=True)
class UpgradeRow:
    component: str
    version: str
    findings: int
    upgrade_to: str | None  # lowest version that fixes every finding we have data for
    unknown: int  # findings without usable fixed-in data
    worst: Severity | None = None  # highest severity among the findings (None = all unknown)
    newer_line: int = 0  # findings fixed only in a newer release line (e.g. kernel 6.18 for a 6.12 kernel)
    newer_line_max: str | None = None  # highest of those fixes
    display: str = ""  # short component label for people


_BOILERPLATE = re.compile(r"^In the Linux kernel, the following vulnerability has been resolved:\s*", re.IGNORECASE)


def clean_summary(text: str | None) -> str | None:
    """Drop boilerplate that starts thousands of kernel CVE texts, so the actual problem shows."""
    if not text:
        return text
    return _BOILERPLATE.sub("", text).strip() or text


def is_version(text: object) -> bool:
    """A usable version number, not a date ('2023-09-12') or a commit."""
    return (isinstance(text, str) and not re.match(r"^\d{4}-\d{2}-\d{2}", text.strip())
            and parse_version(text) is not None)


def same_line(installed: str | None, fixed: str) -> bool:
    """Is `fixed` in the installed release line (same first two numbers: 6.12.49 -> 6.12.x)?"""
    a, b = parse_version(re.sub(r"\+git.*$", "", installed or "")), parse_version(fixed)
    if a is None or b is None:
        return False
    width = min(2, len(a[0]))
    return (tuple(a[0][:width]) + (0,) * width)[:width] == (tuple(b[0][:width]) + (0,) * width)[:width]


def display_name(component: Component, also_in: tuple[str, ...] = ()) -> str:
    """Short label for people: 'linux kernel 6.12.49' instead of a long Yocto package name."""
    name = component.name
    if "/" in name:  # Maven/Go style "org.apache.logging.log4j/log4j-core": the last part names it
        name = name.rstrip("/").rsplit("/", 1)[-1] or name
    if (component.source_package and (also_in or len(name) > 28)
            and len(component.source_package) < len(name)):
        name = component.source_package
    if len(name) > 20 and re.search(r"\d+\.\d+", name) and component.cpe:
        product = component.cpe.split(":")[4] if component.cpe.count(":") >= 5 else ""
        if product and product not in ("*", "-"):
            name = product.replace("\\", "").replace("_", " ")
    if len(name) > 32:
        name = name[:30] + "…"
    version = re.sub(r"\+git.*$", "", component.version or "-")
    return f"{name} {version}"


def upgrade_summary(findings: list[Finding]) -> list[UpgradeRow]:
    """One row per component version: how many findings and what to upgrade to.

    The target is the highest fix in the installed release line (6.12.114 for a 6.12.49
    kernel); findings fixed only in a newer line are counted separately, so the advice
    is not "upgrade to 7.2" when a stable update of your own line fixes almost everything.
    """
    groups: dict[tuple[str, str], list[Finding]] = {}
    for f in findings:
        groups.setdefault((f.component.name, f.component.version or "-"), []).append(f)
    rows = []
    for (name, version), items in groups.items():
        own, newer, unknown = [], [], 0
        for f in items:
            fixes = [v for v in f.fixed_in if is_version(v)]
            if not fixes:
                unknown += 1
                continue
            mine = [v for v in fixes if same_line(version, v)]
            if mine:
                own.append(min(mine, key=parse_version))
            else:
                newer.append(min(fixes, key=parse_version))
        if own:
            best = max(own, key=parse_version)
        elif newer:
            best, newer = max(newer, key=parse_version), []
        else:
            best = None
        severities = [f.severity for f in items if f.severity is not None]
        worst = max(severities, key=lambda s: s.sort_key()) if severities else None
        rows.append(UpgradeRow(name, version, len(items), best, unknown, worst, newer_line=len(newer),
                               newer_line_max=max(newer, key=parse_version) if newer else None,
                               display=display_name(items[0].component, items[0].also_in)))
    # Worst severity first; components with only unknown severity after; then by count.
    rows.sort(key=lambda r: (r.worst is None, -(r.worst.sort_key()[0] if r.worst else 0),
                             -r.findings, r.component.lower(), r.version))
    return rows
