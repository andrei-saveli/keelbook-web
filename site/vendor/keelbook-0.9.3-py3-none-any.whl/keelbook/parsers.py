"""SBOM loading and parsing (CycloneDX JSON, SPDX 2.x JSON and SPDX 3.0 JSON-LD).

Only the SBOM is read. No source code is ever touched.

Error-handling approach: SBOMs come from many tools and are often hand-edited
or truncated, so we treat the input as untrusted. Problems that make the whole
file unusable raise a user-friendly SbomError. Problems with a single entry
become warnings, so one bad component does not hide the rest, while the user
still learns that the result is incomplete.
"""

from __future__ import annotations

import io
import json
import re
import shutil
import subprocess
import tarfile
from pathlib import Path
from typing import Any, Callable

from keelbook import models
from keelbook.errors import SbomFormatError, SbomReadError
from keelbook.models import Component, Sbom, VexStatement

CYCLONEDX = "CycloneDX"
SPDX = "SPDX"
SPDX3 = "SPDX3"  # internal marker; Sbom.format is still "SPDX" (spec_version says 3.x)

# Safety cap so a wrong file (e.g. a disk image) is not read into memory.
# Real SBOMs are far smaller; raise this if you ever hit it legitimately.
MAX_SBOM_BYTES = 100 * 1024 * 1024
# Archives of SBOM files (Yocto 5.0 writes IMAGE.spdx.tar.zst).
ARCHIVE_SUFFIXES = (".tar", ".tar.gz", ".tgz", ".tar.zst", ".tar.zstd")
MAX_ARCHIVE_BYTES = 1024 * 1024 * 1024  # uncompressed total


def load_sbom(path: Path, include_files: bool = False) -> Sbom:
    """Read `path`, detect its format, and return a parsed Sbom.

    `path` may also be a folder: Yocto's SPDX 2.2 output is one document per
    recipe/package, so every *.json file in the folder (and below) is read and
    the results are merged. Files that are not SBOMs are skipped with a warning.

    `include_files` keeps CycloneDX entries of type "file" (see parse_cyclonedx).
    """
    if path.is_dir():
        return _load_folder(path, include_files)
    if path.name.lower().endswith(ARCHIVE_SUFFIXES):
        return _load_archive(path, include_files)
    return _parse_data(_read_json_object(path), include_files)


def _parse_data(data: dict[str, Any], include_files: bool) -> Sbom:
    fmt = detect_format(data)
    if fmt == CYCLONEDX:
        return parse_cyclonedx(data, include_files=include_files)
    if fmt == SPDX3:
        return parse_spdx3(data)
    return parse_spdx(data)


def sbom_files(folder: Path) -> list[Path]:
    """The JSON files read when an SBOM folder is given (sorted, for a stable hash)."""
    return sorted(p for p in folder.rglob("*.json") if p.is_file())


def _load_folder(folder: Path, include_files: bool) -> Sbom:
    files = sbom_files(folder)
    if not files:
        raise SbomReadError(f"No .json files found in the folder {folder}")
    items = [(str(f.relative_to(folder)), lambda f=f: _read_json_object(f)) for f in files]
    return _merge_documents(items, include_files, f"the folder {folder.name}")


def _load_archive(path: Path, include_files: bool) -> Sbom:
    """Every *.json SBOM inside a tar archive (plain, .gz or .zst), merged like a folder."""
    if not path.is_file():
        raise SbomReadError(f"File not found: {path}")
    try:
        raw = path.read_bytes()
    except OSError as exc:
        raise SbomReadError(f"Cannot read {path}: {exc.strerror or exc}") from exc
    name = path.name.lower()
    if name.endswith((".tar.zst", ".tar.zstd")):
        raw = _zstd_decompress(raw, path)
        if not raw:
            raise SbomFormatError(f"{path} decompressed to nothing. Is the file complete?")
    try:
        archive = tarfile.open(fileobj=io.BytesIO(raw), mode="r:*")
    except (tarfile.TarError, EOFError, OSError) as exc:
        raise SbomFormatError(f"{path} is not a readable tar archive: {exc}") from exc
    items = []
    total = 0
    with archive:
        for member in archive.getmembers():
            if not member.isfile() or not member.name.lower().endswith(".json"):
                continue
            total += member.size
            if member.size > MAX_SBOM_BYTES or total > MAX_ARCHIVE_BYTES:
                raise SbomReadError(f"{path} contains more data than an SBOM archive should "
                                    f"({member.name}). Is this really an SBOM archive?")
            data = archive.extractfile(member).read()  # read into memory; nothing is written to disk
            items.append((member.name, lambda data=data, n=member.name: _json_object_from_bytes(data, n)))
    if not items:
        raise SbomFormatError(f"{path} contains no .json files")
    items.sort(key=lambda item: item[0])
    return _merge_documents(items, include_files, f"the archive {path.name}")


def _zstd_decompress(raw: bytes, path: Path) -> bytes:
    """Zstandard: Python 3.14+ has it built in; else the optional 'zstandard'
    package or the 'zstd' program is used if present."""
    try:
        from compression import zstd  # Python 3.14+
    except ImportError:
        zstd = None
    if zstd is not None:
        try:
            return zstd.decompress(raw)
        except zstd.ZstdError as exc:
            raise SbomFormatError(f"{path} is not valid zstd data: {exc}") from exc
    try:
        import zstandard  # optional, not a dependency of this tool
    except ImportError:
        zstandard = None
    if zstandard is not None:
        try:
            # read_across_frames: Yocto's archives can hold several zstd frames
            # (parallel compression); stopping after the first one returns little or nothing.
            with zstandard.ZstdDecompressor().stream_reader(io.BytesIO(raw), read_across_frames=True) as reader:
                return reader.read()
        except zstandard.ZstdError as exc:
            raise SbomFormatError(f"{path} is not valid zstd data: {exc}") from exc
    program = shutil.which("zstd")
    if program:
        done = subprocess.run([program, "-d", "-c", "-q"], input=raw, capture_output=True)
        if done.returncode == 0:
            return done.stdout
        raise SbomFormatError(f"{path} is not valid zstd data: {done.stderr.decode(errors='replace').strip()}")
    raise SbomReadError(
        f"{path} is compressed with zstd. Reading it needs Python 3.14 or newer, or the 'zstd' "
        "program (Fedora: sudo dnf install zstd; Debian/Ubuntu: sudo apt install zstd). "
        f"Or extract it yourself: mkdir sbom && tar --zstd -xf {path.name} -C sbom, then use --sbom sbom"
    )


def _merge_documents(items: list[tuple[str, Callable[[], dict[str, Any]]]], include_files: bool,
                     where: str) -> Sbom:
    """Parse several SBOM documents and merge them into one Sbom."""
    parts: list[Sbom] = []
    rejected: list[str] = []
    for name, read in items:
        try:
            part = _parse_data(read(), include_files)
        except SbomFormatError as exc:
            rejected.append(f"{name}: {exc}")
            continue
        part.warnings = [f"{name}: {w}" for w in part.warnings]
        parts.append(part)
    if not parts:
        raise SbomFormatError(
            f"None of the {len(items)} .json file(s) in {where} is a supported SBOM. "
            f"First problem: {rejected[0]}"
        )

    formats = sorted({p.format for p in parts})
    versions = sorted({p.spec_version or "?" for p in parts})
    merged = Sbom(format="+".join(formats), spec_version="/".join(versions))
    seen: set[Component] = set()
    duplicates = 0
    notes: dict[str, int] = {}
    for part in parts:
        for component in part.components:
            if component in seen:
                duplicates += 1
                continue
            seen.add(component)
            merged.components.append(component)
        merged.warnings.extend(part.warnings)
        merged.vex.extend(part.vex)
        for note in part.notes:
            notes[note] = notes.get(note, 0) + 1
    merged.notes.append(f"Read {len(parts)} SBOM file(s) from {where}.")
    for note, times in notes.items():
        merged.notes.append(note if times == 1 else f"{note} (in {times} files)")
    if duplicates:
        merged.notes.append(f"Merged {duplicates} identical component(s) listed in more than one file.")
    _link_packages_to_recipes(merged)
    if rejected:
        merged.warnings.append(
            f"Skipped {len(rejected)} file(s) that are not supported SBOMs, e.g. {rejected[0]}"
        )
    return merged


def _link_packages_to_recipes(sbom: Sbom) -> None:
    """Yocto 5.0 (SPDX 2.2): installed packages and their recipes are in separate
    documents, linked by GENERATED_FROM. The recipe carries the CPE.

    When such links exist, each package inherits its recipe's CPE (and version
    if missing), and the recipes are left out: they describe how software is
    built (including build-only "-native" tools), not what is on the device.
    """
    by_address = {c.spdx_address: c for c in sbom.components if c.spdx_address}
    linked_recipes = {c.generated_from for c in sbom.components
                      if c.generated_from in by_address and c.generated_from != c.spdx_address}
    if not linked_recipes:
        return  # e.g. a folder with recipe documents only: keep them as they are
    from dataclasses import replace

    kept: list[Component] = []
    inherited = 0
    recipes_left_out = 0
    for component in sbom.components:
        if component.spdx_address and "#SPDXRef-Recipe-" in component.spdx_address:
            recipes_left_out += 1
            continue
        recipe = by_address.get(component.generated_from or "")
        if recipe is not None:
            if not component.cpe and recipe.cpe:
                inherited += 1
            component = replace(
                component,
                cpe=component.cpe or recipe.cpe,
                version=component.version or recipe.version,
                source_package=component.source_package or recipe.name,
            )
        kept.append(component)
    sbom.components = kept
    sbom.notes.append(
        f"Linked installed packages to their recipes across documents: {inherited} package(s) use their "
        f"recipe's CPE. Left out {recipes_left_out} recipe(s) (how software is built, incl. build-only tools)."
    )


def _read_json_object(path: Path) -> dict[str, Any]:
    """Read a file and return its top-level JSON object, or raise SbomError."""
    if not path.exists():
        raise SbomReadError(f"File not found: {path}")
    if not path.is_file():
        raise SbomReadError(f"Not a regular file: {path}")

    try:
        size = path.stat().st_size
        if size > MAX_SBOM_BYTES:
            raise SbomReadError(
                f"{path} is {size // (1024 * 1024)} MB, above the "
                f"{MAX_SBOM_BYTES // (1024 * 1024)} MB limit. Is this really an SBOM?"
            )
        raw = path.read_bytes()
    except PermissionError as exc:
        raise SbomReadError(f"Permission denied reading {path}") from exc
    except OSError as exc:
        raise SbomReadError(f"Cannot read {path}: {exc.strerror or exc}") from exc
    return _json_object_from_bytes(raw, str(path))


def _json_object_from_bytes(raw: bytes, path: str) -> dict[str, Any]:
    """Decode and parse one JSON document; `path` is only used in messages."""
    try:
        # "utf-8-sig" also accepts a leading BOM, which some Windows tools add
        # and which would otherwise make json.loads fail confusingly.
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise SbomReadError(f"{path} is not UTF-8 text, so it cannot be a JSON SBOM") from exc

    if not text.strip():
        raise SbomFormatError(f"{path} is empty")

    try:
        data = json.loads(text)
    except json.JSONDecodeError as exc:
        # Line and column let the user find a truncated or hand-edited spot.
        raise SbomFormatError(
            f"{path} is not valid JSON: {exc.msg} (line {exc.lineno}, column {exc.colno})"
        ) from exc
    except RecursionError as exc:
        # Pathologically nested JSON exhausts Python's stack; report it cleanly.
        raise SbomFormatError(f"{path} is nested too deeply to be a real SBOM") from exc

    if not isinstance(data, dict):
        raise SbomFormatError(
            f"{path} is valid JSON, but the top level is not an object, so it is not an SBOM"
        )
    return data


def detect_format(data: dict[str, Any]) -> str:
    """Return CYCLONEDX or SPDX, or raise SbomFormatError if unrecognised."""
    if data.get("bomFormat") == "CycloneDX":
        return CYCLONEDX

    spdx_version = data.get("spdxVersion")
    if isinstance(spdx_version, str) and spdx_version.startswith("SPDX-"):
        return SPDX

    # SPDX 3.x is JSON-LD: an @context pointing at spdx.org and an @graph of elements.
    if "@graph" in data or "@context" in data:
        if "spdx" in json.dumps(data.get("@context", "")).lower():
            return SPDX3

    raise SbomFormatError(
        "Unrecognised SBOM format. Expected CycloneDX JSON (has 'bomFormat'), "
        "SPDX 2.x JSON (has 'spdxVersion') or SPDX 3.0 JSON-LD (has '@context')."
    )


def ecosystem_from_purl(purl: str | None) -> str | None:
    """Return the purl type (e.g. 'npm', 'pypi') or None if there is no usable purl."""
    if not purl or not purl.lower().startswith("pkg:"):
        return None
    rest = purl[4:].lstrip("/")
    purl_type = re.split(r"[/@?#]", rest, maxsplit=1)[0].strip().lower()
    return purl_type or None


def _clean_str(value: Any) -> str | None:
    """Return a stripped non-empty string, else None.

    SBOM fields are often null, numbers, or placeholders, so never assume str.
    """
    if isinstance(value, str):
        value = value.strip()
        if value and value.upper() not in {"NOASSERTION", "NONE"}:
            return value
    return None


def parse_cyclonedx(data: dict[str, Any], include_files: bool = False) -> Sbom:
    """Parse a CycloneDX JSON document (components may be nested).

    Some generators (Syft, for example) list every file in the scanned image
    as a component of type "file". Those are not software components and can
    outnumber the real ones many times over, so they are skipped by default
    and counted in a note instead. Pass include_files=True to keep them.
    """
    spec_version = _clean_str(data.get("specVersion"))
    sbom = Sbom(format=CYCLONEDX, spec_version=spec_version, serial=_clean_str(data.get("serialNumber")))

    top = data.get("components", [])
    if top is None:
        top = []  # an explicit null is treated like "no components"
    if not isinstance(top, list):
        raise SbomFormatError("CycloneDX 'components' must be a list")

    skipped = 0
    ignored_files = 0
    # Iterative walk instead of recursion: deeply nested components cannot
    # blow the Python stack. Order is not important (the CLI sorts later).
    stack: list[Any] = list(top)
    while stack:
        entry = stack.pop()
        if not isinstance(entry, dict):
            skipped += 1
            continue

        nested = entry.get("components")
        if isinstance(nested, list):
            stack.extend(nested)

        kind = _clean_str(entry.get("type"))
        if kind is not None:
            kind = kind.lower()
        if kind == "file" and not include_files:
            ignored_files += 1
            continue

        name = _clean_str(entry.get("name"))
        if name is None:
            skipped += 1
            continue
        group = _clean_str(entry.get("group"))
        if group:
            name = f"{group}/{name}"  # e.g. Maven groupId, npm scope

        purl = _clean_str(entry.get("purl"))
        sbom.components.append(
            Component(
                name=name,
                version=_clean_str(entry.get("version")),
                ecosystem=ecosystem_from_purl(purl),
                purl=purl,
                kind=kind,
                cpe=_clean_str(entry.get("cpe")),
                ref=_clean_str(entry.get("bom-ref")),
            )
        )

    # Some generators (e.g. cyclonedx-py) list the same package twice: once
    # with a purl and once as a purl-less "local source" entry. Drop the
    # purl-less twin (same name AND version) so it is not counted twice.
    with_purl = {(c.name, c.version) for c in sbom.components if c.purl}
    kept = [c for c in sbom.components if c.purl or (c.name, c.version) not in with_purl]
    duplicates = len(sbom.components) - len(kept)
    sbom.components = kept
    if duplicates:
        sbom.notes.append(
            f"Merged {duplicates} duplicate entr{'y' if duplicates == 1 else 'ies'} "
            "(same name and version, one without a purl)."
        )

    if skipped:
        sbom.warnings.append(
            f"Skipped {skipped} malformed component entr{'y' if skipped == 1 else 'ies'} "
            "(not an object, or no usable name)."
        )
    if ignored_files:
        sbom.notes.append(
            f"Ignored {ignored_files} file entr{'y' if ignored_files == 1 else 'ies'} "
            "(type 'file', not software components). Use --include-files to list them."
        )
    # A CycloneDX SBOM may carry its producer's VEX statements itself.
    if isinstance(data.get("vulnerabilities"), list) and data["vulnerabilities"]:
        from keelbook.vex import cyclonedx_statements

        statements, problems = cyclonedx_statements(data["vulnerabilities"], sbom, "CycloneDX VEX in the SBOM")
        sbom.vex.extend(statements)
        sbom.warnings.extend(problems)
        if statements:
            sbom.notes.append(f"The SBOM contains {len(statements)} VEX statement(s) from its producer.")
    return sbom


def parse_spdx(data: dict[str, Any]) -> Sbom:
    """Parse an SPDX 2.x JSON document.

    The package(s) the document says it DESCRIBES are usually the product (or
    container image) itself, not a dependency, so they are left out when the
    SBOM also lists other packages. If *every* package is marked as described
    (some tools do that), nothing is removed, so real dependencies are never
    hidden. Anything removed is reported in a note.
    """
    raw_version = _clean_str(data.get("spdxVersion"))
    spec_version = raw_version.removeprefix("SPDX-") if raw_version else None
    sbom = Sbom(format=SPDX, spec_version=spec_version)

    packages = data.get("packages", [])
    if packages is None:
        packages = []
    if not isinstance(packages, list):
        raise SbomFormatError("SPDX 'packages' must be a list")

    skipped = 0
    downloads = 0
    namespace = _clean_str(data.get("documentNamespace"))
    external_docs = {
        ref.get("externalDocumentId"): ref.get("spdxDocument")
        for ref in data.get("externalDocumentRefs") or []
        if isinstance(ref, dict) and isinstance(ref.get("externalDocumentId"), str)
    }
    generated_from = _spdx_generated_from(data, namespace, external_docs)
    parsed: list[tuple[str | None, Component]] = []
    for entry in packages:
        if not isinstance(entry, dict):
            skipped += 1
            continue
        name = _clean_str(entry.get("name"))
        if name is None:
            skipped += 1
            continue
        spdx_id = _clean_str(entry.get("SPDXID"))
        version = _clean_str(entry.get("versionInfo"))
        # Yocto lists each recipe's source tarball as "SPDXRef-Download-..."
        # without a version. The recipe itself (with its CPE) is the component;
        # the download is not a separate piece of installed software.
        if spdx_id and spdx_id.startswith("SPDXRef-Download-") and version is None:
            downloads += 1
            continue

        refs = entry.get("externalRefs")
        purl = _find_spdx_ref(refs, ("purl",))
        component = Component(
            name=name,
            version=version,
            ecosystem=ecosystem_from_purl(purl),
            purl=purl,
            cpe=_find_spdx_ref(refs, ("cpe23Type", "cpe22Type")),
            spdx_address=f"{namespace}#{spdx_id}" if namespace and spdx_id else None,
            generated_from=generated_from.get(spdx_id or ""),
        )
        parsed.append((spdx_id, component))

    described = _spdx_described_ids(data)
    all_ids = {spdx_id for spdx_id, _ in parsed if spdx_id}
    remove_roots = bool(described) and bool(all_ids - described)
    roots_removed = 0
    for spdx_id, component in parsed:
        if remove_roots and spdx_id in described:
            roots_removed += 1
            continue
        sbom.components.append(component)

    if skipped:
        sbom.warnings.append(
            f"Skipped {skipped} malformed package entr{'y' if skipped == 1 else 'ies'} "
            "(not an object, or no usable name)."
        )
    if roots_removed:
        sbom.notes.append(
            f"Left out {roots_removed} package(s) the SBOM describes as the product itself "
            "(not a dependency)."
        )
    if downloads:
        sbom.notes.append(
            f"Left out {downloads} source-download entr{'y' if downloads == 1 else 'ies'} "
            "(Yocto 'SPDXRef-Download-', covered by their recipe)."
        )
    return sbom


def _spdx_generated_from(data: dict[str, Any], namespace: str | None, external_docs: dict) -> dict[str, str]:
    """SPDXID -> "namespace#SPDXID" of what it was GENERATED_FROM (also in another document)."""
    links: dict[str, str] = {}
    for rel in data.get("relationships") or []:
        if not isinstance(rel, dict) or rel.get("relationshipType") != "GENERATED_FROM":
            continue
        source, target = rel.get("spdxElementId"), rel.get("relatedSpdxElement")
        if not isinstance(source, str) or not isinstance(target, str) or target == "NOASSERTION":
            continue
        if ":" in target:  # DocumentRef-recipe-acl:SPDXRef-Recipe-acl
            doc_ref, _, element = target.partition(":")
            target_namespace = external_docs.get(doc_ref)
        else:
            target_namespace, element = namespace, target
        if target_namespace:
            links.setdefault(source, f"{target_namespace}#{element}")
    return links


def _spdx_described_ids(data: dict[str, Any]) -> set[str]:
    """SPDX IDs the document says it describes (documentDescribes / DESCRIBES)."""
    described: set[str] = set()

    declared = data.get("documentDescribes")
    if isinstance(declared, list):
        described.update(x for x in declared if isinstance(x, str))

    relationships = data.get("relationships")
    if isinstance(relationships, list):
        for rel in relationships:
            if not isinstance(rel, dict):
                continue
            kind = rel.get("relationshipType")
            source = rel.get("spdxElementId")
            target = rel.get("relatedSpdxElement")
            if kind == "DESCRIBES" and source == "SPDXRef-DOCUMENT" and isinstance(target, str):
                described.add(target)
            elif kind == "DESCRIBED_BY" and target == "SPDXRef-DOCUMENT" and isinstance(source, str):
                described.add(source)
    return described


def _find_spdx_ref(external_refs: Any, types: tuple[str, ...]) -> str | None:
    """Return the first externalRefs locator whose type is one of `types`.

    Tools write the type either short ("cpe23Type") or as a URI
    ("http://spdx.org/rdf/references/cpe23Type", as Yocto does); both count.
    """
    if not isinstance(external_refs, list):
        return None
    wanted = {t.lower() for t in types}
    for ref in external_refs:
        if not isinstance(ref, dict):
            continue
        kind = ref.get("referenceType")
        if not isinstance(kind, str):
            continue
        short = re.split(r"[/#]", kind.strip())[-1].lower()
        if short in wanted:
            locator = _clean_str(ref.get("referenceLocator"))
            if locator:
                return locator
    return None


# --- SPDX 3.0 (JSON-LD) -------------------------------------------------------
#
# SPDX 3.0 is a flat list of elements in "@graph", linked by "spdxId". Yocto
# 5.1 and newer write it by default. What matters here:
#   software_Package       name, software_packageVersion, software_packageUrl,
#                          externalIdentifier (cpe23 / packageUrl),
#                          software_primaryPurpose (install, specification, ...)
#   (LifecycleScoped)Relationship  "generates": recipe -> installed packages
#   security_Vulnerability + security_Vex*VulnAssessmentRelationship:
#                          the producer's statement that a CVE is fixed /
#                          not affecting / affecting a package or recipe.

_VEX_TYPES = {
    "fixed": models.FIXED,
    "notaffected": models.NOT_AFFECTED,
    "affected": models.AFFECTED,
    "underinvestigation": models.UNDER_INVESTIGATION,
}
# Packages that describe how something is built or where its source came from,
# not software installed on the device.
_NOT_INSTALLED_PURPOSES = {"specification", "source"}


def _short_type(value: Any) -> str:
    """'software_Package' or '.../Software/Package' -> 'package' (lower case)."""
    if not isinstance(value, str):
        return ""
    return re.split(r"[_/#]", value.strip())[-1].lower()


def _spdx3_identifiers(entry: dict[str, Any]) -> dict[str, str]:
    found: dict[str, str] = {}
    idents = entry.get("externalIdentifier")
    if isinstance(idents, list):
        for ident in idents:
            if not isinstance(ident, dict):
                continue
            kind = _clean_str(ident.get("externalIdentifierType"))
            value = _clean_str(ident.get("identifier"))
            if kind and value:
                found.setdefault(kind.lower(), value)
    return found


def parse_spdx3(data: dict[str, Any]) -> Sbom:
    """Parse an SPDX 3.0 JSON-LD document (as written by Yocto 5.1+)."""
    graph = data.get("@graph")
    if not isinstance(graph, list):
        raise SbomFormatError("SPDX 3.0 document has no '@graph' list of elements")
    version_match = re.search(r"/rdf/(\d+\.\d+(?:\.\d+)?)/", json.dumps(data.get("@context", "")))
    sbom = Sbom(format=SPDX, spec_version=version_match.group(1) if version_match else "3")

    elements: dict[str, dict[str, Any]] = {}
    packages: list[dict[str, Any]] = []
    relationships: list[dict[str, Any]] = []
    roots: set[str] = set()
    skipped = 0
    for entry in graph:
        if not isinstance(entry, dict):
            skipped += 1
            continue
        kind = _short_type(entry.get("type") or entry.get("@type"))
        spdx_id = _clean_str(entry.get("spdxId") or entry.get("@id"))
        if spdx_id:
            elements[spdx_id] = entry
        if kind == "package":
            packages.append(entry)
        elif kind.endswith("relationship"):
            relationships.append(entry)
        elif kind == "sbom":
            for root in entry.get("rootElement") or []:
                if isinstance(root, str):
                    roots.add(root)

    def targets(rel: dict[str, Any]) -> list[str]:
        to = rel.get("to")
        return [t for t in (to if isinstance(to, list) else [to]) if isinstance(t, str)]

    # recipe/source -> packages it generates (Yocto: busybox -> busybox-syslog)
    generated_by: dict[str, str] = {}
    generates: dict[str, list[str]] = {}
    for rel in relationships:
        if rel.get("relationshipType") == "generates" and isinstance(rel.get("from"), str):
            for target in targets(rel):
                generated_by.setdefault(target, rel["from"])
                generates.setdefault(rel["from"], []).append(target)

    def describe(entry: dict[str, Any]) -> tuple[str | None, str | None, str | None, str | None]:
        idents = _spdx3_identifiers(entry)
        purl = _clean_str(entry.get("software_packageUrl")) or idents.get("packageurl")
        cpe = idents.get("cpe23") or idents.get("cpe22")
        return _clean_str(entry.get("name")), _clean_str(entry.get("software_packageVersion")), purl, cpe

    candidates = []
    left_out = {"recipe/source": 0, "product": 0}
    for entry in packages:
        name, version, purl, cpe = describe(entry)
        if name is None:
            skipped += 1
            continue
        purpose = (_clean_str(entry.get("software_primaryPurpose")) or "").lower()
        spdx_id = _clean_str(entry.get("spdxId") or entry.get("@id"))
        candidates.append((spdx_id, entry, name, version, purl, cpe, purpose))

    # Keep installed software. Leave out recipes/sources and the product itself
    # (the SBOM's root element), unless that would leave nothing at all.
    def keep(item) -> bool:
        spdx_id, _, _, _, _, _, purpose = item
        return purpose not in _NOT_INSTALLED_PURPOSES and spdx_id not in roots
    kept = [c for c in candidates if keep(c)] or candidates
    for item in candidates:
        if item not in kept:
            left_out["product" if item[0] in roots else "recipe/source"] += 1

    for spdx_id, entry, name, version, purl, cpe, _ in kept:
        source = elements.get(generated_by.get(spdx_id or "", ""))
        source_name = None
        if source is not None:
            s_name, s_version, s_purl, s_cpe = describe(source)
            source_name = s_name
            version = version or s_version
            cpe = cpe or s_cpe  # Yocto puts the CPE on the recipe
        sbom.components.append(
            Component(
                name=name,
                version=version,
                ecosystem=ecosystem_from_purl(purl),
                purl=purl,
                cpe=cpe,
                source_package=source_name,
            )
        )

    sbom.vex = _spdx3_vex(elements, relationships, generates, targets, describe)
    unassessed = _spdx3_unassessed(relationships, elements, sbom.vex, targets)

    if skipped:
        sbom.warnings.append(
            f"Skipped {skipped} malformed element(s) (not an object, or a package without a name)."
        )
    if left_out["recipe/source"]:
        sbom.notes.append(
            f"Left out {left_out['recipe/source']} recipe/source package(s) "
            "(how software is built, not what is installed)."
        )
    if left_out["product"]:
        sbom.notes.append(f"Left out {left_out['product']} package(s) the SBOM names as the product itself.")
    if sbom.vex:
        sbom.notes.append(f"The SBOM contains {len(sbom.vex)} VEX statement(s) from its producer.")
    if unassessed:
        sbom.notes.append(
            f"The SBOM links {unassessed} vulnerabilit{'y' if unassessed == 1 else 'ies'} to packages "
            "without a VEX statement; the lookup decides about those."
        )
    return sbom


def _spdx3_cve(vuln: dict[str, Any]) -> str | None:
    idents = _spdx3_identifiers(vuln)
    for value in (idents.get("cve"), _clean_str(vuln.get("name"))):
        if value and re.fullmatch(r"CVE-\d{4}-\d{4,}", value, re.IGNORECASE):
            return value.upper()
    return None


def _spdx3_vex(elements, relationships, generates, targets, describe) -> list[VexStatement]:
    statements: list[VexStatement] = []
    for rel in relationships:
        kind = _short_type(rel.get("type") or rel.get("@type"))
        match = re.fullmatch(r"vex(\w+?)vulnassessmentrelationship", kind)
        if not match or match.group(1) not in _VEX_TYPES:
            continue
        vuln = elements.get(rel.get("from")) if isinstance(rel.get("from"), str) else None
        cve = _spdx3_cve(vuln) if vuln else None
        if cve is None:
            continue
        names: set[str] = set()
        for target in targets(rel):
            for spdx_id in [target, *generates.get(target, [])]:
                element = elements.get(spdx_id)
                if element is not None:
                    name = describe(element)[0]
                    if name:
                        names.add(name.lower())
        if not names:
            continue
        detail = None
        for key in ("security_justificationType", "security_impactStatement", "security_statusNotes",
                    "security_actionStatement", "comment"):
            detail = _clean_str(rel.get(key))
            if detail:
                break
        statements.append(
            VexStatement(cve, _VEX_TYPES[match.group(1)], frozenset(names), "SPDX 3.0 VEX", detail)
        )
    return statements


def _spdx3_unassessed(relationships, elements, vex, targets) -> int:
    assessed = {s.cve_id for s in vex}
    linked: set[str] = set()
    for rel in relationships:
        if rel.get("relationshipType") == "hasAssociatedVulnerability":
            for target in targets(rel):
                element = elements.get(target)
                cve = _spdx3_cve(element) if element else None
                if cve and cve not in assessed:
                    linked.add(cve)
    return len(linked)
