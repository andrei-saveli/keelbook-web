"""Command-line presentation layer (click + rich).

Only user interaction lives here: argument parsing, spinners, tables, colours,
and exit codes. All real work is delegated to `parsers`, so the same logic can
later back other front ends (a web dashboard, CI integration) unchanged.

Exit codes: 0 success, 1 problem with the SBOM input, 2 bad command usage
(click's own convention), 3 vulnerability lookup failed, 4 too little of the
SBOM could be checked (see --min-coverage).
"""

from __future__ import annotations

import os
import re
import ssl
import sys
import zipfile
from collections import Counter
from pathlib import Path

import click
from rich import box
from rich.console import Console
from rich.markup import escape
from rich.table import Table
from rich.text import Text

from keelbook import __version__
from keelbook.cases_cli import audit, case, clocks_cmd
from keelbook.errors import SbomError, VulnLookupError
from keelbook.euvd import EuvdCatalogue, euvd_matches
from keelbook.kev import KevCatalogue, kev_matches
from keelbook.models import Sbom
from keelbook.parsers import load_sbom
from keelbook.report import (
    candidate_sources, make_context, ordered, severity_text, status_text, write_csv, write_markdown,
)
from keelbook.scanpipe import LookupOptions, has_lookup_extras, lookup_options, run_pipeline
from keelbook.vex import is_resolved
from keelbook.vulns import Finding, LookupResult, clean_summary, display_name, upgrade_summary

EXIT_LOW_COVERAGE = 4
FINDING_ROWS_SHOWN = 100


@click.group(context_settings={"help_option_names": ["-h", "--help"]})
def main() -> None:
    """keelbook: work with SBOMs for EU Cyber Resilience Act (CRA) duties.

    Reads only the SBOM file. Never reads or uploads your source code.
    """


@main.command()
def version() -> None:
    """Print the tool version."""
    click.echo(f"keelbook {__version__}")


@main.command("update-db")
@click.option("--from-dir", "from_dir", type=click.Path(path_type=Path, file_okay=False, exists=True),
              help="Build the CVE List index from a folder instead of downloading, e.g. a git clone of "
              "github.com/CVEProject/cvelistV5 (for computers without direct internet access).")
@click.option("--from-zip", "from_zip", type=click.Path(path_type=Path, dir_okay=False, exists=True),
              help="Build it from a downloaded release archive (*_all_CVEs_at_midnight.zip.zip).")
def update_db(from_dir: Path | None, from_zip: Path | None) -> None:
    """Download the official CVE List and build the local index used by --cve-list.

    Downloads several hundred MB from the CVE Project's GitHub releases and keeps a
    condensed index in your user cache folder. Nothing about your products is sent.
    """
    from keelbook.cvelist import CveListIndex, build_index, default_index_file, download_and_build, iter_dir, iter_zip

    console = Console()
    err_console = Console(stderr=True)
    path = default_index_file()
    try:
        with console.status("Building the CVE List index...") as status:
            def progress(text: str) -> None:
                status.update(escape(text))

            def counted(n: int) -> None:
                progress(f"Indexed {n:,} CVE records...")

            if from_dir is not None:
                kept = build_index(iter_dir(from_dir), path, source=f"folder {from_dir.name}", progress=counted)
            elif from_zip is not None:
                kept = build_index(iter_zip(from_zip), path, source=f"archive {from_zip.name}", progress=counted)
            else:
                kept = download_and_build(path, progress=progress)
        index = CveListIndex.open(path)
    except VulnLookupError as exc:
        err_console.print(f"[bold red]Error:[/bold red] {escape(str(exc))}")
        raise SystemExit(3) from exc
    except (OSError, zipfile.BadZipFile) as exc:
        err_console.print(f"[bold red]Error:[/bold red] could not read the CVE List source ({escape(str(exc))}).")
        raise SystemExit(1) from exc
    console.print(f"CVE List index ready: {kept:,} CVE records with product data "
                  f"({index.meta.get('source')}), stored in {path}.")


@main.command()
@click.option(
    "--sbom",
    "sbom_path",
    required=True,
    type=click.Path(path_type=Path),
    help="CycloneDX JSON, SPDX 2.x JSON or SPDX 3.0 JSON-LD file, a folder of such files, "
    "or a .tar/.tar.gz/.tar.zst archive of them (Yocto SPDX 2.2 output).",
)
@click.option(
    "--include-files",
    is_flag=True,
    help="Also list CycloneDX entries of type 'file' (hidden by default).",
)
@click.option(
    "--components",
    "show_components",
    is_flag=True,
    help="Also print the full component table when --check-vulns is used "
    "(without --check-vulns the table is always shown).",
)
@click.option(
    "--check-vulns",
    is_flag=True,
    help="Look up known vulnerabilities. Sends package identifiers only (never source "
    "code): purls to api.osv.dev, and CPEs of components without a usable purl to "
    "the US NVD (services.nvd.nist.gov).",
)
@click.option(
    "--min-coverage",
    type=click.IntRange(0, 100),
    default=None,
    metavar="PERCENT",
    help="Exit with code 4 if fewer than PERCENT of the components could be checked. "
    "Without it, code 4 is used only when nothing could be checked.",
)
@click.option(
    "--details",
    is_flag=True,
    help="Add a Summary column to the findings table (wide terminals).",
)
@click.option(
    "--csv",
    "csv_path",
    type=click.Path(path_type=Path, dir_okay=False),
    help="Write all findings to a CSV file. Needs --check-vulns.",
)
@click.option(
    "--md",
    "md_path",
    type=click.Path(path_type=Path, dir_okay=False),
    help="Write a Markdown scan record (with SBOM SHA-256, coverage, KEV date). Needs --check-vulns.",
)
@click.option(
    "--html",
    "html_path",
    type=click.Path(path_type=Path, dir_okay=False),
    help="Write the report as a web page (opens in any browser, can be printed to PDF). Needs --check-vulns.",
)
@click.option(
    "--xlsx",
    "xlsx_path",
    type=click.Path(path_type=Path, dir_okay=False),
    help="Write the findings as an Excel workbook (Summary, Components, Findings). Needs --check-vulns.",
)
@click.option(
    "--all",
    "show_all",
    is_flag=True,
    help="Print every finding and every check in the terminal (default: a short report; files have everything).",
)
@click.option(
    "--sarif",
    "sarif_path",
    type=click.Path(path_type=Path, dir_okay=False),
    help="Write the findings as SARIF 2.1.0 for CI (GitHub code scanning and others). Needs --check-vulns.",
)
@lookup_options
def scan(
    sbom_path: Path,
    include_files: bool,
    show_components: bool,
    check_vulns: bool,
    details: bool,
    csv_path: Path | None,
    md_path: Path | None,
    sarif_path: Path | None,
    html_path: Path | None,
    xlsx_path: Path | None,
    show_all: bool,
    min_coverage: int | None,
    **lookup,
) -> None:
    """Parse an SBOM, list its components and (with --check-vulns) look up known vulnerabilities.

    The extra lookup options (--kev, --euvd, --vex, --yocto-cve, ...) need --check-vulns.
    """
    opts = LookupOptions(**lookup)
    if (csv_path or md_path or sarif_path or html_path or xlsx_path or has_lookup_extras(opts)) and not check_vulns:
        raise click.UsageError("--kev, --kev-download, --euvd, --vex, --csv, --md, --html, --xlsx, --sarif and "
                               "--yocto-cve need --check-vulns.")
    console = Console()
    # Errors go to stderr so stdout stays clean for the table (pipes, scripts).
    err_console = Console(stderr=True)

    try:
        with console.status("Parsing SBOM..."):
            sbom = load_sbom(sbom_path, include_files=include_files)
    except SbomError as exc:
        # SbomError messages are written for users, so no traceback here.
        # escape() stops file names like "[x].json" being read as rich markup.
        err_console.print(f"[bold red]Error:[/bold red] {escape(str(exc))}")
        raise click.exceptions.Exit(1) from exc

    for warning in sbom.warnings:
        err_console.print(f"[yellow]Warning:[/yellow] {escape(warning)}")

    for note in sbom.notes:
        console.print(f"[dim]Note: {escape(note)}[/dim]")

    if not sbom.components:
        console.print("[yellow]No components found in this SBOM.[/yellow]")
        return

    # With --check-vulns the findings are the point: a long component table in
    # front of them buries the result, so it is shown only on request.
    if show_components or not check_vulns:
        console.print(_build_table(sbom))
    console.print(
        f"[dim]{sbom.format} {escape(sbom.spec_version or '')} | "
        f"{len(sbom.components)} component(s) | "
        f"{escape(_ecosystem_summary(sbom))}[/dim]"
    )
    if not check_vulns:
        console.print("[dim]Add --check-vulns to look up known vulnerabilities (OSV).[/dim]")
        return

    result = run_pipeline(console, err_console, sbom, opts)
    lookup, catalogue, euvd = result.lookup, result.kev, result.euvd
    yocto_reports, vex_files, statements = result.yocto_reports, result.vex_files, result.statements
    yocto_added = result.yocto_added

    _print_lookup(console, lookup, total=len(sbom.components), catalogue=catalogue, details=details, euvd=euvd,
                  show_all=show_all)
    if statements:
        _section(console, "What the SBOM producer says")
        _print_statement_summary(console, lookup, yocto_reports, yocto_added, bool(sbom.vex), vex_files,
                                 limit=None if show_all else TOP_ROWS)

    if csv_path or md_path or sarif_path or html_path or xlsx_path:
        try:
            ctx = make_context(sbom_path, sbom.format, sbom.spec_version, len(sbom.components), __version__)
            if csv_path:
                write_csv(csv_path, lookup, catalogue, euvd)
                console.print(f"Wrote CSV: {escape(str(csv_path))}")
            if md_path:
                write_markdown(md_path, ctx, lookup, catalogue, euvd)
                console.print(f"Wrote Markdown record: {escape(str(md_path))}")
            if sarif_path:
                from keelbook.sarif import sarif_document, write_sarif
                write_sarif(sarif_path, sarif_document(lookup, _sbom_uri(sbom_path), len(sbom.components),
                                                       catalogue, euvd, result.sources()))
                console.print(f"Wrote SARIF: {escape(str(sarif_path))}")
            if html_path:
                from keelbook.htmlreport import scan_html
                html_path.write_text(scan_html(ctx, lookup, catalogue, euvd), encoding="utf-8")
                console.print(f"Wrote web page report: {escape(str(html_path))}")
            if xlsx_path:
                from keelbook.xlsxreport import scan_workbook
                scan_workbook(xlsx_path, ctx, lookup, catalogue, euvd)
                console.print(f"Wrote Excel workbook: {escape(str(xlsx_path))}")
        except OSError as exc:
            err_console.print(f"[bold red]Error:[/bold red] could not write output file: {escape(str(exc))}")
            raise click.exceptions.Exit(1) from exc

    _print_notes(console, lookup)
    if not (csv_path or md_path or html_path or xlsx_path):
        _section(console, "Next steps")
        console.print("Readable report with everything:  [bold]--html report.html[/bold]   ·   Excel:  "
                      "[bold]--xlsx findings.xlsx[/bold]")
        console.print("Record decisions per release:     [bold]keelbook product add NAME[/bold], then "
                      "[bold]keelbook product scan NAME --release X --sbom FILE[/bold]")
    _check_coverage(err_console, lookup, len(sbom.components), min_coverage)


def _check_coverage(err_console: Console, lookup: LookupResult, total: int, minimum: int | None) -> None:
    """Exit 4 when too little was checked, so scripts and CI cannot miss it."""
    percent = 100 * lookup.checked / total if total else 100
    if lookup.checked == 0 and total:
        err_console.print(
            "[bold red]Nothing in this SBOM could be checked.[/bold red] An empty result here does "
            "NOT mean the product is free of known vulnerabilities. See the reasons above."
        )
        raise click.exceptions.Exit(EXIT_LOW_COVERAGE)
    if minimum is not None and percent < minimum:
        err_console.print(
            f"[bold red]Only {percent:.0f}% of the components could be checked "
            f"(--min-coverage {minimum}).[/bold red]"
        )
        raise click.exceptions.Exit(EXIT_LOW_COVERAGE)


def _build_table(sbom: Sbom) -> Table:
    table = Table(title=f"Components ({len(sbom.components)})")
    table.add_column("Name")
    table.add_column("Version")
    table.add_column("Ecosystem")

    ordered = sorted(
        sbom.components,
        key=lambda c: ((c.ecosystem or "~"), c.name.lower(), c.version or ""),
    )
    for comp in ordered:
        # Text(...) rather than a plain str: rich parses str cells as markup,
        # and SBOM contents are untrusted (a name like "[red]x" must not
        # change the output).
        table.add_row(
            Text(comp.name),
            Text(comp.version or "-"),
            Text(comp.ecosystem or "unknown"),
        )
    return table


def _ecosystem_summary(sbom: Sbom) -> str:
    counts = Counter(c.ecosystem or "unknown" for c in sbom.components)
    return ", ".join(f"{eco}: {n}" for eco, n in sorted(counts.items()))


TOP_ROWS = 10  # rows per section in the default (short) report; --all shows everything


def _section(console: Console, title: str) -> None:
    console.print()
    console.rule(f"[bold]{escape(title)}[/bold]", align="left", style="dim")


def _severity_line(findings: list[Finding]) -> Text:
    counts = Counter(f.severity.label if f.severity else "unknown" for f in findings)
    text = Text("Severity: ")
    parts = [(label, counts[label]) for label in ("critical", "high", "medium", "low", "none", "unknown")
             if counts[label]]
    for i, (label, n) in enumerate(parts):
        if i:
            text.append("  ·  ", style="dim")
        text.append(f"{label} {n:,}", style=_SEVERITY_STYLE.get(label, "dim" if label == "unknown" else ""))
    return text


def _print_lookup(
    console: Console,
    lookup: LookupResult,
    total: int,
    catalogue: KevCatalogue | None = None,
    details: bool = False,
    euvd: EuvdCatalogue | None = None,
    show_all: bool = False,
) -> None:
    open_findings = ordered([f for f in lookup.findings if not is_resolved(f)], catalogue, euvd)
    resolved = len(lookup.findings) - len(open_findings)

    _section(console, "Result")
    if open_findings:
        components = len({(f.component.name, f.component.version) for f in open_findings})
        line = f"{len(open_findings):,} open finding(s) in {components} component(s)"
        if resolved:
            line += f"  ·  {resolved:,} marked fixed or not affected by the SBOM producer"
        console.print(Text(line, style="bold"))
        console.print(_severity_line(open_findings))
    elif lookup.checked == 0:
        console.print("[bold red]No component could be checked, so there is no result.[/bold red]")
    elif resolved:
        console.print(
            f"No open findings: all {resolved} known vulnerabilities are marked fixed or not affected "
            "by the SBOM producer (see below)."
        )
    else:
        console.print(f"[green]No known vulnerabilities found for the {lookup.checked} checked component(s).[/green]")
    _print_coverage(console, lookup, total)

    if catalogue or euvd is not None:
        _section(console, "Act first: listed as exploited")
        _print_candidates(console, lookup, catalogue, euvd)

    if open_findings:
        _section(console, "Components, worst first")
        _print_upgrade_summary(console, open_findings, limit=None if show_all else TOP_ROWS)
        if show_all:
            _section(console, f"All open findings ({len(open_findings):,})")
            console.print(_findings_table(open_findings, catalogue, euvd, details, console.width))
        else:
            shown = min(TOP_ROWS, len(open_findings))
            only = _single_component(open_findings[:shown])
            _section(console, f"Most severe findings ({shown} of {len(open_findings):,})"
                     + (f", all in {only}" if only else ""))
            console.print(_findings_table(open_findings[:shown], catalogue, euvd, details, console.width))
            if len(open_findings) > shown:
                console.print(f"[dim]All {len(open_findings):,}: add --all, or write them to a file with "
                              "--html report.html / --xlsx findings.xlsx.[/dim]")

    _print_checks(console, lookup, show_all)


def _print_coverage(console: Console, lookup: LookupResult, total: int) -> None:
    """Components that were skipped were NOT checked, so say so."""
    skipped_total = sum(lookup.skipped.values())
    coverage = f"Checked {lookup.checked} of {total} component(s)"
    if len(lookup.checked_by) > 1 or set(lookup.checked_by) - {"OSV"}:
        coverage += " (" + ", ".join(f"{src}: {n}" for src, n in sorted(lookup.checked_by.items())) + ")"
    coverage += "."
    if skipped_total:
        reasons = "; ".join(f"{count} {reason}" for reason, count in sorted(lookup.skipped.items()))
        coverage += f" NOT checked: {skipped_total} ({reasons})."
    console.print(f"[yellow]{escape(coverage)}[/yellow]" if skipped_total else escape(coverage))
    if lookup.nvd_missed:
        missed = "; ".join(f"{n} {reason}" for reason, n in sorted(lookup.nvd_missed.items()))
        text = f"Checked by the CVE List only, NOT by NVD: {missed}."
        console.print(f"[yellow]{escape(text)}[/yellow]")
    if "NVD" in lookup.checked_by and not lookup.cvelist_label:
        console.print("[yellow]Not checked against the official CVE List: CVEs that NVD has not analysed "
                      "yet (a large backlog) are missing. Add --cve-list.[/yellow]")


WIDE = 100  # below this terminal width, less important columns are left out (files have everything)


def _single_component(findings: list[Finding]) -> str | None:
    """The component's name if every row is about the same one (then it goes in the title, not each row)."""
    names = {display_name(f.component, f.also_in) for f in findings}
    return names.pop() if len(names) == 1 and len(findings) > 1 else None


def _findings_table(findings: list[Finding], catalogue: KevCatalogue | None, euvd: EuvdCatalogue | None,
                    details: bool, width: int = 120) -> Table:
    show_source = {f.source for f in findings} != {"OSV"} and width >= WIDE
    show_component = _single_component(findings) is None
    show_status = any(f.vex_status for f in findings)
    table = Table(box=box.SIMPLE_HEAD, pad_edge=False)
    # no_wrap on the ID column: a cut-off ID cannot be looked up.
    table.add_column("Vulnerability", no_wrap=True)
    if show_component:
        table.add_column("Component", min_width=12)
    table.add_column("Severity", no_wrap=True)
    table.add_column("Fixed in", no_wrap=True)
    if catalogue is not None or euvd is not None:
        table.add_column("Listed?", no_wrap=True)  # on an exploited-vulnerability list (KEV / EUVD)
    if show_source:
        table.add_column("Source", overflow="fold")
    if show_status:
        table.add_column("Producer says", overflow="fold")
    if details:
        table.add_column("Summary", overflow="ellipsis", max_width=60)
    for finding in findings:
        # CVE IDs first (also those hidden in ALPINE-CVE-... IDs), then the rest.
        others = [i for i in (finding.vuln_id, *finding.aliases)
                  if i not in finding.cve_ids and not any(c in i.upper() for c in finding.cve_ids)]
        # Narrow window: CVE IDs only (the other IDs are in the files), so no column is cut off.
        ids = "\n".join([*finding.cve_ids, *others] if width >= WIDE or not finding.cve_ids else finding.cve_ids)
        row = [Text(ids)] + ([Text(display_name(finding.component, finding.also_in))] if show_component else []) \
            + [_severity_cell(finding), Text(finding.fixed_text)]
        if catalogue is not None or euvd is not None:
            lists = candidate_sources(finding, catalogue, euvd)
            if lists:
                row.append(Text(" + ".join("KEV" if "KEV" in x else "EUVD" for x in lists), style="bold red"))
            else:
                # no CVE ID: the lists cannot be matched, which is not the same as "no"
                row.append(Text("unknown" if not finding.cve_ids else "no", style="dim"))
        if show_source:
            cell = Text(finding.source)
            if finding.vendor_unconfirmed:
                cell.append(" vendor?", style="yellow")
            row.append(cell)
        if show_status:
            row.append(Text(status_text(finding)))
        if details:
            row.append(Text(clean_summary(finding.summary) or "-"))
        table.add_row(*row)
    return table


def _print_checks(console: Console, lookup: LookupResult, show_all: bool) -> None:
    """Things a person should look at once: name-only matches, records that could not be compared."""
    vendor_pairs = _vendor_pairs(lookup)
    if not vendor_pairs and not lookup.cvelist_unknown and not lookup.details_failed:
        return
    _section(console, "Check once")
    if vendor_pairs:
        console.print(
            "[yellow]Check these matches once: the SBOM gives no vendor for these components, so they were "
            "matched by product name only, and the vendor named by NVD or the CVE record is not obviously the "
            "same project. If it is a different product, its findings do not apply ('vendor?' above).[/yellow]"
        )
        limit = None if show_all else 5
        for (name, where, vendor), count in vendor_pairs[:limit]:
            console.print(Text(f"  {name}  ->  {where} '{vendor}'  ({count} finding(s))", style="yellow"))
        if limit and len(vendor_pairs) > limit:
            console.print(f"[dim]  ... and {len(vendor_pairs) - limit} more (--all, or the --md record).[/dim]")
    if lookup.cvelist_unknown:
        total_unknown = sum(len(v) for v in lookup.cvelist_unknown.values())
        console.print(f"[yellow]{total_unknown} CVE record(s) name these components, but give versions that "
                      "cannot be compared with yours (e.g. only source commits). Not counted as findings, "
                      "and not as clean.[/yellow]")
        if show_all:
            for name, ids in sorted(lookup.cvelist_unknown.items()):
                console.print(Text(f"  {name}: {', '.join(ids)}", style="yellow"))
        else:
            parts = ", ".join(f"{name} ({len(ids)})" for name, ids in
                              sorted(lookup.cvelist_unknown.items(), key=lambda kv: -len(kv[1]))[:5])
            console.print(f"[dim]  Most: {escape(parts)}. Full list: --all, or the --md record.[/dim]")
    if lookup.details_failed:
        console.print(f"[yellow]{lookup.details_failed} finding(s) are listed by ID only "
                      "(details could not be fetched).[/yellow]")


def _print_notes(console: Console, lookup: LookupResult) -> None:
    _section(console, "Notes")
    if "NVD" in lookup.checked_by:
        note = (f"NVD: {lookup.nvd_requests} request(s), {lookup.nvd_cache_hits} answer(s) from cache"
                + (" (offline mode: saved answers of any age)" if lookup.offline else "")
                + f"{', oldest fetched ' + lookup.nvd_oldest_data[:16].replace('T', ' ') if lookup.nvd_oldest_data else ''}.")
        if lookup.nvd_platform_only:
            note += (f" Left out {lookup.nvd_platform_only} CVE(s) where NVD lists the product only as a "
                     "platform, not as vulnerable.")
        if lookup.merged_duplicates:
            note += f" Merged {lookup.merged_duplicates} duplicate finding(s) (same CVE via several CPEs)."
        console.print(f"[dim]{escape(note)}[/dim]")
    if lookup.checked_by.keys() & {"NVD", "CVE List"}:
        console.print("[dim]Matching is by version number: a patch backported without a version change is not "
                      "known unless the producer says so (VEX, --yocto-cve).[/dim]")
    console.print(
        "[dim]Known vulnerabilities are not the same as actively exploited ones "
        "(CRA Art. 14). A person must decide what is reportable. Working aid, not legal advice.[/dim]"
    )


def _vendor_pairs(lookup: LookupResult) -> list[tuple[tuple[str, str, str], int]]:
    """((component, where, vendor), count), once per vendor spelling ('Red Hat' = 'redhat')."""
    pairs: dict[tuple[str, str, str], int] = {}
    names: dict[tuple[str, str, str], str] = {}
    for f in lookup.findings:
        where = "NVD vendor" if f.source.startswith("NVD") else "CVE record vendor"
        for vendor in f.vendor_unconfirmed:
            key = (display_name(f.component, f.also_in), where, re.sub(r"[^a-z0-9]", "", vendor.lower()))
            names.setdefault(key, vendor)
            pairs[key] = pairs.get(key, 0) + 1
    out = [((k[0], k[1], names[k]), n) for k, n in pairs.items()]
    return sorted(out, key=lambda item: (-item[1], item[0]))


UPGRADE_ROWS_SHOWN = 15


_SEVERITY_STYLE = {"critical": "bold red", "high": "red", "medium": "yellow"}


def _short_severity(severity) -> str:
    """'9.8 critical' (the CVSS version is in the files, not needed on screen)."""
    if severity is None:
        return "unknown"
    return f"{severity.score:.1f} {severity.label}" if severity.score is not None else severity.label


def _severity_cell(finding: Finding) -> Text:
    style = _SEVERITY_STYLE.get(finding.severity.label, "") if finding.severity else "dim"
    return Text(_short_severity(finding.severity), style=style)


def _component_label(finding: Finding) -> str:
    label = f"{finding.component.name} {finding.component.version or '-'}"
    if finding.also_in:
        label += f" (+{len(finding.also_in)} more from the same source)"
    return label


def _print_statement_summary(console, lookup: LookupResult, yocto_reports, yocto_added: int, in_sbom: bool,
                             vex_files=(), limit: int | None = None) -> None:
    """What the SBOM producer / build system says about the findings."""
    resolved = [f for f in lookup.findings if is_resolved(f)]
    if resolved:
        console.print(f"Marked fixed or not affected by the SBOM producer ({len(resolved)}):")
        table = Table(box=box.SIMPLE_HEAD, pad_edge=False)
        table.add_column("Vulnerability", no_wrap=True)
        table.add_column("Component", overflow="fold")
        table.add_column("Producer says", overflow="fold")
        for finding in resolved[:limit]:
            table.add_row(Text(" ".join(finding.cve_ids) or finding.vuln_id),
                          Text(display_name(finding.component, finding.also_in)), Text(status_text(finding)))
        console.print(table)
        if limit and len(resolved) > limit:
            console.print(f"[dim]{limit} of {len(resolved)} shown; all with --all or in --md / --csv.[/dim]")
    sources = []
    if in_sbom:
        sources.append("VEX statements inside the SBOM")
    for name, file_statements in vex_files:
        sources.append(f"{name} ({len(file_statements)} statement(s) matched to this SBOM)")
    for report in yocto_reports:
        counts = ", ".join(f"{n} {status}" for status, n in sorted(report.counts.items()))
        sources.append(f"Yocto cve-check ({report.packages} recipe(s): {counts or 'no CVEs'})")
    console.print(f"[dim]Producer statements used: {escape('; '.join(sources))}.[/dim]")
    if yocto_added:
        console.print(f"Added {yocto_added} CVE(s) that Yocto lists as Unpatched and the lookup did not find.")
    console.print(
        "[dim]These are the producer's statements, shown as they are. The tool does not verify them; "
        "a person remains responsible for the assessment.[/dim]"
    )


def _print_upgrade_summary(console: Console, findings: list[Finding], limit: int | None = UPGRADE_ROWS_SHOWN) -> None:
    """Short, actionable view: per component version, the worst finding and what to upgrade to."""
    rows = upgrade_summary(findings)
    table = Table(box=box.SIMPLE_HEAD, pad_edge=False)
    table.add_column("Component", min_width=12)
    table.add_column("Findings", justify="right", no_wrap=True)
    table.add_column("Worst", no_wrap=True)
    table.add_column("Upgrade to", min_width=10)
    for row in rows[:limit]:
        target = Text(row.upgrade_to or "unknown", style="bold" if row.upgrade_to else "dim")
        extra = []
        if row.newer_line:
            extra.append(f"+{row.newer_line:,} newer line")
        if row.upgrade_to and row.unknown:
            extra.append(f"{row.unknown:,} no fix data")
        if extra:
            target.append(f" ({', '.join(extra)})", style="dim")
        worst = Text(_short_severity(row.worst),
                     style=_SEVERITY_STYLE.get(row.worst.label, "") if row.worst else "dim")
        table.add_row(Text(row.display or f"{row.component} {row.version}"), Text(f"{row.findings:,}"), worst, target)
    console.print(table)
    if limit and len(rows) > limit:
        console.print(f"[dim]{limit} of {len(rows)} components shown; all with --all or in the --md record.[/dim]")
    console.print("[dim]'Upgrade to': the lowest version in your release line (e.g. 6.12.x) that fixes them; "
                  "'+N newer line': findings no update of your line fixes yet; 'no fix data': the source names "
                  "no fixed version. Severity 'unknown' means no score, not 'low'.[/dim]")


def _print_candidates(console: Console, lookup: LookupResult, catalogue: KevCatalogue | None,
                      euvd: EuvdCatalogue | None) -> None:
    """Findings listed as exploited by CISA KEV and/or ENISA EUVD: candidates only."""
    lists = " and ".join(name for name, used in (("CISA KEV", catalogue), ("EUVD", euvd is not None)) if used)
    hits = [f for f in ordered(lookup.findings, catalogue, euvd) if candidate_sources(f, catalogue, euvd)]
    no_cve = sum(1 for f in lookup.findings if not f.cve_ids)

    if hits:
        # Plain lines, not a table: they stay readable at any terminal width.
        console.print(f"[bold]Candidates for 'actively exploited' ({len(hits)}) - {lists}[/bold]")
        if console.width < 70:  # too narrow for a table: one short block per finding, nothing cut off
            for finding in hits:
                listed = [f"KEV since {e.date_added or '?'}"
                          + (" (ransomware)" if (e.ransomware or "").lower() == "known" else "")
                          for e in (kev_matches(finding, catalogue) if catalogue else [])]
                listed += [f"EUVD {e.euvd_id}, exploited since {e.exploited_since or '?'}"
                           for e in (euvd_matches(finding, euvd) if euvd is not None else [])]
                line = Text(" ".join(finding.cve_ids) + "  ", style="bold")
                line.append_text(_severity_cell(finding))
                console.print(line)
                console.print(Text(f"  {display_name(finding.component, finding.also_in)}, fixed in "
                                   f"{finding.fixed_text}"))
                console.print(Text("  " + "; ".join(listed), style="bold red"))
        if console.width >= 70:
            table = Table(box=box.SIMPLE_HEAD, pad_edge=False)
            table.add_column("Vulnerability", no_wrap=True)
            table.add_column("Component", min_width=10)
            table.add_column("Severity", no_wrap=True)
            table.add_column("Fixed in", no_wrap=True)
            table.add_column("Listed since", min_width=10, overflow="fold")
            narrow = console.width < WIDE  # short pieces on separate lines, so nothing is cut off
            for finding in hits:
                listed = []
                for entry in kev_matches(finding, catalogue) if catalogue else []:
                    ransom = (entry.ransomware or "").lower() == "known"
                    listed.append(f"KEV\n{entry.date_added or '?'}" + ("\nransomware" if ransom else "") if narrow
                                  else f"KEV {entry.date_added or '?'}" + (" (ransomware)" if ransom else ""))
                for entry in euvd_matches(finding, euvd) if euvd is not None else []:
                    listed.append(f"EUVD\n{entry.exploited_since or '?'}\n{entry.euvd_id}" if narrow
                                  else f"EUVD {entry.euvd_id}, exploited since {entry.exploited_since or '?'}")
                table.add_row(Text("\n".join(finding.cve_ids)), Text(display_name(finding.component, finding.also_in)),
                              _severity_cell(finding), Text(finding.fixed_text),
                              Text(("\n" if narrow else "; ").join(listed)))
            console.print(table)
        console.print(
            "[bold]If one of these is really exploited in your product, the Art. 14 "
            "clocks (24 h / 72 h) may be running. A person must confirm and decide.[/bold]"
        )
    else:
        console.print(f"[green]No finding is listed in {escape(lists)}.[/green]")

    notes = []
    if catalogue:
        note = f"KEV data: catalogue released {(catalogue.released or 'unknown date')[:10]}"
        if catalogue.version:
            note += f", version {catalogue.version}"
        notes.append(note + ". Check it is current. KEV is a US list and not complete for EU products.")
    if euvd is not None:
        fetched = euvd.fetched_at.strftime("%Y-%m-%d %H:%M UTC") if euvd.fetched_at else "unknown time"
        notes.append(f"EUVD data: {euvd.total} exploited entries, downloaded {fetched}"
                     + (" (from cache)" if euvd.from_cache else "") + ".")
    resolved_hits = sum(1 for f in hits if is_resolved(f))
    if resolved_hits:
        notes.append(f"{resolved_hits} candidate(s) are marked fixed/not affected by the SBOM producer: check them anyway.")
    if no_cve:
        notes.append(f"{no_cve} finding(s) have no CVE ID and could not be matched.")
    for note in notes:
        console.print(f"[yellow]{escape(note)}[/yellow]")


main.add_command(case)
main.add_command(clocks_cmd)
main.add_command(audit)

from keelbook.register_cli import product  # noqa: E402  (after main is defined; avoids an import cycle)

main.add_command(product)


# Where Linux distributions keep the trusted HTTPS certificates (one file each).
CA_BUNDLES = (
    "/etc/ssl/certs/ca-certificates.crt",  # Debian, Ubuntu
    "/etc/pki/tls/certs/ca-bundle.crt",  # Fedora, RHEL, AlmaLinux, Rocky
    "/etc/pki/ca-trust/extracted/pem/tls-ca-bundle.pem",  # Fedora, RHEL (newer path)
    "/etc/ssl/ca-bundle.pem",  # openSUSE
    "/etc/ssl/cert.pem",  # Alpine, Arch
)


def find_ca_certificates(environ=os.environ, exists=os.path.exists) -> str | None:
    """A certificate file to use when Python's built-in location has none.

    The standalone Linux program is built on Ubuntu and looks where Ubuntu keeps
    certificates; on Fedora/RHEL that place is empty and every HTTPS lookup would
    fail. Returns None when nothing needs to change (or the user set SSL_CERT_FILE).
    """
    if environ.get("SSL_CERT_FILE") or environ.get("SSL_CERT_DIR"):
        return None
    paths = ssl.get_default_verify_paths()
    if (paths.cafile and exists(paths.cafile)) or (paths.capath and exists(paths.capath)
                                                   and os.listdir(paths.capath)):
        return None
    return next((path for path in CA_BUNDLES if exists(path)), None)


def run(prog_name: str | None = None) -> None:
    """Entry point of the `keelbook` (and old `cra-tool`) command.

    When output goes to a file or pipe, Windows may use an old character set
    (e.g. cp1252) that cannot show every character of a component name. Print
    such characters as '?' instead of crashing.
    """
    console_cp = _windows_console_codepage()
    for stream in (sys.stdout, sys.stderr):
        try:
            if console_cp and not stream.isatty():
                # Output redirected to a file in Windows PowerShell: PowerShell decodes it with the
                # console code page (e.g. 437), so write in that one, not Windows' ANSI one (1252).
                stream.reconfigure(encoding="utf-8" if console_cp == 65001 else f"cp{console_cp}", errors="replace")
            else:
                stream.reconfigure(errors="replace")
        except (AttributeError, ValueError, LookupError, OSError):  # replaced/closed stream, unknown code page
            pass
    use_system_certificates()
    main(prog_name=prog_name)


def _windows_console_codepage() -> int | None:
    """The console's output code page on Windows (e.g. 437), None elsewhere or without a console."""
    if sys.platform != "win32":
        return None
    try:
        import ctypes
        cp = int(ctypes.windll.kernel32.GetConsoleOutputCP())
    except Exception:
        return None
    return cp or None  # 0: no console; 65001 is UTF-8 (Python would otherwise write the ANSI code page)


def use_system_certificates(platform: str | None = None) -> str:
    """Make HTTPS trust the same certificates as the operating system. Returns what was done.

    Windows and macOS: let the system verify certificates (truststore). A fresh Windows
    installation holds only some root certificates and fetches the others when Windows
    itself checks a connection; Python reading the store directly fails there
    (CERTIFICATE_VERIFY_FAILED). Linux: Python's own check, pointed at the distribution's
    certificate file when the built-in location is empty (see find_ca_certificates).
    """
    platform = platform or sys.platform
    if platform in ("win32", "darwin"):
        try:
            import truststore
            truststore.inject_into_ssl()
            return "system"
        except Exception:  # missing or unsupported: fall back to Python's own check
            return "python"
    if platform.startswith("linux"):
        bundle = find_ca_certificates()
        if bundle:
            os.environ["SSL_CERT_FILE"] = bundle
            return f"file {bundle}"
    return "python"


def _sbom_uri(path: Path) -> str:
    """The SBOM's path for SARIF: relative to the current folder if possible, with '/'."""
    try:
        return path.resolve().relative_to(Path.cwd().resolve()).as_posix()
    except ValueError:
        return path.resolve().as_uri()
