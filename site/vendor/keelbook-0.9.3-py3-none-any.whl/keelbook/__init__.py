"""Keelbook: vulnerability register for firmware makers (EU Cyber Resilience Act)."""

__version__ = "0.9.3"
