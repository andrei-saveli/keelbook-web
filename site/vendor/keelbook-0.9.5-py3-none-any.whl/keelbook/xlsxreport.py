"""Excel workbooks: the scan findings, and the register's review sheet (fill in, import back)."""

from __future__ import annotations

import csv
import io
from pathlib import Path

from keelbook import models
from keelbook.euvd import EuvdCatalogue, euvd_matches
from keelbook.kev import KevCatalogue, kev_matches
from keelbook.register import JUSTIFICATIONS, STATUSES, ProductState, RegisterError, Release, ReviewRow
from keelbook.registerreport import SHEET_COLUMNS, SHEET_INPUT, _display, read_review_sheet, review_rows
from keelbook.registerreport import ordered as review_order
from keelbook.report import ScanContext, candidate_sources, ordered, status_text
from keelbook.vulns import LookupResult, clean_summary, display_name, upgrade_summary
from keelbook.xlsx import LABEL, NOTE, SEVERITY_STYLE, TITLE, Sheet, XlsxError, read_xlsx, write_xlsx

REVIEW_SHEET = "Review"


def _sev(f) -> tuple[str, float | str]:
    if f.severity is None:
        return "unknown", ""
    return f.severity.label, (f.severity.score if f.severity.score is not None else "")


def scan_workbook(path: Path, ctx: ScanContext, lookup: LookupResult, catalogue: KevCatalogue | None,
                  euvd: EuvdCatalogue | None = None) -> None:
    open_findings = ordered([f for f in lookup.findings if f.vex_status not in models.RESOLVED_STATUSES],
                            catalogue, euvd)
    resolved = [f for f in lookup.findings if f.vex_status in models.RESOLVED_STATUSES]
    lists = catalogue is not None or euvd is not None
    hits = [f for f in open_findings if candidate_sources(f, catalogue, euvd)]
    skipped = sum(lookup.skipped.values())

    summary = Sheet("Summary", header=False, widths=[34, 90], wrap_cols={1})
    s = summary.rows
    s += [["Vulnerability scan report"], [], ["SBOM file", ctx.sbom_name], ["SBOM SHA-256", ctx.sbom_sha256],
          ["Generated (UTC)", ctx.generated_at], ["Tool", f"Keelbook {ctx.tool_version}"], [],
          ["Open findings", len(open_findings)],
          ["Components checked", f"{lookup.checked} of {ctx.total_components}"]]
    summary.styles[(0, 0)] = TITLE
    if skipped:
        s.append(["NOT checked", f"{skipped} component(s): "
                  + "; ".join(f"{n} {r}" for r, n in sorted(lookup.skipped.items())) + " (not clean)"])
    s.append(["On an exploited list (KEV/EUVD)", len(hits) if lists else "not checked (no list used)"])
    if resolved:
        s.append(["Marked fixed/not affected by the producer", len(resolved)])
    if lookup.cvelist_unknown:
        s.append(["CVE records not comparable", sum(len(v) for v in lookup.cvelist_unknown.values())])
    s += [[], ["Sources", ", ".join(sorted(lookup.checked_by)) or "-"],
          ["Note", "Working aid, not legal advice. A known vulnerability is not the same as an actively exploited "
                   "one (CRA Art. 14): a person decides what is reportable."]]
    for r in range(2, len(s)):
        if s[r]:
            summary.styles[(r, 0)] = LABEL
            s[r] = [str(v) for v in s[r]]  # numbers left-aligned next to their label
    summary.styles[(len(s) - 1, 1)] = NOTE
    s += [[], ["Sheets", "Components: one row per component, worst first, with the version to upgrade to. "
                         "Findings: one row per vulnerability (use the filter arrows in the header row)."]]
    summary.styles[(len(s) - 1, 0)] = LABEL

    comps = Sheet("Components", widths=[30, 10, 9, 8, 9, 8, 10, 16, 14, 12], freeze_cols=1)
    comps.rows.append(["Component", "Findings", "Critical", "High", "Medium", "Low", "Unknown", "Upgrade to at least",
                       "Only in a newer line", "Without fix data"])
    by_comp: dict[tuple, list] = {}
    for f in open_findings:
        by_comp.setdefault((f.component.name, f.component.version or "-"), []).append(f)
    for r in upgrade_summary(open_findings):
        items = by_comp[(r.component, r.version)]
        labels = [(_sev(f)[0] if _sev(f)[0] != "none" else "low") for f in items]
        comps.rows.append([r.display, r.findings, *(labels.count(k) for k in ("critical", "high", "medium", "low", "unknown")),
                           r.upgrade_to or "unknown", r.newer_line, r.unknown])

    headers = ["CVE", "Component", "Version", "Severity", "Score", "Fixed in"]
    if lists:
        headers.append("On exploited list")
    headers += ["Summary", "Producer says", "Other IDs", "Source"]
    fs = Sheet("Findings", widths=[16, 22, 12, 10, 7, 12] + ([11] if lists else []) + [60, 22, 22, 14],
               freeze_cols=1)
    fs.wrap_cols = {headers.index("Summary"), headers.index("Producer says")}
    fs.rows.append(headers)
    for f in open_findings + ordered(resolved, catalogue, euvd):
        label, score = _sev(f)
        others = [i for i in (f.vuln_id, *f.aliases) if i not in f.cve_ids]
        row = [" ".join(f.cve_ids) or f.vuln_id, display_name(f.component, f.also_in).rsplit(" ", 1)[0],
               f.component.version or "", label, score, f.fixed_text]
        if lists:
            listed = candidate_sources(f, catalogue, euvd)
            row.append(", ".join(listed) if listed else ("unknown" if not f.cve_ids else "no"))
        row += [clean_summary(f.summary) or "", status_text(f) or "", " ".join(others),
                f.source + (" (check vendor)" if f.vendor_unconfirmed else "")]
        fs.rows.append(row)
        style = SEVERITY_STYLE.get(label)
        if style:
            fs.styles[(len(fs.rows) - 1, 3)] = style
    sheets = [summary, comps, fs]
    if lists and hits:
        hs = Sheet("Exploited", widths=[16, 22, 12, 10, 12, 40], freeze_cols=1)
        hs.rows.append(["CVE", "Component", "Version", "Severity", "Fixed in", "Listed"])
        for f in hits:
            listed = [f"CISA KEV since {k.date_added or '?'}" for k in (kev_matches(f, catalogue) if catalogue else [])]
            listed += [f"EUVD {e.euvd_id}" for e in (euvd_matches(f, euvd) if euvd is not None else [])]
            hs.rows.append([" ".join(f.cve_ids), display_name(f.component, f.also_in).rsplit(" ", 1)[0],
                            f.component.version or "", _sev(f)[0], f.fixed_text, "; ".join(listed)])
            style = SEVERITY_STYLE.get(_sev(f)[0])
            if style:
                hs.styles[(len(hs.rows) - 1, 3)] = style
        sheets.insert(1, hs)
    write_xlsx(path, sheets)


# Review sheet in Excel: (column, header shown, width). The columns a person needs come first,
# then the yellow input columns, then reference columns; product/release/key are hidden (the
# import needs them). Headers are readable; the import maps them back to the CSV column names.
REVIEW_LAYOUT = [
    ("cve_ids", "CVE", 16), ("component", "Component", 22), ("version", "Version", 11),
    ("severity", "Severity", 13), ("kev", "On CISA KEV", 9), ("euvd_exploited", "On EUVD exploited", 10),
    ("fixed_in_per_source", "Fixed in (per source)", 13), ("state", "State", 20), ("summary", "Summary", 50),
    ("new_status", "Your decision", 19), ("new_justification", "Justification (if not_affected)", 30),
    ("new_impact", "Impact statement (if not_affected, instead of a justification)", 28),
    ("new_action", "Action (if affected)", 28), ("new_fixed_in", "Fixed in release (if fixed)", 14),
    ("new_reason", "Reason (always)", 40),
    ("current_status", "Current decision", 16), ("current_reason", "Current reason", 30),
    ("decided_by", "Decided by", 14), ("decided_at", "Decided at (UTC)", 19),
    ("current_justification", "Current justification", 20), ("current_impact", "Current impact", 20),
    ("current_action", "Current action", 20), ("current_fixed_in", "Current fixed in", 12),
    ("decided_for_version", "Decided for version", 12), ("producer_says", "Producer says", 22),
    ("other_ids", "Other IDs", 22), ("source", "Source", 12), ("matched_as", "Matched as", 22),
    ("check_vendor", "Check vendor", 14),
    ("product", "product", 10), ("release", "release", 10), ("key", "key", 10),
]
HIDDEN = {"product", "release", "key"}
assert sorted(c for c, _, _ in REVIEW_LAYOUT) == sorted(SHEET_COLUMNS)


def review_workbook(path: Path, state: ProductState, release: Release, rows: list[ReviewRow]) -> int:
    """The review sheet as Excel: drop-down lists for the decision and justification. Returns the row count."""
    data = review_rows(state, release, rows)
    position = {name: i for i, name in enumerate(SHEET_COLUMNS)}
    names = [c for c, _, _ in REVIEW_LAYOUT]
    review = Sheet(REVIEW_SHEET, rows=[[label for _, label, _ in REVIEW_LAYOUT]],
                   widths=[w for _, _, w in REVIEW_LAYOUT], freeze_cols=2)
    comp_col = names.index("component")
    for row, item in zip(data, review_order(rows)):
        values = [row[position[c]] for c in names]
        values[comp_col] = _display(item.finding)  # short name; the hidden key identifies the finding
        review.rows.append(values)
    review.input_cols = {names.index(c) for c in SHEET_INPUT}
    review.wrap_cols = {names.index(c) for c in ("summary", "current_reason", "producer_says")}
    review.hidden_cols = {names.index(c) for c in HIDDEN}
    sev_col = names.index("severity")
    for r, row in enumerate(review.rows[1:], start=1):
        style = SEVERITY_STYLE.get(row[sev_col].split()[-1] if row[sev_col] else "")
        if style:
            review.styles[(r, sev_col)] = style
    review.dropdowns = {names.index("new_status"): list(STATUSES),
                        names.index("new_justification"): list(JUSTIFICATIONS)}
    review.tip = {names.index("new_status"): "not_affected: also give a justification or impact. affected: also an "
                                             "action. fixed: also the release with the fix. Always give a reason.",
                  names.index("new_justification"): "Only for not_affected (or write an impact statement instead)."}
    review.dropdown_rows = len(data)

    guide = Sheet("How to use", header=False, widths=[100], wrap_cols={0})
    guide.rows += [[f"Review sheet: {state.name} ({state.id}), release {release.label}"], [],
                   ["1. Open the 'Review' tab. Each row is one finding of this release, most urgent first."],
                   ["2. Fill in the yellow columns for the findings you have decided:"],
                   ["    Your decision (choose from the list) and Reason (always)."],
                   ["    not_affected: also Justification (list) or an Impact statement."],
                   ["    affected: also Action (what is being done, e.g. 'Upgrade to 2.17.1 in 1.1')."],
                   ["    fixed: also Fixed in release."],
                   ["3. Leave the rows you have not decided empty: they are ignored."],
                   ["4. Save the file as .xlsx, then run:"],
                   [f"    keelbook product import {state.id} --sheet {path.name}"],
                   ["    Either all filled-in rows are recorded, or none is (the problems are listed)."], [],
                   ["Tips: use the filter arrows in the header row (e.g. to show one component). Columns after "
                    "'Reason' show the current decision and more detail. Do not rename the column headers."],
                   [], ["Working aid, not legal advice. Every decision is recorded with your name."]]
    guide.styles[(0, 0)] = TITLE
    guide.styles[(len(guide.rows) - 1, 0)] = NOTE
    write_xlsx(path, [review, guide])
    return len(data)


def read_review_workbook(path: Path, state: ProductState, release: Release):
    """Decisions from a filled-in review workbook (same rules as the CSV sheet)."""
    try:
        sheets = read_xlsx(path)
    except XlsxError as exc:
        raise RegisterError(str(exc)) from exc
    by_label = {label.lower(): name for name, label, _ in REVIEW_LAYOUT}
    by_label.update({name: name for name in SHEET_COLUMNS})

    def names(header: list[str]) -> list[str]:
        return [by_label.get(h.strip().lower(), h.strip()) for h in header]

    rows = sheets.get(REVIEW_SHEET) or next((r for r in sheets.values() if r and "new_status" in names(r[0])), None)
    if not rows:
        raise RegisterError(f"{path.name} has no '{REVIEW_SHEET}' sheet from 'keelbook product sheet --out review.xlsx'.")
    out = io.StringIO()
    writer = csv.writer(out)
    header = names(rows[0])
    width = len(header)
    writer.writerow(header)
    for row in rows[1:]:
        writer.writerow((row + [""] * width)[:width])
    return read_review_sheet(out.getvalue(), state, release, {name: label for name, label, _ in REVIEW_LAYOUT})
